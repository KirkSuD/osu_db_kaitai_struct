#pragma once

// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

#include "kaitai/kaitaistruct.h"
#include <stdint.h>
#include <memory>
#include "vlq_base128_le.h"
#include <vector>

#if KAITAI_STRUCT_VERSION < 9000L
#error "Incompatible Kaitai Struct C++/STL API: version 0.9 or later is required"
#endif
class vlq_base128_le_t;

/**
 * osu!.db file format in rhythm game, osu!.
 * \sa https://osu.ppy.sh/wiki/zh-tw/osu%21_File_Formats/Db_%28file_format%29 Source
 */

class osu_db_t : public kaitai::kstruct {

public:
    class timing_point_t;
    class string_t;
    class beatmap_t;
    class timing_points_t;
    class bool_t;
    class int_double_pair_t;
    class int_double_pairs_t;

    osu_db_t(kaitai::kstream* p__io, kaitai::kstruct* p__parent = nullptr, osu_db_t* p__root = nullptr);

private:
    void _read();
    void _clean_up();

public:
    ~osu_db_t();

    /**
     * Consists of a Double, signifying the BPM, another Double,
     * signifying the offset into the song, in milliseconds, and a Boolean;
     * if false, then this timing point is inherited.
     * See Osu (file format) for more information regarding timing points.
     */

    class timing_point_t : public kaitai::kstruct {

    public:

        timing_point_t(kaitai::kstream* p__io, osu_db_t::timing_points_t* p__parent = nullptr, osu_db_t* p__root = nullptr);

    private:
        void _read();
        void _clean_up();

    public:
        ~timing_point_t();

    private:
        double m_bpm;
        double m_offset;
        std::unique_ptr<bool_t> m_not_inherited;
        osu_db_t* m__root;
        osu_db_t::timing_points_t* m__parent;

    public:
        double bpm() const { return m_bpm; }
        double offset() const { return m_offset; }
        bool_t* not_inherited() const { return m_not_inherited.get(); }
        osu_db_t* _root() const { return m__root; }
        osu_db_t::timing_points_t* _parent() const { return m__parent; }
    };

    class string_t : public kaitai::kstruct {

    public:

        string_t(kaitai::kstream* p__io, kaitai::kstruct* p__parent = nullptr, osu_db_t* p__root = nullptr);

    private:
        void _read();
        void _clean_up();

    public:
        ~string_t();

    private:
        int8_t m_is_present;
        std::unique_ptr<vlq_base128_le_t> m_len_str;
        bool n_len_str;

    public:
        bool _is_null_len_str() { len_str(); return n_len_str; };

    private:
        std::string m_value;
        bool n_value;

    public:
        bool _is_null_value() { value(); return n_value; };

    private:
        osu_db_t* m__root;
        kaitai::kstruct* m__parent;

    public:
        int8_t is_present() const { return m_is_present; }
        vlq_base128_le_t* len_str() const { return m_len_str.get(); }
        std::string value() const { return m_value; }
        osu_db_t* _root() const { return m__root; }
        kaitai::kstruct* _parent() const { return m__parent; }
    };

    class beatmap_t : public kaitai::kstruct {

    public:

        beatmap_t(kaitai::kstream* p__io, osu_db_t* p__parent = nullptr, osu_db_t* p__root = nullptr);

    private:
        void _read();
        void _clean_up();

    public:
        ~beatmap_t();

    private:
        int32_t m_len_beatmap;
        bool n_len_beatmap;

    public:
        bool _is_null_len_beatmap() { len_beatmap(); return n_len_beatmap; };

    private:
        std::unique_ptr<string_t> m_artist_name;
        std::unique_ptr<string_t> m_artist_name_unicode;
        std::unique_ptr<string_t> m_song_title;
        std::unique_ptr<string_t> m_song_title_unicode;
        std::unique_ptr<string_t> m_creator_name;
        std::unique_ptr<string_t> m_difficulty;
        std::unique_ptr<string_t> m_audio_file_name;
        std::unique_ptr<string_t> m_md5_hash;
        std::unique_ptr<string_t> m_osu_file_name;
        int8_t m_ranked_status;
        int16_t m_num_hitcircles;
        int16_t m_num_sliders;
        int16_t m_num_spinners;
        int64_t m_last_modification_time;
        int8_t m_approach_rate_byte;
        bool n_approach_rate_byte;

    public:
        bool _is_null_approach_rate_byte() { approach_rate_byte(); return n_approach_rate_byte; };

    private:
        float m_approach_rate;
        bool n_approach_rate;

    public:
        bool _is_null_approach_rate() { approach_rate(); return n_approach_rate; };

    private:
        int8_t m_circle_size_byte;
        bool n_circle_size_byte;

    public:
        bool _is_null_circle_size_byte() { circle_size_byte(); return n_circle_size_byte; };

    private:
        float m_circle_size;
        bool n_circle_size;

    public:
        bool _is_null_circle_size() { circle_size(); return n_circle_size; };

    private:
        int8_t m_hp_drain_byte;
        bool n_hp_drain_byte;

    public:
        bool _is_null_hp_drain_byte() { hp_drain_byte(); return n_hp_drain_byte; };

    private:
        float m_hp_drain;
        bool n_hp_drain;

    public:
        bool _is_null_hp_drain() { hp_drain(); return n_hp_drain; };

    private:
        int8_t m_overall_difficulty_byte;
        bool n_overall_difficulty_byte;

    public:
        bool _is_null_overall_difficulty_byte() { overall_difficulty_byte(); return n_overall_difficulty_byte; };

    private:
        float m_overall_difficulty;
        bool n_overall_difficulty;

    public:
        bool _is_null_overall_difficulty() { overall_difficulty(); return n_overall_difficulty; };

    private:
        double m_slider_velocity;
        std::unique_ptr<int_double_pairs_t> m_star_rating_osu;
        bool n_star_rating_osu;

    public:
        bool _is_null_star_rating_osu() { star_rating_osu(); return n_star_rating_osu; };

    private:
        std::unique_ptr<int_double_pairs_t> m_star_rating_taiko;
        bool n_star_rating_taiko;

    public:
        bool _is_null_star_rating_taiko() { star_rating_taiko(); return n_star_rating_taiko; };

    private:
        std::unique_ptr<int_double_pairs_t> m_star_rating_ctb;
        bool n_star_rating_ctb;

    public:
        bool _is_null_star_rating_ctb() { star_rating_ctb(); return n_star_rating_ctb; };

    private:
        std::unique_ptr<int_double_pairs_t> m_star_rating_mania;
        bool n_star_rating_mania;

    public:
        bool _is_null_star_rating_mania() { star_rating_mania(); return n_star_rating_mania; };

    private:
        int32_t m_drain_time;
        int32_t m_total_time;
        int32_t m_audio_preview_start_time;
        std::unique_ptr<timing_points_t> m_timing_points;
        int32_t m_beatmap_id;
        int32_t m_beatmap_set_id;
        int32_t m_thread_id;
        int8_t m_grade_osu;
        int8_t m_grade_taiko;
        int8_t m_grade_ctb;
        int8_t m_grade_mania;
        int16_t m_local_beatmap_offset;
        float m_stack_leniency;
        int8_t m_gameplay_mode;
        std::unique_ptr<string_t> m_song_source;
        std::unique_ptr<string_t> m_song_tags;
        int16_t m_online_offset;
        std::unique_ptr<string_t> m_song_title_font;
        std::unique_ptr<bool_t> m_is_unplayed;
        int64_t m_last_played_time;
        std::unique_ptr<bool_t> m_is_osz2;
        std::unique_ptr<string_t> m_folder_name;
        int64_t m_last_check_repo_time;
        std::unique_ptr<bool_t> m_ignore_sound;
        std::unique_ptr<bool_t> m_ignore_skin;
        std::unique_ptr<bool_t> m_disable_storyboard;
        std::unique_ptr<bool_t> m_disable_video;
        std::unique_ptr<bool_t> m_visual_override;
        int16_t m_unknown_short;
        bool n_unknown_short;

    public:
        bool _is_null_unknown_short() { unknown_short(); return n_unknown_short; };

    private:
        int32_t m_last_modification_time_int;
        int8_t m_mania_scroll_speed;
        osu_db_t* m__root;
        osu_db_t* m__parent;

    public:

        /**
         * Int,	Size in bytes of the beatmap entry. Only present if version is less than 20191106.
         */
        int32_t len_beatmap() const { return m_len_beatmap; }

        /**
         * String, Artist name
         */
        string_t* artist_name() const { return m_artist_name.get(); }

        /**
         * String, Artist name, in Unicode
         */
        string_t* artist_name_unicode() const { return m_artist_name_unicode.get(); }

        /**
         * String, Song title
         */
        string_t* song_title() const { return m_song_title.get(); }

        /**
         * String, Song title, in Unicode
         */
        string_t* song_title_unicode() const { return m_song_title_unicode.get(); }

        /**
         * String, Creator name
         */
        string_t* creator_name() const { return m_creator_name.get(); }

        /**
         * String, Difficulty (e.g. Hard, Insane, etc.)
         */
        string_t* difficulty() const { return m_difficulty.get(); }

        /**
         * String, Audio file name
         */
        string_t* audio_file_name() const { return m_audio_file_name.get(); }

        /**
         * String, MD5 hash of the beatmap
         */
        string_t* md5_hash() const { return m_md5_hash.get(); }

        /**
         * String, Name of the .osu file corresponding to this beatmap
         */
        string_t* osu_file_name() const { return m_osu_file_name.get(); }

        /**
         * Byte, Ranked status (0 = unknown, 1 = unsubmitted, 2 = pending/wip/graveyard, 3 = unused, 4 = ranked, 5 = approved, 6 = qualified, 7 = loved)
         */
        int8_t ranked_status() const { return m_ranked_status; }

        /**
         * Short, Number of hitcircles
         */
        int16_t num_hitcircles() const { return m_num_hitcircles; }

        /**
         * Short, Number of sliders (note: this will be present in every mode)
         */
        int16_t num_sliders() const { return m_num_sliders; }

        /**
         * Short, Number of spinners (note: this will be present in every mode)
         */
        int16_t num_spinners() const { return m_num_spinners; }

        /**
         * Long, Last modification time, Windows ticks.
         */
        int64_t last_modification_time() const { return m_last_modification_time; }

        /**
         * Byte/Single, Approach rate. Byte if the version is less than 20140609, Single otherwise.
         */
        int8_t approach_rate_byte() const { return m_approach_rate_byte; }

        /**
         * Byte/Single, Approach rate. Byte if the version is less than 20140609, Single otherwise.
         */
        float approach_rate() const { return m_approach_rate; }

        /**
         * Byte/Single, Circle size. Byte if the version is less than 20140609, Single otherwise.
         */
        int8_t circle_size_byte() const { return m_circle_size_byte; }

        /**
         * Byte/Single, Circle size. Byte if the version is less than 20140609, Single otherwise.
         */
        float circle_size() const { return m_circle_size; }

        /**
         * Byte/Single, HP drain. Byte if the version is less than 20140609, Single otherwise.
         */
        int8_t hp_drain_byte() const { return m_hp_drain_byte; }

        /**
         * Byte/Single, HP drain. Byte if the version is less than 20140609, Single otherwise.
         */
        float hp_drain() const { return m_hp_drain; }

        /**
         * Byte/Single, Overall difficulty. Byte if the version is less than 20140609, Single otherwise.
         */
        int8_t overall_difficulty_byte() const { return m_overall_difficulty_byte; }

        /**
         * Byte/Single, Overall difficulty. Byte if the version is less than 20140609, Single otherwise.
         */
        float overall_difficulty() const { return m_overall_difficulty; }

        /**
         * Double, Slider velocity
         */
        double slider_velocity() const { return m_slider_velocity; }

        /**
         * Int-Double pair*, Star Rating info for osu! standard, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
         */
        int_double_pairs_t* star_rating_osu() const { return m_star_rating_osu.get(); }

        /**
         * Int-Double pair*, Star Rating info for Taiko, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
         */
        int_double_pairs_t* star_rating_taiko() const { return m_star_rating_taiko.get(); }

        /**
         * Int-Double pair*, Star Rating info for CTB, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
         */
        int_double_pairs_t* star_rating_ctb() const { return m_star_rating_ctb.get(); }

        /**
         * Int-Double pair*, Star Rating info for osu!mania, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
         */
        int_double_pairs_t* star_rating_mania() const { return m_star_rating_mania.get(); }

        /**
         * Int, Drain time, in seconds
         */
        int32_t drain_time() const { return m_drain_time; }

        /**
         * Int, Total time, in milliseconds
         */
        int32_t total_time() const { return m_total_time; }

        /**
         * Int, Time when the audio preview when hovering over a beatmap in beatmap select starts, in milliseconds.
         */
        int32_t audio_preview_start_time() const { return m_audio_preview_start_time; }

        /**
         * Timing point+, An Int indicating the number of following Timing points, then the aforementioned Timing points.
         */
        timing_points_t* timing_points() const { return m_timing_points.get(); }

        /**
         * Int, Beatmap ID
         */
        int32_t beatmap_id() const { return m_beatmap_id; }

        /**
         * Int, Beatmap set ID
         */
        int32_t beatmap_set_id() const { return m_beatmap_set_id; }

        /**
         * Int, Thread ID
         */
        int32_t thread_id() const { return m_thread_id; }

        /**
         * Byte, Grade achieved in osu! standard.
         */
        int8_t grade_osu() const { return m_grade_osu; }

        /**
         * Byte, Grade achieved in Taiko.
         */
        int8_t grade_taiko() const { return m_grade_taiko; }

        /**
         * Byte, Grade achieved in CTB.
         */
        int8_t grade_ctb() const { return m_grade_ctb; }

        /**
         * Byte, Grade achieved in osu!mania.
         */
        int8_t grade_mania() const { return m_grade_mania; }

        /**
         * Short, Local beatmap offset
         */
        int16_t local_beatmap_offset() const { return m_local_beatmap_offset; }

        /**
         * Single, Stack leniency
         */
        float stack_leniency() const { return m_stack_leniency; }

        /**
         * Byte, Osu gameplay mode. 0x00 = osu!Standard, 0x01 = Taiko, 0x02 = CTB, 0x03 = Mania
         */
        int8_t gameplay_mode() const { return m_gameplay_mode; }

        /**
         * String, Song source
         */
        string_t* song_source() const { return m_song_source.get(); }

        /**
         * String, Song tags
         */
        string_t* song_tags() const { return m_song_tags.get(); }

        /**
         * Short, Online offset
         */
        int16_t online_offset() const { return m_online_offset; }

        /**
         * String, Font used for the title of the song
         */
        string_t* song_title_font() const { return m_song_title_font.get(); }

        /**
         * Boolean, Is beatmap unplayed
         */
        bool_t* is_unplayed() const { return m_is_unplayed.get(); }

        /**
         * Long, Last time when beatmap was played
         */
        int64_t last_played_time() const { return m_last_played_time; }

        /**
         * Boolean, Is the beatmap osz2
         */
        bool_t* is_osz2() const { return m_is_osz2.get(); }

        /**
         * String, Folder name of the beatmap, relative to Songs folder
         */
        string_t* folder_name() const { return m_folder_name.get(); }

        /**
         * Long, Last time when beatmap was checked against osu! repository
         */
        int64_t last_check_repo_time() const { return m_last_check_repo_time; }

        /**
         * Boolean, Ignore beatmap sound
         */
        bool_t* ignore_sound() const { return m_ignore_sound.get(); }

        /**
         * Boolean, Ignore beatmap skin
         */
        bool_t* ignore_skin() const { return m_ignore_skin.get(); }

        /**
         * Boolean, Disable storyboard
         */
        bool_t* disable_storyboard() const { return m_disable_storyboard.get(); }

        /**
         * Boolean, Disable video
         */
        bool_t* disable_video() const { return m_disable_video.get(); }

        /**
         * Boolean, Visual override
         */
        bool_t* visual_override() const { return m_visual_override.get(); }

        /**
         * Short?, Unknown. Only present if version is less than 20140609.
         */
        int16_t unknown_short() const { return m_unknown_short; }

        /**
         * Int, Last modification time (?)
         */
        int32_t last_modification_time_int() const { return m_last_modification_time_int; }

        /**
         * Byte, Mania scroll speed
         */
        int8_t mania_scroll_speed() const { return m_mania_scroll_speed; }
        osu_db_t* _root() const { return m__root; }
        osu_db_t* _parent() const { return m__parent; }
    };

    /**
     * An Int indicating the number of following Timing points, then the aforementioned Timing points.
     */

    class timing_points_t : public kaitai::kstruct {

    public:

        timing_points_t(kaitai::kstream* p__io, osu_db_t::beatmap_t* p__parent = nullptr, osu_db_t* p__root = nullptr);

    private:
        void _read();
        void _clean_up();

    public:
        ~timing_points_t();

    private:
        int32_t m_num_points;
        std::unique_ptr<std::vector<std::unique_ptr<timing_point_t>>> m_points;
        osu_db_t* m__root;
        osu_db_t::beatmap_t* m__parent;

    public:
        int32_t num_points() const { return m_num_points; }
        std::vector<std::unique_ptr<timing_point_t>>* points() const { return m_points.get(); }
        osu_db_t* _root() const { return m__root; }
        osu_db_t::beatmap_t* _parent() const { return m__parent; }
    };

    class bool_t : public kaitai::kstruct {

    public:

        bool_t(kaitai::kstream* p__io, kaitai::kstruct* p__parent = nullptr, osu_db_t* p__root = nullptr);

    private:
        void _read();
        void _clean_up();

    public:
        ~bool_t();

    private:
        bool f_value;
        bool m_value;

    public:
        bool value();

    private:
        int8_t m_byte;
        osu_db_t* m__root;
        kaitai::kstruct* m__parent;

    public:
        int8_t byte() const { return m_byte; }
        osu_db_t* _root() const { return m__root; }
        kaitai::kstruct* _parent() const { return m__parent; }
    };

    /**
     * The first byte is 0x08, followed by an Int, then 0x0d, followed by a Double.
     * These extraneous bytes are presumably flags to signify different data types
     * in these slots, though in practice no other such flags have been seen.
     * Currently the purpose of this data type is unknown.
     */

    class int_double_pair_t : public kaitai::kstruct {

    public:

        int_double_pair_t(kaitai::kstream* p__io, osu_db_t::int_double_pairs_t* p__parent = nullptr, osu_db_t* p__root = nullptr);

    private:
        void _read();
        void _clean_up();

    public:
        ~int_double_pair_t();

    private:
        std::string m_magic1;
        int32_t m_int;
        std::string m_magic2;
        double m_double;
        osu_db_t* m__root;
        osu_db_t::int_double_pairs_t* m__parent;

    public:
        std::string magic1() const { return m_magic1; }
        int32_t int() const { return m_int; }
        std::string magic2() const { return m_magic2; }
        double double() const { return m_double; }
        osu_db_t* _root() const { return m__root; }
        osu_db_t::int_double_pairs_t* _parent() const { return m__parent; }
    };

    /**
     * An Int indicating the number of following Int-Double pairs, then the aforementioned pairs.
     */

    class int_double_pairs_t : public kaitai::kstruct {

    public:

        int_double_pairs_t(kaitai::kstream* p__io, osu_db_t::beatmap_t* p__parent = nullptr, osu_db_t* p__root = nullptr);

    private:
        void _read();
        void _clean_up();

    public:
        ~int_double_pairs_t();

    private:
        int32_t m_num_pairs;
        std::unique_ptr<std::vector<std::unique_ptr<int_double_pair_t>>> m_pairs;
        osu_db_t* m__root;
        osu_db_t::beatmap_t* m__parent;

    public:
        int32_t num_pairs() const { return m_num_pairs; }
        std::vector<std::unique_ptr<int_double_pair_t>>* pairs() const { return m_pairs.get(); }
        osu_db_t* _root() const { return m__root; }
        osu_db_t::beatmap_t* _parent() const { return m__parent; }
    };

private:
    int32_t m_osu_version;
    int32_t m_folder_count;
    std::unique_ptr<bool_t> m_account_unlocked;
    int64_t m_account_unlock_date;
    std::unique_ptr<string_t> m_player_name;
    int32_t m_num_beatmaps;
    std::unique_ptr<std::vector<std::unique_ptr<beatmap_t>>> m_beatmaps;
    int32_t m_user_permissions;
    osu_db_t* m__root;
    kaitai::kstruct* m__parent;

public:

    /**
     * Int, osu! version (e.g. 20150203)
     */
    int32_t osu_version() const { return m_osu_version; }

    /**
     * Int, Folder Count
     */
    int32_t folder_count() const { return m_folder_count; }

    /**
     * Bool, AccountUnlocked (only false when the account is locked or banned in any way)
     */
    bool_t* account_unlocked() const { return m_account_unlocked.get(); }

    /**
     * DateTime, Date the account will be unlocked
     */
    int64_t account_unlock_date() const { return m_account_unlock_date; }

    /**
     * String, Player name
     */
    string_t* player_name() const { return m_player_name.get(); }

    /**
     * Int, Number of beatmaps
     */
    int32_t num_beatmaps() const { return m_num_beatmaps; }

    /**
     * Beatmaps*, Aforementioned beatmaps
     */
    std::vector<std::unique_ptr<beatmap_t>>* beatmaps() const { return m_beatmaps.get(); }

    /**
     * Int, User permissions (0 = None, 1 = Normal, 2 = Moderator, 4 = Supporter, 8 = Friend, 16 = peppy, 32 = World Cup staff)
     */
    int32_t user_permissions() const { return m_user_permissions; }
    osu_db_t* _root() const { return m__root; }
    kaitai::kstruct* _parent() const { return m__parent; }
};
