// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

#include "osu_db.h"
#include "kaitai/exceptions.h"

osu_db_t::osu_db_t(kaitai::kstream* p__io, kaitai::kstruct* p__parent, osu_db_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = this;
    m_account_unlocked = nullptr;
    m_player_name = nullptr;
    m_beatmaps = nullptr;
    _read();
}

void osu_db_t::_read() {
    m_osu_version = m__io->read_s4le();
    m_folder_count = m__io->read_s4le();
    m_account_unlocked = std::unique_ptr<bool_t>(new bool_t(m__io, this, m__root));
    m_account_unlock_date = m__io->read_s8le();
    m_player_name = std::unique_ptr<string_t>(new string_t(m__io, this, m__root));
    m_num_beatmaps = m__io->read_s4le();
    int l_beatmaps = num_beatmaps();
    m_beatmaps = std::unique_ptr<std::vector<std::unique_ptr<beatmap_t>>>(new std::vector<std::unique_ptr<beatmap_t>>());
    m_beatmaps->reserve(l_beatmaps);
    for (int i = 0; i < l_beatmaps; i++) {
        m_beatmaps->push_back(std::move(std::unique_ptr<beatmap_t>(new beatmap_t(m__io, this, m__root))));
    }
    m_user_permissions = m__io->read_s4le();
}

osu_db_t::~osu_db_t() {
    _clean_up();
}

void osu_db_t::_clean_up() {
}

osu_db_t::timing_point_t::timing_point_t(kaitai::kstream* p__io, osu_db_t::timing_points_t* p__parent, osu_db_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    m_not_inherited = nullptr;
    _read();
}

void osu_db_t::timing_point_t::_read() {
    m_bpm = m__io->read_f8le();
    m_offset = m__io->read_f8le();
    m_not_inherited = std::unique_ptr<bool_t>(new bool_t(m__io, this, m__root));
}

osu_db_t::timing_point_t::~timing_point_t() {
    _clean_up();
}

void osu_db_t::timing_point_t::_clean_up() {
}

osu_db_t::string_t::string_t(kaitai::kstream* p__io, kaitai::kstruct* p__parent, osu_db_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    m_len_str = nullptr;
    _read();
}

void osu_db_t::string_t::_read() {
    m_is_present = m__io->read_s1();
    n_len_str = true;
    if (is_present() == 11) {
        n_len_str = false;
        m_len_str = std::unique_ptr<vlq_base128_le_t>(new vlq_base128_le_t(m__io));
    }
    n_value = true;
    if (is_present() == 11) {
        n_value = false;
        m_value = kaitai::kstream::bytes_to_str(m__io->read_bytes(len_str()->value()), std::string("UTF-8"));
    }
}

osu_db_t::string_t::~string_t() {
    _clean_up();
}

void osu_db_t::string_t::_clean_up() {
    if (!n_len_str) {
    }
    if (!n_value) {
    }
}

osu_db_t::beatmap_t::beatmap_t(kaitai::kstream* p__io, osu_db_t* p__parent, osu_db_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    m_artist_name = nullptr;
    m_artist_name_unicode = nullptr;
    m_song_title = nullptr;
    m_song_title_unicode = nullptr;
    m_creator_name = nullptr;
    m_difficulty = nullptr;
    m_audio_file_name = nullptr;
    m_md5_hash = nullptr;
    m_osu_file_name = nullptr;
    m_star_rating_osu = nullptr;
    m_star_rating_taiko = nullptr;
    m_star_rating_ctb = nullptr;
    m_star_rating_mania = nullptr;
    m_timing_points = nullptr;
    m_song_source = nullptr;
    m_song_tags = nullptr;
    m_song_title_font = nullptr;
    m_is_unplayed = nullptr;
    m_is_osz2 = nullptr;
    m_folder_name = nullptr;
    m_ignore_sound = nullptr;
    m_ignore_skin = nullptr;
    m_disable_storyboard = nullptr;
    m_disable_video = nullptr;
    m_visual_override = nullptr;
    _read();
}

void osu_db_t::beatmap_t::_read() {
    n_len_beatmap = true;
    if (_root()->osu_version() < 20191106) {
        n_len_beatmap = false;
        m_len_beatmap = m__io->read_s4le();
    }
    m_artist_name = std::unique_ptr<string_t>(new string_t(m__io, this, m__root));
    m_artist_name_unicode = std::unique_ptr<string_t>(new string_t(m__io, this, m__root));
    m_song_title = std::unique_ptr<string_t>(new string_t(m__io, this, m__root));
    m_song_title_unicode = std::unique_ptr<string_t>(new string_t(m__io, this, m__root));
    m_creator_name = std::unique_ptr<string_t>(new string_t(m__io, this, m__root));
    m_difficulty = std::unique_ptr<string_t>(new string_t(m__io, this, m__root));
    m_audio_file_name = std::unique_ptr<string_t>(new string_t(m__io, this, m__root));
    m_md5_hash = std::unique_ptr<string_t>(new string_t(m__io, this, m__root));
    m_osu_file_name = std::unique_ptr<string_t>(new string_t(m__io, this, m__root));
    m_ranked_status = m__io->read_s1();
    m_num_hitcircles = m__io->read_s2le();
    m_num_sliders = m__io->read_s2le();
    m_num_spinners = m__io->read_s2le();
    m_last_modification_time = m__io->read_s8le();
    n_approach_rate_byte = true;
    if (_root()->osu_version() < 20140609) {
        n_approach_rate_byte = false;
        m_approach_rate_byte = m__io->read_s1();
    }
    n_approach_rate = true;
    if (_root()->osu_version() >= 20140609) {
        n_approach_rate = false;
        m_approach_rate = m__io->read_f4le();
    }
    n_circle_size_byte = true;
    if (_root()->osu_version() < 20140609) {
        n_circle_size_byte = false;
        m_circle_size_byte = m__io->read_s1();
    }
    n_circle_size = true;
    if (_root()->osu_version() >= 20140609) {
        n_circle_size = false;
        m_circle_size = m__io->read_f4le();
    }
    n_hp_drain_byte = true;
    if (_root()->osu_version() < 20140609) {
        n_hp_drain_byte = false;
        m_hp_drain_byte = m__io->read_s1();
    }
    n_hp_drain = true;
    if (_root()->osu_version() >= 20140609) {
        n_hp_drain = false;
        m_hp_drain = m__io->read_f4le();
    }
    n_overall_difficulty_byte = true;
    if (_root()->osu_version() < 20140609) {
        n_overall_difficulty_byte = false;
        m_overall_difficulty_byte = m__io->read_s1();
    }
    n_overall_difficulty = true;
    if (_root()->osu_version() >= 20140609) {
        n_overall_difficulty = false;
        m_overall_difficulty = m__io->read_f4le();
    }
    m_slider_velocity = m__io->read_f8le();
    n_star_rating_osu = true;
    if (_root()->osu_version() >= 20140609) {
        n_star_rating_osu = false;
        m_star_rating_osu = std::unique_ptr<int_double_pairs_t>(new int_double_pairs_t(m__io, this, m__root));
    }
    n_star_rating_taiko = true;
    if (_root()->osu_version() >= 20140609) {
        n_star_rating_taiko = false;
        m_star_rating_taiko = std::unique_ptr<int_double_pairs_t>(new int_double_pairs_t(m__io, this, m__root));
    }
    n_star_rating_ctb = true;
    if (_root()->osu_version() >= 20140609) {
        n_star_rating_ctb = false;
        m_star_rating_ctb = std::unique_ptr<int_double_pairs_t>(new int_double_pairs_t(m__io, this, m__root));
    }
    n_star_rating_mania = true;
    if (_root()->osu_version() >= 20140609) {
        n_star_rating_mania = false;
        m_star_rating_mania = std::unique_ptr<int_double_pairs_t>(new int_double_pairs_t(m__io, this, m__root));
    }
    m_drain_time = m__io->read_s4le();
    m_total_time = m__io->read_s4le();
    m_audio_preview_start_time = m__io->read_s4le();
    m_timing_points = std::unique_ptr<timing_points_t>(new timing_points_t(m__io, this, m__root));
    m_beatmap_id = m__io->read_s4le();
    m_beatmap_set_id = m__io->read_s4le();
    m_thread_id = m__io->read_s4le();
    m_grade_osu = m__io->read_s1();
    m_grade_taiko = m__io->read_s1();
    m_grade_ctb = m__io->read_s1();
    m_grade_mania = m__io->read_s1();
    m_local_beatmap_offset = m__io->read_s2le();
    m_stack_leniency = m__io->read_f4le();
    m_gameplay_mode = m__io->read_s1();
    m_song_source = std::unique_ptr<string_t>(new string_t(m__io, this, m__root));
    m_song_tags = std::unique_ptr<string_t>(new string_t(m__io, this, m__root));
    m_online_offset = m__io->read_s2le();
    m_song_title_font = std::unique_ptr<string_t>(new string_t(m__io, this, m__root));
    m_is_unplayed = std::unique_ptr<bool_t>(new bool_t(m__io, this, m__root));
    m_last_played_time = m__io->read_s8le();
    m_is_osz2 = std::unique_ptr<bool_t>(new bool_t(m__io, this, m__root));
    m_folder_name = std::unique_ptr<string_t>(new string_t(m__io, this, m__root));
    m_last_check_repo_time = m__io->read_s8le();
    m_ignore_sound = std::unique_ptr<bool_t>(new bool_t(m__io, this, m__root));
    m_ignore_skin = std::unique_ptr<bool_t>(new bool_t(m__io, this, m__root));
    m_disable_storyboard = std::unique_ptr<bool_t>(new bool_t(m__io, this, m__root));
    m_disable_video = std::unique_ptr<bool_t>(new bool_t(m__io, this, m__root));
    m_visual_override = std::unique_ptr<bool_t>(new bool_t(m__io, this, m__root));
    n_unknown_short = true;
    if (_root()->osu_version() < 20140609) {
        n_unknown_short = false;
        m_unknown_short = m__io->read_s2le();
    }
    m_last_modification_time_int = m__io->read_s4le();
    m_mania_scroll_speed = m__io->read_s1();
}

osu_db_t::beatmap_t::~beatmap_t() {
    _clean_up();
}

void osu_db_t::beatmap_t::_clean_up() {
    if (!n_len_beatmap) {
    }
    if (!n_approach_rate_byte) {
    }
    if (!n_approach_rate) {
    }
    if (!n_circle_size_byte) {
    }
    if (!n_circle_size) {
    }
    if (!n_hp_drain_byte) {
    }
    if (!n_hp_drain) {
    }
    if (!n_overall_difficulty_byte) {
    }
    if (!n_overall_difficulty) {
    }
    if (!n_star_rating_osu) {
    }
    if (!n_star_rating_taiko) {
    }
    if (!n_star_rating_ctb) {
    }
    if (!n_star_rating_mania) {
    }
    if (!n_unknown_short) {
    }
}

osu_db_t::timing_points_t::timing_points_t(kaitai::kstream* p__io, osu_db_t::beatmap_t* p__parent, osu_db_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    m_points = nullptr;
    _read();
}

void osu_db_t::timing_points_t::_read() {
    m_num_points = m__io->read_s4le();
    int l_points = num_points();
    m_points = std::unique_ptr<std::vector<std::unique_ptr<timing_point_t>>>(new std::vector<std::unique_ptr<timing_point_t>>());
    m_points->reserve(l_points);
    for (int i = 0; i < l_points; i++) {
        m_points->push_back(std::move(std::unique_ptr<timing_point_t>(new timing_point_t(m__io, this, m__root))));
    }
}

osu_db_t::timing_points_t::~timing_points_t() {
    _clean_up();
}

void osu_db_t::timing_points_t::_clean_up() {
}

osu_db_t::bool_t::bool_t(kaitai::kstream* p__io, kaitai::kstruct* p__parent, osu_db_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    f_value = false;
    _read();
}

void osu_db_t::bool_t::_read() {
    m_byte = m__io->read_s1();
}

osu_db_t::bool_t::~bool_t() {
    _clean_up();
}

void osu_db_t::bool_t::_clean_up() {
}

bool osu_db_t::bool_t::value() {
    if (f_value)
        return m_value;
    m_value = ((byte() == 0) ? (false) : (true));
    f_value = true;
    return m_value;
}

osu_db_t::int_double_pair_t::int_double_pair_t(kaitai::kstream* p__io, osu_db_t::int_double_pairs_t* p__parent, osu_db_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    _read();
}

void osu_db_t::int_double_pair_t::_read() {
    m_magic1 = m__io->read_bytes(1);
    if (!(magic1() == std::string("\x08", 1))) {
        throw kaitai::validation_not_equal_error<std::string>(std::string("\x08", 1), magic1(), _io(), std::string("/types/int_double_pair/seq/0"));
    }
    m_int = m__io->read_s4le();
    m_magic2 = m__io->read_bytes(1);
    if (!(magic2() == std::string("\x0D", 1))) {
        throw kaitai::validation_not_equal_error<std::string>(std::string("\x0D", 1), magic2(), _io(), std::string("/types/int_double_pair/seq/2"));
    }
    m_double = m__io->read_f8le();
}

osu_db_t::int_double_pair_t::~int_double_pair_t() {
    _clean_up();
}

void osu_db_t::int_double_pair_t::_clean_up() {
}

osu_db_t::int_double_pairs_t::int_double_pairs_t(kaitai::kstream* p__io, osu_db_t::beatmap_t* p__parent, osu_db_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    m_pairs = nullptr;
    _read();
}

void osu_db_t::int_double_pairs_t::_read() {
    m_num_pairs = m__io->read_s4le();
    int l_pairs = num_pairs();
    m_pairs = std::unique_ptr<std::vector<std::unique_ptr<int_double_pair_t>>>(new std::vector<std::unique_ptr<int_double_pair_t>>());
    m_pairs->reserve(l_pairs);
    for (int i = 0; i < l_pairs; i++) {
        m_pairs->push_back(std::move(std::unique_ptr<int_double_pair_t>(new int_double_pair_t(m__io, this, m__root))));
    }
}

osu_db_t::int_double_pairs_t::~int_double_pairs_t() {
    _clean_up();
}

void osu_db_t::int_double_pairs_t::_clean_up() {
}
