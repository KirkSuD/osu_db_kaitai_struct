// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

import (
	"github.com/kaitai-io/kaitai_struct_go_runtime/kaitai"
	"bytes"
)


/**
 * osu!.db file format in rhythm game, osu!.
 * @see <a href="https://osu.ppy.sh/wiki/zh-tw/osu%21_File_Formats/Db_%28file_format%29">Source</a>
 */
type OsuDb struct {
	OsuVersion int32
	FolderCount int32
	AccountUnlocked *OsuDb_Bool
	AccountUnlockDate int64
	PlayerName *OsuDb_String
	NumBeatmaps int32
	Beatmaps []*OsuDb_Beatmap
	UserPermissions int32
	_io *kaitai.Stream
	_root *OsuDb
	_parent interface{}
}
func NewOsuDb() *OsuDb {
	return &OsuDb{
	}
}

func (this *OsuDb) Read(io *kaitai.Stream, parent interface{}, root *OsuDb) (err error) {
	this._io = io
	this._parent = parent
	this._root = root

	tmp1, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.OsuVersion = int32(tmp1)
	tmp2, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.FolderCount = int32(tmp2)
	tmp3 := NewOsuDb_Bool()
	err = tmp3.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.AccountUnlocked = tmp3
	tmp4, err := this._io.ReadS8le()
	if err != nil {
		return err
	}
	this.AccountUnlockDate = int64(tmp4)
	tmp5 := NewOsuDb_String()
	err = tmp5.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.PlayerName = tmp5
	tmp6, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.NumBeatmaps = int32(tmp6)
	this.Beatmaps = make([]*OsuDb_Beatmap, this.NumBeatmaps)
	for i := range this.Beatmaps {
		tmp7 := NewOsuDb_Beatmap()
		err = tmp7.Read(this._io, this, this._root)
		if err != nil {
			return err
		}
		this.Beatmaps[i] = tmp7
	}
	tmp8, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.UserPermissions = int32(tmp8)
	return err
}

/**
 * Int, osu! version (e.g. 20150203)
 */

/**
 * Int, Folder Count
 */

/**
 * Bool, AccountUnlocked (only false when the account is locked or banned in any way)
 */

/**
 * DateTime, Date the account will be unlocked
 */

/**
 * String, Player name
 */

/**
 * Int, Number of beatmaps
 */

/**
 * Beatmaps*, Aforementioned beatmaps
 */

/**
 * Int, User permissions (0 = None, 1 = Normal, 2 = Moderator, 4 = Supporter, 8 = Friend, 16 = peppy, 32 = World Cup staff)
 */

/**
 * Consists of a Double, signifying the BPM, another Double,
 * signifying the offset into the song, in milliseconds, and a Boolean;
 * if false, then this timing point is inherited.
 * See Osu (file format) for more information regarding timing points.
 */
type OsuDb_TimingPoint struct {
	Bpm float64
	Offset float64
	NotInherited *OsuDb_Bool
	_io *kaitai.Stream
	_root *OsuDb
	_parent *OsuDb_TimingPoints
}
func NewOsuDb_TimingPoint() *OsuDb_TimingPoint {
	return &OsuDb_TimingPoint{
	}
}

func (this *OsuDb_TimingPoint) Read(io *kaitai.Stream, parent *OsuDb_TimingPoints, root *OsuDb) (err error) {
	this._io = io
	this._parent = parent
	this._root = root

	tmp9, err := this._io.ReadF8le()
	if err != nil {
		return err
	}
	this.Bpm = float64(tmp9)
	tmp10, err := this._io.ReadF8le()
	if err != nil {
		return err
	}
	this.Offset = float64(tmp10)
	tmp11 := NewOsuDb_Bool()
	err = tmp11.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.NotInherited = tmp11
	return err
}
type OsuDb_String struct {
	IsPresent int8
	LenStr *VlqBase128Le
	Value string
	_io *kaitai.Stream
	_root *OsuDb
	_parent interface{}
}
func NewOsuDb_String() *OsuDb_String {
	return &OsuDb_String{
	}
}

func (this *OsuDb_String) Read(io *kaitai.Stream, parent interface{}, root *OsuDb) (err error) {
	this._io = io
	this._parent = parent
	this._root = root

	tmp12, err := this._io.ReadS1()
	if err != nil {
		return err
	}
	this.IsPresent = tmp12
	if (this.IsPresent == 11) {
		tmp13 := NewVlqBase128Le()
		err = tmp13.Read(this._io, this, nil)
		if err != nil {
			return err
		}
		this.LenStr = tmp13
	}
	if (this.IsPresent == 11) {
		tmp14, err := this.LenStr.Value()
		if err != nil {
			return err
		}
		tmp15, err := this._io.ReadBytes(int(tmp14))
		if err != nil {
			return err
		}
		tmp15 = tmp15
		this.Value = string(tmp15)
	}
	return err
}
type OsuDb_Beatmap struct {
	LenBeatmap int32
	ArtistName *OsuDb_String
	ArtistNameUnicode *OsuDb_String
	SongTitle *OsuDb_String
	SongTitleUnicode *OsuDb_String
	CreatorName *OsuDb_String
	Difficulty *OsuDb_String
	AudioFileName *OsuDb_String
	Md5Hash *OsuDb_String
	OsuFileName *OsuDb_String
	RankedStatus int8
	NumHitcircles int16
	NumSliders int16
	NumSpinners int16
	LastModificationTime int64
	ApproachRateByte int8
	ApproachRate float32
	CircleSizeByte int8
	CircleSize float32
	HpDrainByte int8
	HpDrain float32
	OverallDifficultyByte int8
	OverallDifficulty float32
	SliderVelocity float64
	StarRatingOsu *OsuDb_IntDoublePairs
	StarRatingTaiko *OsuDb_IntDoublePairs
	StarRatingCtb *OsuDb_IntDoublePairs
	StarRatingMania *OsuDb_IntDoublePairs
	DrainTime int32
	TotalTime int32
	AudioPreviewStartTime int32
	TimingPoints *OsuDb_TimingPoints
	BeatmapId int32
	BeatmapSetId int32
	ThreadId int32
	GradeOsu int8
	GradeTaiko int8
	GradeCtb int8
	GradeMania int8
	LocalBeatmapOffset int16
	StackLeniency float32
	GameplayMode int8
	SongSource *OsuDb_String
	SongTags *OsuDb_String
	OnlineOffset int16
	SongTitleFont *OsuDb_String
	IsUnplayed *OsuDb_Bool
	LastPlayedTime int64
	IsOsz2 *OsuDb_Bool
	FolderName *OsuDb_String
	LastCheckRepoTime int64
	IgnoreSound *OsuDb_Bool
	IgnoreSkin *OsuDb_Bool
	DisableStoryboard *OsuDb_Bool
	DisableVideo *OsuDb_Bool
	VisualOverride *OsuDb_Bool
	UnknownShort int16
	LastModificationTimeInt int32
	ManiaScrollSpeed int8
	_io *kaitai.Stream
	_root *OsuDb
	_parent *OsuDb
}
func NewOsuDb_Beatmap() *OsuDb_Beatmap {
	return &OsuDb_Beatmap{
	}
}

func (this *OsuDb_Beatmap) Read(io *kaitai.Stream, parent *OsuDb, root *OsuDb) (err error) {
	this._io = io
	this._parent = parent
	this._root = root

	if (this._root.OsuVersion < 20191106) {
		tmp16, err := this._io.ReadS4le()
		if err != nil {
			return err
		}
		this.LenBeatmap = int32(tmp16)
	}
	tmp17 := NewOsuDb_String()
	err = tmp17.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.ArtistName = tmp17
	tmp18 := NewOsuDb_String()
	err = tmp18.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.ArtistNameUnicode = tmp18
	tmp19 := NewOsuDb_String()
	err = tmp19.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.SongTitle = tmp19
	tmp20 := NewOsuDb_String()
	err = tmp20.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.SongTitleUnicode = tmp20
	tmp21 := NewOsuDb_String()
	err = tmp21.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.CreatorName = tmp21
	tmp22 := NewOsuDb_String()
	err = tmp22.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.Difficulty = tmp22
	tmp23 := NewOsuDb_String()
	err = tmp23.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.AudioFileName = tmp23
	tmp24 := NewOsuDb_String()
	err = tmp24.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.Md5Hash = tmp24
	tmp25 := NewOsuDb_String()
	err = tmp25.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.OsuFileName = tmp25
	tmp26, err := this._io.ReadS1()
	if err != nil {
		return err
	}
	this.RankedStatus = tmp26
	tmp27, err := this._io.ReadS2le()
	if err != nil {
		return err
	}
	this.NumHitcircles = int16(tmp27)
	tmp28, err := this._io.ReadS2le()
	if err != nil {
		return err
	}
	this.NumSliders = int16(tmp28)
	tmp29, err := this._io.ReadS2le()
	if err != nil {
		return err
	}
	this.NumSpinners = int16(tmp29)
	tmp30, err := this._io.ReadS8le()
	if err != nil {
		return err
	}
	this.LastModificationTime = int64(tmp30)
	if (this._root.OsuVersion < 20140609) {
		tmp31, err := this._io.ReadS1()
		if err != nil {
			return err
		}
		this.ApproachRateByte = tmp31
	}
	if (this._root.OsuVersion >= 20140609) {
		tmp32, err := this._io.ReadF4le()
		if err != nil {
			return err
		}
		this.ApproachRate = float32(tmp32)
	}
	if (this._root.OsuVersion < 20140609) {
		tmp33, err := this._io.ReadS1()
		if err != nil {
			return err
		}
		this.CircleSizeByte = tmp33
	}
	if (this._root.OsuVersion >= 20140609) {
		tmp34, err := this._io.ReadF4le()
		if err != nil {
			return err
		}
		this.CircleSize = float32(tmp34)
	}
	if (this._root.OsuVersion < 20140609) {
		tmp35, err := this._io.ReadS1()
		if err != nil {
			return err
		}
		this.HpDrainByte = tmp35
	}
	if (this._root.OsuVersion >= 20140609) {
		tmp36, err := this._io.ReadF4le()
		if err != nil {
			return err
		}
		this.HpDrain = float32(tmp36)
	}
	if (this._root.OsuVersion < 20140609) {
		tmp37, err := this._io.ReadS1()
		if err != nil {
			return err
		}
		this.OverallDifficultyByte = tmp37
	}
	if (this._root.OsuVersion >= 20140609) {
		tmp38, err := this._io.ReadF4le()
		if err != nil {
			return err
		}
		this.OverallDifficulty = float32(tmp38)
	}
	tmp39, err := this._io.ReadF8le()
	if err != nil {
		return err
	}
	this.SliderVelocity = float64(tmp39)
	if (this._root.OsuVersion >= 20140609) {
		tmp40 := NewOsuDb_IntDoublePairs()
		err = tmp40.Read(this._io, this, this._root)
		if err != nil {
			return err
		}
		this.StarRatingOsu = tmp40
	}
	if (this._root.OsuVersion >= 20140609) {
		tmp41 := NewOsuDb_IntDoublePairs()
		err = tmp41.Read(this._io, this, this._root)
		if err != nil {
			return err
		}
		this.StarRatingTaiko = tmp41
	}
	if (this._root.OsuVersion >= 20140609) {
		tmp42 := NewOsuDb_IntDoublePairs()
		err = tmp42.Read(this._io, this, this._root)
		if err != nil {
			return err
		}
		this.StarRatingCtb = tmp42
	}
	if (this._root.OsuVersion >= 20140609) {
		tmp43 := NewOsuDb_IntDoublePairs()
		err = tmp43.Read(this._io, this, this._root)
		if err != nil {
			return err
		}
		this.StarRatingMania = tmp43
	}
	tmp44, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.DrainTime = int32(tmp44)
	tmp45, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.TotalTime = int32(tmp45)
	tmp46, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.AudioPreviewStartTime = int32(tmp46)
	tmp47 := NewOsuDb_TimingPoints()
	err = tmp47.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.TimingPoints = tmp47
	tmp48, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.BeatmapId = int32(tmp48)
	tmp49, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.BeatmapSetId = int32(tmp49)
	tmp50, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.ThreadId = int32(tmp50)
	tmp51, err := this._io.ReadS1()
	if err != nil {
		return err
	}
	this.GradeOsu = tmp51
	tmp52, err := this._io.ReadS1()
	if err != nil {
		return err
	}
	this.GradeTaiko = tmp52
	tmp53, err := this._io.ReadS1()
	if err != nil {
		return err
	}
	this.GradeCtb = tmp53
	tmp54, err := this._io.ReadS1()
	if err != nil {
		return err
	}
	this.GradeMania = tmp54
	tmp55, err := this._io.ReadS2le()
	if err != nil {
		return err
	}
	this.LocalBeatmapOffset = int16(tmp55)
	tmp56, err := this._io.ReadF4le()
	if err != nil {
		return err
	}
	this.StackLeniency = float32(tmp56)
	tmp57, err := this._io.ReadS1()
	if err != nil {
		return err
	}
	this.GameplayMode = tmp57
	tmp58 := NewOsuDb_String()
	err = tmp58.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.SongSource = tmp58
	tmp59 := NewOsuDb_String()
	err = tmp59.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.SongTags = tmp59
	tmp60, err := this._io.ReadS2le()
	if err != nil {
		return err
	}
	this.OnlineOffset = int16(tmp60)
	tmp61 := NewOsuDb_String()
	err = tmp61.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.SongTitleFont = tmp61
	tmp62 := NewOsuDb_Bool()
	err = tmp62.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.IsUnplayed = tmp62
	tmp63, err := this._io.ReadS8le()
	if err != nil {
		return err
	}
	this.LastPlayedTime = int64(tmp63)
	tmp64 := NewOsuDb_Bool()
	err = tmp64.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.IsOsz2 = tmp64
	tmp65 := NewOsuDb_String()
	err = tmp65.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.FolderName = tmp65
	tmp66, err := this._io.ReadS8le()
	if err != nil {
		return err
	}
	this.LastCheckRepoTime = int64(tmp66)
	tmp67 := NewOsuDb_Bool()
	err = tmp67.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.IgnoreSound = tmp67
	tmp68 := NewOsuDb_Bool()
	err = tmp68.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.IgnoreSkin = tmp68
	tmp69 := NewOsuDb_Bool()
	err = tmp69.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.DisableStoryboard = tmp69
	tmp70 := NewOsuDb_Bool()
	err = tmp70.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.DisableVideo = tmp70
	tmp71 := NewOsuDb_Bool()
	err = tmp71.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.VisualOverride = tmp71
	if (this._root.OsuVersion < 20140609) {
		tmp72, err := this._io.ReadS2le()
		if err != nil {
			return err
		}
		this.UnknownShort = int16(tmp72)
	}
	tmp73, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.LastModificationTimeInt = int32(tmp73)
	tmp74, err := this._io.ReadS1()
	if err != nil {
		return err
	}
	this.ManiaScrollSpeed = tmp74
	return err
}

/**
 * Int,	Size in bytes of the beatmap entry. Only present if version is less than 20191106.
 */

/**
 * String, Artist name
 */

/**
 * String, Artist name, in Unicode
 */

/**
 * String, Song title
 */

/**
 * String, Song title, in Unicode
 */

/**
 * String, Creator name
 */

/**
 * String, Difficulty (e.g. Hard, Insane, etc.)
 */

/**
 * String, Audio file name
 */

/**
 * String, MD5 hash of the beatmap
 */

/**
 * String, Name of the .osu file corresponding to this beatmap
 */

/**
 * Byte, Ranked status (0 = unknown, 1 = unsubmitted, 2 = pending/wip/graveyard, 3 = unused, 4 = ranked, 5 = approved, 6 = qualified, 7 = loved)
 */

/**
 * Short, Number of hitcircles
 */

/**
 * Short, Number of sliders (note: this will be present in every mode)
 */

/**
 * Short, Number of spinners (note: this will be present in every mode)
 */

/**
 * Long, Last modification time, Windows ticks.
 */

/**
 * Byte/Single, Approach rate. Byte if the version is less than 20140609, Single otherwise.
 */

/**
 * Byte/Single, Approach rate. Byte if the version is less than 20140609, Single otherwise.
 */

/**
 * Byte/Single, Circle size. Byte if the version is less than 20140609, Single otherwise.
 */

/**
 * Byte/Single, Circle size. Byte if the version is less than 20140609, Single otherwise.
 */

/**
 * Byte/Single, HP drain. Byte if the version is less than 20140609, Single otherwise.
 */

/**
 * Byte/Single, HP drain. Byte if the version is less than 20140609, Single otherwise.
 */

/**
 * Byte/Single, Overall difficulty. Byte if the version is less than 20140609, Single otherwise.
 */

/**
 * Byte/Single, Overall difficulty. Byte if the version is less than 20140609, Single otherwise.
 */

/**
 * Double, Slider velocity
 */

/**
 * Int-Double pair*, Star Rating info for osu! standard, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
 */

/**
 * Int-Double pair*, Star Rating info for Taiko, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
 */

/**
 * Int-Double pair*, Star Rating info for CTB, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
 */

/**
 * Int-Double pair*, Star Rating info for osu!mania, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
 */

/**
 * Int, Drain time, in seconds
 */

/**
 * Int, Total time, in milliseconds
 */

/**
 * Int, Time when the audio preview when hovering over a beatmap in beatmap select starts, in milliseconds.
 */

/**
 * Timing point+, An Int indicating the number of following Timing points, then the aforementioned Timing points.
 */

/**
 * Int, Beatmap ID
 */

/**
 * Int, Beatmap set ID
 */

/**
 * Int, Thread ID
 */

/**
 * Byte, Grade achieved in osu! standard.
 */

/**
 * Byte, Grade achieved in Taiko.
 */

/**
 * Byte, Grade achieved in CTB.
 */

/**
 * Byte, Grade achieved in osu!mania.
 */

/**
 * Short, Local beatmap offset
 */

/**
 * Single, Stack leniency
 */

/**
 * Byte, Osu gameplay mode. 0x00 = osu!Standard, 0x01 = Taiko, 0x02 = CTB, 0x03 = Mania
 */

/**
 * String, Song source
 */

/**
 * String, Song tags
 */

/**
 * Short, Online offset
 */

/**
 * String, Font used for the title of the song
 */

/**
 * Boolean, Is beatmap unplayed
 */

/**
 * Long, Last time when beatmap was played
 */

/**
 * Boolean, Is the beatmap osz2
 */

/**
 * String, Folder name of the beatmap, relative to Songs folder
 */

/**
 * Long, Last time when beatmap was checked against osu! repository
 */

/**
 * Boolean, Ignore beatmap sound
 */

/**
 * Boolean, Ignore beatmap skin
 */

/**
 * Boolean, Disable storyboard
 */

/**
 * Boolean, Disable video
 */

/**
 * Boolean, Visual override
 */

/**
 * Short?, Unknown. Only present if version is less than 20140609.
 */

/**
 * Int, Last modification time (?)
 */

/**
 * Byte, Mania scroll speed
 */

/**
 * An Int indicating the number of following Timing points, then the aforementioned Timing points.
 */
type OsuDb_TimingPoints struct {
	NumPoints int32
	Points []*OsuDb_TimingPoint
	_io *kaitai.Stream
	_root *OsuDb
	_parent *OsuDb_Beatmap
}
func NewOsuDb_TimingPoints() *OsuDb_TimingPoints {
	return &OsuDb_TimingPoints{
	}
}

func (this *OsuDb_TimingPoints) Read(io *kaitai.Stream, parent *OsuDb_Beatmap, root *OsuDb) (err error) {
	this._io = io
	this._parent = parent
	this._root = root

	tmp75, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.NumPoints = int32(tmp75)
	this.Points = make([]*OsuDb_TimingPoint, this.NumPoints)
	for i := range this.Points {
		tmp76 := NewOsuDb_TimingPoint()
		err = tmp76.Read(this._io, this, this._root)
		if err != nil {
			return err
		}
		this.Points[i] = tmp76
	}
	return err
}
type OsuDb_Bool struct {
	Byte int8
	_io *kaitai.Stream
	_root *OsuDb
	_parent interface{}
	_f_value bool
	value bool
}
func NewOsuDb_Bool() *OsuDb_Bool {
	return &OsuDb_Bool{
	}
}

func (this *OsuDb_Bool) Read(io *kaitai.Stream, parent interface{}, root *OsuDb) (err error) {
	this._io = io
	this._parent = parent
	this._root = root

	tmp77, err := this._io.ReadS1()
	if err != nil {
		return err
	}
	this.Byte = tmp77
	return err
}
func (this *OsuDb_Bool) Value() (v bool, err error) {
	if (this._f_value) {
		return this.value, nil
	}
	var tmp78 bool;
	if (this.Byte == 0) {
		tmp78 = false
	} else {
		tmp78 = true
	}
	this.value = bool(tmp78)
	this._f_value = true
	return this.value, nil
}

/**
 * The first byte is 0x08, followed by an Int, then 0x0d, followed by a Double.
 * These extraneous bytes are presumably flags to signify different data types
 * in these slots, though in practice no other such flags have been seen.
 * Currently the purpose of this data type is unknown.
 */
type OsuDb_IntDoublePair struct {
	Magic1 []byte
	Int int32
	Magic2 []byte
	Double float64
	_io *kaitai.Stream
	_root *OsuDb
	_parent *OsuDb_IntDoublePairs
}
func NewOsuDb_IntDoublePair() *OsuDb_IntDoublePair {
	return &OsuDb_IntDoublePair{
	}
}

func (this *OsuDb_IntDoublePair) Read(io *kaitai.Stream, parent *OsuDb_IntDoublePairs, root *OsuDb) (err error) {
	this._io = io
	this._parent = parent
	this._root = root

	tmp79, err := this._io.ReadBytes(int(1))
	if err != nil {
		return err
	}
	tmp79 = tmp79
	this.Magic1 = tmp79
	if !(bytes.Equal(this.Magic1, []uint8{8})) {
		return kaitai.NewValidationNotEqualError([]uint8{8}, this.Magic1, this._io, "/types/int_double_pair/seq/0")
	}
	tmp80, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.Int = int32(tmp80)
	tmp81, err := this._io.ReadBytes(int(1))
	if err != nil {
		return err
	}
	tmp81 = tmp81
	this.Magic2 = tmp81
	if !(bytes.Equal(this.Magic2, []uint8{13})) {
		return kaitai.NewValidationNotEqualError([]uint8{13}, this.Magic2, this._io, "/types/int_double_pair/seq/2")
	}
	tmp82, err := this._io.ReadF8le()
	if err != nil {
		return err
	}
	this.Double = float64(tmp82)
	return err
}

/**
 * An Int indicating the number of following Int-Double pairs, then the aforementioned pairs.
 */
type OsuDb_IntDoublePairs struct {
	NumPairs int32
	Pairs []*OsuDb_IntDoublePair
	_io *kaitai.Stream
	_root *OsuDb
	_parent *OsuDb_Beatmap
}
func NewOsuDb_IntDoublePairs() *OsuDb_IntDoublePairs {
	return &OsuDb_IntDoublePairs{
	}
}

func (this *OsuDb_IntDoublePairs) Read(io *kaitai.Stream, parent *OsuDb_Beatmap, root *OsuDb) (err error) {
	this._io = io
	this._parent = parent
	this._root = root

	tmp83, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.NumPairs = int32(tmp83)
	this.Pairs = make([]*OsuDb_IntDoublePair, this.NumPairs)
	for i := range this.Pairs {
		tmp84 := NewOsuDb_IntDoublePair()
		err = tmp84.Read(this._io, this, this._root)
		if err != nil {
			return err
		}
		this.Pairs[i] = tmp84
	}
	return err
}
