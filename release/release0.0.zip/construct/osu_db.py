from construct import *
from construct.lib import *

osu_db__timing_point = Struct(
	'bpm' / Float64l,
	'offset' / Float64l,
	'not_inherited' / LazyBound(lambda: osu_db__bool),
)

osu_db__string = Struct(
	'is_present' / Int8sb,
	'len_str' / If(this.is_present == 11, LazyBound(lambda: vlq_base128_le)),
	'value' / If(this.is_present == 11, FixedSized(this.len_str.value, GreedyString(encoding='UTF-8'))),
)

osu_db__beatmap = Struct(
	'len_beatmap' / If(this._root.osu_version < 20191106, Int32sl),
	'artist_name' / LazyBound(lambda: osu_db__string),
	'artist_name_unicode' / LazyBound(lambda: osu_db__string),
	'song_title' / LazyBound(lambda: osu_db__string),
	'song_title_unicode' / LazyBound(lambda: osu_db__string),
	'creator_name' / LazyBound(lambda: osu_db__string),
	'difficulty' / LazyBound(lambda: osu_db__string),
	'audio_file_name' / LazyBound(lambda: osu_db__string),
	'md5_hash' / LazyBound(lambda: osu_db__string),
	'osu_file_name' / LazyBound(lambda: osu_db__string),
	'ranked_status' / Int8sb,
	'num_hitcircles' / Int16sl,
	'num_sliders' / Int16sl,
	'num_spinners' / Int16sl,
	'last_modification_time' / Int64sl,
	'approach_rate_byte' / If(this._root.osu_version < 20140609, Int8sb),
	'approach_rate' / If(this._root.osu_version >= 20140609, Float32l),
	'circle_size_byte' / If(this._root.osu_version < 20140609, Int8sb),
	'circle_size' / If(this._root.osu_version >= 20140609, Float32l),
	'hp_drain_byte' / If(this._root.osu_version < 20140609, Int8sb),
	'hp_drain' / If(this._root.osu_version >= 20140609, Float32l),
	'overall_difficulty_byte' / If(this._root.osu_version < 20140609, Int8sb),
	'overall_difficulty' / If(this._root.osu_version >= 20140609, Float32l),
	'slider_velocity' / Float64l,
	'star_rating_osu' / If(this._root.osu_version >= 20140609, LazyBound(lambda: osu_db__int_double_pairs)),
	'star_rating_taiko' / If(this._root.osu_version >= 20140609, LazyBound(lambda: osu_db__int_double_pairs)),
	'star_rating_ctb' / If(this._root.osu_version >= 20140609, LazyBound(lambda: osu_db__int_double_pairs)),
	'star_rating_mania' / If(this._root.osu_version >= 20140609, LazyBound(lambda: osu_db__int_double_pairs)),
	'drain_time' / Int32sl,
	'total_time' / Int32sl,
	'audio_preview_start_time' / Int32sl,
	'timing_points' / LazyBound(lambda: osu_db__timing_points),
	'beatmap_id' / Int32sl,
	'beatmap_set_id' / Int32sl,
	'thread_id' / Int32sl,
	'grade_osu' / Int8sb,
	'grade_taiko' / Int8sb,
	'grade_ctb' / Int8sb,
	'grade_mania' / Int8sb,
	'local_beatmap_offset' / Int16sl,
	'stack_leniency' / Float32l,
	'gameplay_mode' / Int8sb,
	'song_source' / LazyBound(lambda: osu_db__string),
	'song_tags' / LazyBound(lambda: osu_db__string),
	'online_offset' / Int16sl,
	'song_title_font' / LazyBound(lambda: osu_db__string),
	'is_unplayed' / LazyBound(lambda: osu_db__bool),
	'last_played_time' / Int64sl,
	'is_osz2' / LazyBound(lambda: osu_db__bool),
	'folder_name' / LazyBound(lambda: osu_db__string),
	'last_check_repo_time' / Int64sl,
	'ignore_sound' / LazyBound(lambda: osu_db__bool),
	'ignore_skin' / LazyBound(lambda: osu_db__bool),
	'disable_storyboard' / LazyBound(lambda: osu_db__bool),
	'disable_video' / LazyBound(lambda: osu_db__bool),
	'visual_override' / LazyBound(lambda: osu_db__bool),
	'unknown_short' / If(this._root.osu_version < 20140609, Int16sl),
	'last_modification_time_int' / Int32sl,
	'mania_scroll_speed' / Int8sb,
)

osu_db__timing_points = Struct(
	'num_points' / Int32sl,
	'points' / Array(this.num_points, LazyBound(lambda: osu_db__timing_point)),
)

osu_db__bool = Struct(
	'byte' / Int8sb,
	'value' / Computed(lambda this: (False if this.byte == 0 else True)),
)

osu_db__int_double_pair = Struct(
	'magic1' / FixedSized(1, GreedyBytes),
	'int' / Int32sl,
	'magic2' / FixedSized(1, GreedyBytes),
	'double' / Float64l,
)

osu_db__int_double_pairs = Struct(
	'num_pairs' / Int32sl,
	'pairs' / Array(this.num_pairs, LazyBound(lambda: osu_db__int_double_pair)),
)

osu_db = Struct(
	'osu_version' / Int32sl,
	'folder_count' / Int32sl,
	'account_unlocked' / LazyBound(lambda: osu_db__bool),
	'account_unlock_date' / Int64sl,
	'player_name' / LazyBound(lambda: osu_db__string),
	'num_beatmaps' / Int32sl,
	'beatmaps' / Array(this.num_beatmaps, LazyBound(lambda: osu_db__beatmap)),
	'user_permissions' / Int32sl,
)

_schema = osu_db
