# This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

use strict;
use warnings;
use IO::KaitaiStruct 0.009_000;
use Encode;
use VlqBase128Le;

########################################################################
package OsuDb;

our @ISA = 'IO::KaitaiStruct::Struct';

sub from_file {
    my ($class, $filename) = @_;
    my $fd;

    open($fd, '<', $filename) or return undef;
    binmode($fd);
    return new($class, IO::KaitaiStruct::Stream->new($fd));
}

sub new {
    my ($class, $_io, $_parent, $_root) = @_;
    my $self = IO::KaitaiStruct::Struct->new($_io);

    bless $self, $class;
    $self->{_parent} = $_parent;
    $self->{_root} = $_root || $self;;

    $self->_read();

    return $self;
}

sub _read {
    my ($self) = @_;

    $self->{osu_version} = $self->{_io}->read_s4le();
    $self->{folder_count} = $self->{_io}->read_s4le();
    $self->{account_unlocked} = OsuDb::Bool->new($self->{_io}, $self, $self->{_root});
    $self->{account_unlock_date} = $self->{_io}->read_s8le();
    $self->{player_name} = OsuDb::String->new($self->{_io}, $self, $self->{_root});
    $self->{num_beatmaps} = $self->{_io}->read_s4le();
    $self->{beatmaps} = ();
    my $n_beatmaps = $self->num_beatmaps();
    for (my $i = 0; $i < $n_beatmaps; $i++) {
        $self->{beatmaps}[$i] = OsuDb::Beatmap->new($self->{_io}, $self, $self->{_root});
    }
    $self->{user_permissions} = $self->{_io}->read_s4le();
}

sub osu_version {
    my ($self) = @_;
    return $self->{osu_version};
}

sub folder_count {
    my ($self) = @_;
    return $self->{folder_count};
}

sub account_unlocked {
    my ($self) = @_;
    return $self->{account_unlocked};
}

sub account_unlock_date {
    my ($self) = @_;
    return $self->{account_unlock_date};
}

sub player_name {
    my ($self) = @_;
    return $self->{player_name};
}

sub num_beatmaps {
    my ($self) = @_;
    return $self->{num_beatmaps};
}

sub beatmaps {
    my ($self) = @_;
    return $self->{beatmaps};
}

sub user_permissions {
    my ($self) = @_;
    return $self->{user_permissions};
}

########################################################################
package OsuDb::TimingPoint;

our @ISA = 'IO::KaitaiStruct::Struct';

sub from_file {
    my ($class, $filename) = @_;
    my $fd;

    open($fd, '<', $filename) or return undef;
    binmode($fd);
    return new($class, IO::KaitaiStruct::Stream->new($fd));
}

sub new {
    my ($class, $_io, $_parent, $_root) = @_;
    my $self = IO::KaitaiStruct::Struct->new($_io);

    bless $self, $class;
    $self->{_parent} = $_parent;
    $self->{_root} = $_root || $self;;

    $self->_read();

    return $self;
}

sub _read {
    my ($self) = @_;

    $self->{bpm} = $self->{_io}->read_f8le();
    $self->{offset} = $self->{_io}->read_f8le();
    $self->{not_inherited} = OsuDb::Bool->new($self->{_io}, $self, $self->{_root});
}

sub bpm {
    my ($self) = @_;
    return $self->{bpm};
}

sub offset {
    my ($self) = @_;
    return $self->{offset};
}

sub not_inherited {
    my ($self) = @_;
    return $self->{not_inherited};
}

########################################################################
package OsuDb::String;

our @ISA = 'IO::KaitaiStruct::Struct';

sub from_file {
    my ($class, $filename) = @_;
    my $fd;

    open($fd, '<', $filename) or return undef;
    binmode($fd);
    return new($class, IO::KaitaiStruct::Stream->new($fd));
}

sub new {
    my ($class, $_io, $_parent, $_root) = @_;
    my $self = IO::KaitaiStruct::Struct->new($_io);

    bless $self, $class;
    $self->{_parent} = $_parent;
    $self->{_root} = $_root || $self;;

    $self->_read();

    return $self;
}

sub _read {
    my ($self) = @_;

    $self->{is_present} = $self->{_io}->read_s1();
    if ($self->is_present() == 11) {
        $self->{len_str} = VlqBase128Le->new($self->{_io});
    }
    if ($self->is_present() == 11) {
        $self->{value} = Encode::decode("UTF-8", $self->{_io}->read_bytes($self->len_str()->value()));
    }
}

sub is_present {
    my ($self) = @_;
    return $self->{is_present};
}

sub len_str {
    my ($self) = @_;
    return $self->{len_str};
}

sub value {
    my ($self) = @_;
    return $self->{value};
}

########################################################################
package OsuDb::Beatmap;

our @ISA = 'IO::KaitaiStruct::Struct';

sub from_file {
    my ($class, $filename) = @_;
    my $fd;

    open($fd, '<', $filename) or return undef;
    binmode($fd);
    return new($class, IO::KaitaiStruct::Stream->new($fd));
}

sub new {
    my ($class, $_io, $_parent, $_root) = @_;
    my $self = IO::KaitaiStruct::Struct->new($_io);

    bless $self, $class;
    $self->{_parent} = $_parent;
    $self->{_root} = $_root || $self;;

    $self->_read();

    return $self;
}

sub _read {
    my ($self) = @_;

    if ($self->_root()->osu_version() < 20191106) {
        $self->{len_beatmap} = $self->{_io}->read_s4le();
    }
    $self->{artist_name} = OsuDb::String->new($self->{_io}, $self, $self->{_root});
    $self->{artist_name_unicode} = OsuDb::String->new($self->{_io}, $self, $self->{_root});
    $self->{song_title} = OsuDb::String->new($self->{_io}, $self, $self->{_root});
    $self->{song_title_unicode} = OsuDb::String->new($self->{_io}, $self, $self->{_root});
    $self->{creator_name} = OsuDb::String->new($self->{_io}, $self, $self->{_root});
    $self->{difficulty} = OsuDb::String->new($self->{_io}, $self, $self->{_root});
    $self->{audio_file_name} = OsuDb::String->new($self->{_io}, $self, $self->{_root});
    $self->{md5_hash} = OsuDb::String->new($self->{_io}, $self, $self->{_root});
    $self->{osu_file_name} = OsuDb::String->new($self->{_io}, $self, $self->{_root});
    $self->{ranked_status} = $self->{_io}->read_s1();
    $self->{num_hitcircles} = $self->{_io}->read_s2le();
    $self->{num_sliders} = $self->{_io}->read_s2le();
    $self->{num_spinners} = $self->{_io}->read_s2le();
    $self->{last_modification_time} = $self->{_io}->read_s8le();
    if ($self->_root()->osu_version() < 20140609) {
        $self->{approach_rate_byte} = $self->{_io}->read_s1();
    }
    if ($self->_root()->osu_version() >= 20140609) {
        $self->{approach_rate} = $self->{_io}->read_f4le();
    }
    if ($self->_root()->osu_version() < 20140609) {
        $self->{circle_size_byte} = $self->{_io}->read_s1();
    }
    if ($self->_root()->osu_version() >= 20140609) {
        $self->{circle_size} = $self->{_io}->read_f4le();
    }
    if ($self->_root()->osu_version() < 20140609) {
        $self->{hp_drain_byte} = $self->{_io}->read_s1();
    }
    if ($self->_root()->osu_version() >= 20140609) {
        $self->{hp_drain} = $self->{_io}->read_f4le();
    }
    if ($self->_root()->osu_version() < 20140609) {
        $self->{overall_difficulty_byte} = $self->{_io}->read_s1();
    }
    if ($self->_root()->osu_version() >= 20140609) {
        $self->{overall_difficulty} = $self->{_io}->read_f4le();
    }
    $self->{slider_velocity} = $self->{_io}->read_f8le();
    if ($self->_root()->osu_version() >= 20140609) {
        $self->{star_rating_osu} = OsuDb::IntDoublePairs->new($self->{_io}, $self, $self->{_root});
    }
    if ($self->_root()->osu_version() >= 20140609) {
        $self->{star_rating_taiko} = OsuDb::IntDoublePairs->new($self->{_io}, $self, $self->{_root});
    }
    if ($self->_root()->osu_version() >= 20140609) {
        $self->{star_rating_ctb} = OsuDb::IntDoublePairs->new($self->{_io}, $self, $self->{_root});
    }
    if ($self->_root()->osu_version() >= 20140609) {
        $self->{star_rating_mania} = OsuDb::IntDoublePairs->new($self->{_io}, $self, $self->{_root});
    }
    $self->{drain_time} = $self->{_io}->read_s4le();
    $self->{total_time} = $self->{_io}->read_s4le();
    $self->{audio_preview_start_time} = $self->{_io}->read_s4le();
    $self->{timing_points} = OsuDb::TimingPoints->new($self->{_io}, $self, $self->{_root});
    $self->{beatmap_id} = $self->{_io}->read_s4le();
    $self->{beatmap_set_id} = $self->{_io}->read_s4le();
    $self->{thread_id} = $self->{_io}->read_s4le();
    $self->{grade_osu} = $self->{_io}->read_s1();
    $self->{grade_taiko} = $self->{_io}->read_s1();
    $self->{grade_ctb} = $self->{_io}->read_s1();
    $self->{grade_mania} = $self->{_io}->read_s1();
    $self->{local_beatmap_offset} = $self->{_io}->read_s2le();
    $self->{stack_leniency} = $self->{_io}->read_f4le();
    $self->{gameplay_mode} = $self->{_io}->read_s1();
    $self->{song_source} = OsuDb::String->new($self->{_io}, $self, $self->{_root});
    $self->{song_tags} = OsuDb::String->new($self->{_io}, $self, $self->{_root});
    $self->{online_offset} = $self->{_io}->read_s2le();
    $self->{song_title_font} = OsuDb::String->new($self->{_io}, $self, $self->{_root});
    $self->{is_unplayed} = OsuDb::Bool->new($self->{_io}, $self, $self->{_root});
    $self->{last_played_time} = $self->{_io}->read_s8le();
    $self->{is_osz2} = OsuDb::Bool->new($self->{_io}, $self, $self->{_root});
    $self->{folder_name} = OsuDb::String->new($self->{_io}, $self, $self->{_root});
    $self->{last_check_repo_time} = $self->{_io}->read_s8le();
    $self->{ignore_sound} = OsuDb::Bool->new($self->{_io}, $self, $self->{_root});
    $self->{ignore_skin} = OsuDb::Bool->new($self->{_io}, $self, $self->{_root});
    $self->{disable_storyboard} = OsuDb::Bool->new($self->{_io}, $self, $self->{_root});
    $self->{disable_video} = OsuDb::Bool->new($self->{_io}, $self, $self->{_root});
    $self->{visual_override} = OsuDb::Bool->new($self->{_io}, $self, $self->{_root});
    if ($self->_root()->osu_version() < 20140609) {
        $self->{unknown_short} = $self->{_io}->read_s2le();
    }
    $self->{last_modification_time_int} = $self->{_io}->read_s4le();
    $self->{mania_scroll_speed} = $self->{_io}->read_s1();
}

sub len_beatmap {
    my ($self) = @_;
    return $self->{len_beatmap};
}

sub artist_name {
    my ($self) = @_;
    return $self->{artist_name};
}

sub artist_name_unicode {
    my ($self) = @_;
    return $self->{artist_name_unicode};
}

sub song_title {
    my ($self) = @_;
    return $self->{song_title};
}

sub song_title_unicode {
    my ($self) = @_;
    return $self->{song_title_unicode};
}

sub creator_name {
    my ($self) = @_;
    return $self->{creator_name};
}

sub difficulty {
    my ($self) = @_;
    return $self->{difficulty};
}

sub audio_file_name {
    my ($self) = @_;
    return $self->{audio_file_name};
}

sub md5_hash {
    my ($self) = @_;
    return $self->{md5_hash};
}

sub osu_file_name {
    my ($self) = @_;
    return $self->{osu_file_name};
}

sub ranked_status {
    my ($self) = @_;
    return $self->{ranked_status};
}

sub num_hitcircles {
    my ($self) = @_;
    return $self->{num_hitcircles};
}

sub num_sliders {
    my ($self) = @_;
    return $self->{num_sliders};
}

sub num_spinners {
    my ($self) = @_;
    return $self->{num_spinners};
}

sub last_modification_time {
    my ($self) = @_;
    return $self->{last_modification_time};
}

sub approach_rate_byte {
    my ($self) = @_;
    return $self->{approach_rate_byte};
}

sub approach_rate {
    my ($self) = @_;
    return $self->{approach_rate};
}

sub circle_size_byte {
    my ($self) = @_;
    return $self->{circle_size_byte};
}

sub circle_size {
    my ($self) = @_;
    return $self->{circle_size};
}

sub hp_drain_byte {
    my ($self) = @_;
    return $self->{hp_drain_byte};
}

sub hp_drain {
    my ($self) = @_;
    return $self->{hp_drain};
}

sub overall_difficulty_byte {
    my ($self) = @_;
    return $self->{overall_difficulty_byte};
}

sub overall_difficulty {
    my ($self) = @_;
    return $self->{overall_difficulty};
}

sub slider_velocity {
    my ($self) = @_;
    return $self->{slider_velocity};
}

sub star_rating_osu {
    my ($self) = @_;
    return $self->{star_rating_osu};
}

sub star_rating_taiko {
    my ($self) = @_;
    return $self->{star_rating_taiko};
}

sub star_rating_ctb {
    my ($self) = @_;
    return $self->{star_rating_ctb};
}

sub star_rating_mania {
    my ($self) = @_;
    return $self->{star_rating_mania};
}

sub drain_time {
    my ($self) = @_;
    return $self->{drain_time};
}

sub total_time {
    my ($self) = @_;
    return $self->{total_time};
}

sub audio_preview_start_time {
    my ($self) = @_;
    return $self->{audio_preview_start_time};
}

sub timing_points {
    my ($self) = @_;
    return $self->{timing_points};
}

sub beatmap_id {
    my ($self) = @_;
    return $self->{beatmap_id};
}

sub beatmap_set_id {
    my ($self) = @_;
    return $self->{beatmap_set_id};
}

sub thread_id {
    my ($self) = @_;
    return $self->{thread_id};
}

sub grade_osu {
    my ($self) = @_;
    return $self->{grade_osu};
}

sub grade_taiko {
    my ($self) = @_;
    return $self->{grade_taiko};
}

sub grade_ctb {
    my ($self) = @_;
    return $self->{grade_ctb};
}

sub grade_mania {
    my ($self) = @_;
    return $self->{grade_mania};
}

sub local_beatmap_offset {
    my ($self) = @_;
    return $self->{local_beatmap_offset};
}

sub stack_leniency {
    my ($self) = @_;
    return $self->{stack_leniency};
}

sub gameplay_mode {
    my ($self) = @_;
    return $self->{gameplay_mode};
}

sub song_source {
    my ($self) = @_;
    return $self->{song_source};
}

sub song_tags {
    my ($self) = @_;
    return $self->{song_tags};
}

sub online_offset {
    my ($self) = @_;
    return $self->{online_offset};
}

sub song_title_font {
    my ($self) = @_;
    return $self->{song_title_font};
}

sub is_unplayed {
    my ($self) = @_;
    return $self->{is_unplayed};
}

sub last_played_time {
    my ($self) = @_;
    return $self->{last_played_time};
}

sub is_osz2 {
    my ($self) = @_;
    return $self->{is_osz2};
}

sub folder_name {
    my ($self) = @_;
    return $self->{folder_name};
}

sub last_check_repo_time {
    my ($self) = @_;
    return $self->{last_check_repo_time};
}

sub ignore_sound {
    my ($self) = @_;
    return $self->{ignore_sound};
}

sub ignore_skin {
    my ($self) = @_;
    return $self->{ignore_skin};
}

sub disable_storyboard {
    my ($self) = @_;
    return $self->{disable_storyboard};
}

sub disable_video {
    my ($self) = @_;
    return $self->{disable_video};
}

sub visual_override {
    my ($self) = @_;
    return $self->{visual_override};
}

sub unknown_short {
    my ($self) = @_;
    return $self->{unknown_short};
}

sub last_modification_time_int {
    my ($self) = @_;
    return $self->{last_modification_time_int};
}

sub mania_scroll_speed {
    my ($self) = @_;
    return $self->{mania_scroll_speed};
}

########################################################################
package OsuDb::TimingPoints;

our @ISA = 'IO::KaitaiStruct::Struct';

sub from_file {
    my ($class, $filename) = @_;
    my $fd;

    open($fd, '<', $filename) or return undef;
    binmode($fd);
    return new($class, IO::KaitaiStruct::Stream->new($fd));
}

sub new {
    my ($class, $_io, $_parent, $_root) = @_;
    my $self = IO::KaitaiStruct::Struct->new($_io);

    bless $self, $class;
    $self->{_parent} = $_parent;
    $self->{_root} = $_root || $self;;

    $self->_read();

    return $self;
}

sub _read {
    my ($self) = @_;

    $self->{num_points} = $self->{_io}->read_s4le();
    $self->{points} = ();
    my $n_points = $self->num_points();
    for (my $i = 0; $i < $n_points; $i++) {
        $self->{points}[$i] = OsuDb::TimingPoint->new($self->{_io}, $self, $self->{_root});
    }
}

sub num_points {
    my ($self) = @_;
    return $self->{num_points};
}

sub points {
    my ($self) = @_;
    return $self->{points};
}

########################################################################
package OsuDb::Bool;

our @ISA = 'IO::KaitaiStruct::Struct';

sub from_file {
    my ($class, $filename) = @_;
    my $fd;

    open($fd, '<', $filename) or return undef;
    binmode($fd);
    return new($class, IO::KaitaiStruct::Stream->new($fd));
}

sub new {
    my ($class, $_io, $_parent, $_root) = @_;
    my $self = IO::KaitaiStruct::Struct->new($_io);

    bless $self, $class;
    $self->{_parent} = $_parent;
    $self->{_root} = $_root || $self;;

    $self->_read();

    return $self;
}

sub _read {
    my ($self) = @_;

    $self->{byte} = $self->{_io}->read_s1();
}

sub value {
    my ($self) = @_;
    return $self->{value} if ($self->{value});
    $self->{value} = ($self->byte() == 0 ? 0 : 1);
    return $self->{value};
}

sub byte {
    my ($self) = @_;
    return $self->{byte};
}

########################################################################
package OsuDb::IntDoublePair;

our @ISA = 'IO::KaitaiStruct::Struct';

sub from_file {
    my ($class, $filename) = @_;
    my $fd;

    open($fd, '<', $filename) or return undef;
    binmode($fd);
    return new($class, IO::KaitaiStruct::Stream->new($fd));
}

sub new {
    my ($class, $_io, $_parent, $_root) = @_;
    my $self = IO::KaitaiStruct::Struct->new($_io);

    bless $self, $class;
    $self->{_parent} = $_parent;
    $self->{_root} = $_root || $self;;

    $self->_read();

    return $self;
}

sub _read {
    my ($self) = @_;

    $self->{magic1} = $self->{_io}->read_bytes(1);
    $self->{int} = $self->{_io}->read_s4le();
    $self->{magic2} = $self->{_io}->read_bytes(1);
    $self->{double} = $self->{_io}->read_f8le();
}

sub magic1 {
    my ($self) = @_;
    return $self->{magic1};
}

sub int {
    my ($self) = @_;
    return $self->{int};
}

sub magic2 {
    my ($self) = @_;
    return $self->{magic2};
}

sub double {
    my ($self) = @_;
    return $self->{double};
}

########################################################################
package OsuDb::IntDoublePairs;

our @ISA = 'IO::KaitaiStruct::Struct';

sub from_file {
    my ($class, $filename) = @_;
    my $fd;

    open($fd, '<', $filename) or return undef;
    binmode($fd);
    return new($class, IO::KaitaiStruct::Stream->new($fd));
}

sub new {
    my ($class, $_io, $_parent, $_root) = @_;
    my $self = IO::KaitaiStruct::Struct->new($_io);

    bless $self, $class;
    $self->{_parent} = $_parent;
    $self->{_root} = $_root || $self;;

    $self->_read();

    return $self;
}

sub _read {
    my ($self) = @_;

    $self->{num_pairs} = $self->{_io}->read_s4le();
    $self->{pairs} = ();
    my $n_pairs = $self->num_pairs();
    for (my $i = 0; $i < $n_pairs; $i++) {
        $self->{pairs}[$i] = OsuDb::IntDoublePair->new($self->{_io}, $self, $self->{_root});
    }
}

sub num_pairs {
    my ($self) = @_;
    return $self->{num_pairs};
}

sub pairs {
    my ($self) = @_;
    return $self->{pairs};
}

1;
