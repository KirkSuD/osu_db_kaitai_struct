// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

use std::option::Option;
use std::boxed::Box;
use std::io::Result;
use std::io::Cursor;
use std::vec::Vec;
use std::default::Default;
use kaitai_struct::KaitaiStream;
use kaitai_struct::KaitaiStruct;
use vlq_base128_le::VlqBase128Le;


/*
 * osu!.db file format in rhythm game, osu!.
 */
#[derive(Default)]
pub struct OsuDb {
    pub osuVersion: i32,
    pub folderCount: i32,
    pub accountUnlocked: Box<OsuDb__Bool>,
    pub accountUnlockDate: i64,
    pub playerName: Box<OsuDb__String>,
    pub numBeatmaps: i32,
    pub beatmaps: Vec<Box<OsuDb__Beatmap>>,
    pub userPermissions: i32,
}

impl KaitaiStruct for OsuDb {
    fn new<S: KaitaiStream>(stream: &mut S,
                            _parent: &Option<Box<KaitaiStruct>>,
                            _root: &Option<Box<KaitaiStruct>>)
                            -> Result<Self>
        where Self: Sized {
        let mut s: Self = Default::default();

        s.stream = stream;
        s.read(stream, _parent, _root)?;

        Ok(s)
    }


    fn read<S: KaitaiStream>(&mut self,
                             stream: &mut S,
                             _parent: &Option<Box<KaitaiStruct>>,
                             _root: &Option<Box<KaitaiStruct>>)
                             -> Result<()>
        where Self: Sized {
        self.osuVersion = self.stream.read_s4le()?;
        self.folderCount = self.stream.read_s4le()?;
        self.accountUnlocked = Box::new(OsuDb__Bool::new(self.stream, self, _root)?);
        self.accountUnlockDate = self.stream.read_s8le()?;
        self.playerName = Box::new(OsuDb__String::new(self.stream, self, _root)?);
        self.numBeatmaps = self.stream.read_s4le()?;
        self.beatmaps = vec!();
        for i in 0..self.num_beatmaps {
            self.beatmaps.push(Box::new(OsuDb__Beatmap::new(self.stream, self, _root)?));
        }
        self.userPermissions = self.stream.read_s4le()?;
    }
}

impl OsuDb {

    /*
     * Int, osu! version (e.g. 20150203)
     */

    /*
     * Int, Folder Count
     */

    /*
     * Bool, AccountUnlocked (only false when the account is locked or banned in any way)
     */

    /*
     * DateTime, Date the account will be unlocked
     */

    /*
     * String, Player name
     */

    /*
     * Int, Number of beatmaps
     */

    /*
     * Beatmaps*, Aforementioned beatmaps
     */

    /*
     * Int, User permissions (0 = None, 1 = Normal, 2 = Moderator, 4 = Supporter, 8 = Friend, 16 = peppy, 32 = World Cup staff)
     */
}

/*
 * Consists of a Double, signifying the BPM, another Double,
 * signifying the offset into the song, in milliseconds, and a Boolean;
 * if false, then this timing point is inherited.
 * See Osu (file format) for more information regarding timing points.
 */
#[derive(Default)]
pub struct OsuDb__TimingPoint {
    pub bpm: f64,
    pub offset: f64,
    pub notInherited: Box<OsuDb__Bool>,
}

impl KaitaiStruct for OsuDb__TimingPoint {
    fn new<S: KaitaiStream>(stream: &mut S,
                            _parent: &Option<Box<KaitaiStruct>>,
                            _root: &Option<Box<KaitaiStruct>>)
                            -> Result<Self>
        where Self: Sized {
        let mut s: Self = Default::default();

        s.stream = stream;
        s.read(stream, _parent, _root)?;

        Ok(s)
    }


    fn read<S: KaitaiStream>(&mut self,
                             stream: &mut S,
                             _parent: &Option<Box<KaitaiStruct>>,
                             _root: &Option<Box<KaitaiStruct>>)
                             -> Result<()>
        where Self: Sized {
        self.bpm = self.stream.read_f8le()?;
        self.offset = self.stream.read_f8le()?;
        self.notInherited = Box::new(OsuDb__Bool::new(self.stream, self, _root)?);
    }
}

impl OsuDb__TimingPoint {
}
#[derive(Default)]
pub struct OsuDb__String {
    pub isPresent: i8,
    pub lenStr: Box<VlqBase128Le>,
    pub value: String,
}

impl KaitaiStruct for OsuDb__String {
    fn new<S: KaitaiStream>(stream: &mut S,
                            _parent: &Option<Box<KaitaiStruct>>,
                            _root: &Option<Box<KaitaiStruct>>)
                            -> Result<Self>
        where Self: Sized {
        let mut s: Self = Default::default();

        s.stream = stream;
        s.read(stream, _parent, _root)?;

        Ok(s)
    }


    fn read<S: KaitaiStream>(&mut self,
                             stream: &mut S,
                             _parent: &Option<Box<KaitaiStruct>>,
                             _root: &Option<Box<KaitaiStruct>>)
                             -> Result<()>
        where Self: Sized {
        self.isPresent = self.stream.read_s1()?;
        if self.is_present == 11 {
            self.lenStr = Box::new(VlqBase128Le::new(self.stream, self, _root)?);
        }
        if self.is_present == 11 {
            self.value = panic!("Unimplemented encoding for bytesToStr: {}", "UTF-8");
        }
    }
}

impl OsuDb__String {
}
#[derive(Default)]
pub struct OsuDb__Beatmap {
    pub lenBeatmap: i32,
    pub artistName: Box<OsuDb__String>,
    pub artistNameUnicode: Box<OsuDb__String>,
    pub songTitle: Box<OsuDb__String>,
    pub songTitleUnicode: Box<OsuDb__String>,
    pub creatorName: Box<OsuDb__String>,
    pub difficulty: Box<OsuDb__String>,
    pub audioFileName: Box<OsuDb__String>,
    pub md5Hash: Box<OsuDb__String>,
    pub osuFileName: Box<OsuDb__String>,
    pub rankedStatus: i8,
    pub numHitcircles: i16,
    pub numSliders: i16,
    pub numSpinners: i16,
    pub lastModificationTime: i64,
    pub approachRateByte: i8,
    pub approachRate: f32,
    pub circleSizeByte: i8,
    pub circleSize: f32,
    pub hpDrainByte: i8,
    pub hpDrain: f32,
    pub overallDifficultyByte: i8,
    pub overallDifficulty: f32,
    pub sliderVelocity: f64,
    pub starRatingOsu: Box<OsuDb__IntDoublePairs>,
    pub starRatingTaiko: Box<OsuDb__IntDoublePairs>,
    pub starRatingCtb: Box<OsuDb__IntDoublePairs>,
    pub starRatingMania: Box<OsuDb__IntDoublePairs>,
    pub drainTime: i32,
    pub totalTime: i32,
    pub audioPreviewStartTime: i32,
    pub timingPoints: Box<OsuDb__TimingPoints>,
    pub beatmapId: i32,
    pub beatmapSetId: i32,
    pub threadId: i32,
    pub gradeOsu: i8,
    pub gradeTaiko: i8,
    pub gradeCtb: i8,
    pub gradeMania: i8,
    pub localBeatmapOffset: i16,
    pub stackLeniency: f32,
    pub gameplayMode: i8,
    pub songSource: Box<OsuDb__String>,
    pub songTags: Box<OsuDb__String>,
    pub onlineOffset: i16,
    pub songTitleFont: Box<OsuDb__String>,
    pub isUnplayed: Box<OsuDb__Bool>,
    pub lastPlayedTime: i64,
    pub isOsz2: Box<OsuDb__Bool>,
    pub folderName: Box<OsuDb__String>,
    pub lastCheckRepoTime: i64,
    pub ignoreSound: Box<OsuDb__Bool>,
    pub ignoreSkin: Box<OsuDb__Bool>,
    pub disableStoryboard: Box<OsuDb__Bool>,
    pub disableVideo: Box<OsuDb__Bool>,
    pub visualOverride: Box<OsuDb__Bool>,
    pub unknownShort: i16,
    pub lastModificationTimeInt: i32,
    pub maniaScrollSpeed: i8,
}

impl KaitaiStruct for OsuDb__Beatmap {
    fn new<S: KaitaiStream>(stream: &mut S,
                            _parent: &Option<Box<KaitaiStruct>>,
                            _root: &Option<Box<KaitaiStruct>>)
                            -> Result<Self>
        where Self: Sized {
        let mut s: Self = Default::default();

        s.stream = stream;
        s.read(stream, _parent, _root)?;

        Ok(s)
    }


    fn read<S: KaitaiStream>(&mut self,
                             stream: &mut S,
                             _parent: &Option<Box<KaitaiStruct>>,
                             _root: &Option<Box<KaitaiStruct>>)
                             -> Result<()>
        where Self: Sized {
        if self._root.osu_version < 20191106 {
            self.lenBeatmap = self.stream.read_s4le()?;
        }
        self.artistName = Box::new(OsuDb__String::new(self.stream, self, _root)?);
        self.artistNameUnicode = Box::new(OsuDb__String::new(self.stream, self, _root)?);
        self.songTitle = Box::new(OsuDb__String::new(self.stream, self, _root)?);
        self.songTitleUnicode = Box::new(OsuDb__String::new(self.stream, self, _root)?);
        self.creatorName = Box::new(OsuDb__String::new(self.stream, self, _root)?);
        self.difficulty = Box::new(OsuDb__String::new(self.stream, self, _root)?);
        self.audioFileName = Box::new(OsuDb__String::new(self.stream, self, _root)?);
        self.md5Hash = Box::new(OsuDb__String::new(self.stream, self, _root)?);
        self.osuFileName = Box::new(OsuDb__String::new(self.stream, self, _root)?);
        self.rankedStatus = self.stream.read_s1()?;
        self.numHitcircles = self.stream.read_s2le()?;
        self.numSliders = self.stream.read_s2le()?;
        self.numSpinners = self.stream.read_s2le()?;
        self.lastModificationTime = self.stream.read_s8le()?;
        if self._root.osu_version < 20140609 {
            self.approachRateByte = self.stream.read_s1()?;
        }
        if self._root.osu_version >= 20140609 {
            self.approachRate = self.stream.read_f4le()?;
        }
        if self._root.osu_version < 20140609 {
            self.circleSizeByte = self.stream.read_s1()?;
        }
        if self._root.osu_version >= 20140609 {
            self.circleSize = self.stream.read_f4le()?;
        }
        if self._root.osu_version < 20140609 {
            self.hpDrainByte = self.stream.read_s1()?;
        }
        if self._root.osu_version >= 20140609 {
            self.hpDrain = self.stream.read_f4le()?;
        }
        if self._root.osu_version < 20140609 {
            self.overallDifficultyByte = self.stream.read_s1()?;
        }
        if self._root.osu_version >= 20140609 {
            self.overallDifficulty = self.stream.read_f4le()?;
        }
        self.sliderVelocity = self.stream.read_f8le()?;
        if self._root.osu_version >= 20140609 {
            self.starRatingOsu = Box::new(OsuDb__IntDoublePairs::new(self.stream, self, _root)?);
        }
        if self._root.osu_version >= 20140609 {
            self.starRatingTaiko = Box::new(OsuDb__IntDoublePairs::new(self.stream, self, _root)?);
        }
        if self._root.osu_version >= 20140609 {
            self.starRatingCtb = Box::new(OsuDb__IntDoublePairs::new(self.stream, self, _root)?);
        }
        if self._root.osu_version >= 20140609 {
            self.starRatingMania = Box::new(OsuDb__IntDoublePairs::new(self.stream, self, _root)?);
        }
        self.drainTime = self.stream.read_s4le()?;
        self.totalTime = self.stream.read_s4le()?;
        self.audioPreviewStartTime = self.stream.read_s4le()?;
        self.timingPoints = Box::new(OsuDb__TimingPoints::new(self.stream, self, _root)?);
        self.beatmapId = self.stream.read_s4le()?;
        self.beatmapSetId = self.stream.read_s4le()?;
        self.threadId = self.stream.read_s4le()?;
        self.gradeOsu = self.stream.read_s1()?;
        self.gradeTaiko = self.stream.read_s1()?;
        self.gradeCtb = self.stream.read_s1()?;
        self.gradeMania = self.stream.read_s1()?;
        self.localBeatmapOffset = self.stream.read_s2le()?;
        self.stackLeniency = self.stream.read_f4le()?;
        self.gameplayMode = self.stream.read_s1()?;
        self.songSource = Box::new(OsuDb__String::new(self.stream, self, _root)?);
        self.songTags = Box::new(OsuDb__String::new(self.stream, self, _root)?);
        self.onlineOffset = self.stream.read_s2le()?;
        self.songTitleFont = Box::new(OsuDb__String::new(self.stream, self, _root)?);
        self.isUnplayed = Box::new(OsuDb__Bool::new(self.stream, self, _root)?);
        self.lastPlayedTime = self.stream.read_s8le()?;
        self.isOsz2 = Box::new(OsuDb__Bool::new(self.stream, self, _root)?);
        self.folderName = Box::new(OsuDb__String::new(self.stream, self, _root)?);
        self.lastCheckRepoTime = self.stream.read_s8le()?;
        self.ignoreSound = Box::new(OsuDb__Bool::new(self.stream, self, _root)?);
        self.ignoreSkin = Box::new(OsuDb__Bool::new(self.stream, self, _root)?);
        self.disableStoryboard = Box::new(OsuDb__Bool::new(self.stream, self, _root)?);
        self.disableVideo = Box::new(OsuDb__Bool::new(self.stream, self, _root)?);
        self.visualOverride = Box::new(OsuDb__Bool::new(self.stream, self, _root)?);
        if self._root.osu_version < 20140609 {
            self.unknownShort = self.stream.read_s2le()?;
        }
        self.lastModificationTimeInt = self.stream.read_s4le()?;
        self.maniaScrollSpeed = self.stream.read_s1()?;
    }
}

impl OsuDb__Beatmap {

    /*
     * Int,	Size in bytes of the beatmap entry. Only present if version is less than 20191106.
     */

    /*
     * String, Artist name
     */

    /*
     * String, Artist name, in Unicode
     */

    /*
     * String, Song title
     */

    /*
     * String, Song title, in Unicode
     */

    /*
     * String, Creator name
     */

    /*
     * String, Difficulty (e.g. Hard, Insane, etc.)
     */

    /*
     * String, Audio file name
     */

    /*
     * String, MD5 hash of the beatmap
     */

    /*
     * String, Name of the .osu file corresponding to this beatmap
     */

    /*
     * Byte, Ranked status (0 = unknown, 1 = unsubmitted, 2 = pending/wip/graveyard, 3 = unused, 4 = ranked, 5 = approved, 6 = qualified, 7 = loved)
     */

    /*
     * Short, Number of hitcircles
     */

    /*
     * Short, Number of sliders (note: this will be present in every mode)
     */

    /*
     * Short, Number of spinners (note: this will be present in every mode)
     */

    /*
     * Long, Last modification time, Windows ticks.
     */

    /*
     * Byte/Single, Approach rate. Byte if the version is less than 20140609, Single otherwise.
     */

    /*
     * Byte/Single, Approach rate. Byte if the version is less than 20140609, Single otherwise.
     */

    /*
     * Byte/Single, Circle size. Byte if the version is less than 20140609, Single otherwise.
     */

    /*
     * Byte/Single, Circle size. Byte if the version is less than 20140609, Single otherwise.
     */

    /*
     * Byte/Single, HP drain. Byte if the version is less than 20140609, Single otherwise.
     */

    /*
     * Byte/Single, HP drain. Byte if the version is less than 20140609, Single otherwise.
     */

    /*
     * Byte/Single, Overall difficulty. Byte if the version is less than 20140609, Single otherwise.
     */

    /*
     * Byte/Single, Overall difficulty. Byte if the version is less than 20140609, Single otherwise.
     */

    /*
     * Double, Slider velocity
     */

    /*
     * Int-Double pair*, Star Rating info for osu! standard, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
     */

    /*
     * Int-Double pair*, Star Rating info for Taiko, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
     */

    /*
     * Int-Double pair*, Star Rating info for CTB, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
     */

    /*
     * Int-Double pair*, Star Rating info for osu!mania, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
     */

    /*
     * Int, Drain time, in seconds
     */

    /*
     * Int, Total time, in milliseconds
     */

    /*
     * Int, Time when the audio preview when hovering over a beatmap in beatmap select starts, in milliseconds.
     */

    /*
     * Timing point+, An Int indicating the number of following Timing points, then the aforementioned Timing points.
     */

    /*
     * Int, Beatmap ID
     */

    /*
     * Int, Beatmap set ID
     */

    /*
     * Int, Thread ID
     */

    /*
     * Byte, Grade achieved in osu! standard.
     */

    /*
     * Byte, Grade achieved in Taiko.
     */

    /*
     * Byte, Grade achieved in CTB.
     */

    /*
     * Byte, Grade achieved in osu!mania.
     */

    /*
     * Short, Local beatmap offset
     */

    /*
     * Single, Stack leniency
     */

    /*
     * Byte, Osu gameplay mode. 0x00 = osu!Standard, 0x01 = Taiko, 0x02 = CTB, 0x03 = Mania
     */

    /*
     * String, Song source
     */

    /*
     * String, Song tags
     */

    /*
     * Short, Online offset
     */

    /*
     * String, Font used for the title of the song
     */

    /*
     * Boolean, Is beatmap unplayed
     */

    /*
     * Long, Last time when beatmap was played
     */

    /*
     * Boolean, Is the beatmap osz2
     */

    /*
     * String, Folder name of the beatmap, relative to Songs folder
     */

    /*
     * Long, Last time when beatmap was checked against osu! repository
     */

    /*
     * Boolean, Ignore beatmap sound
     */

    /*
     * Boolean, Ignore beatmap skin
     */

    /*
     * Boolean, Disable storyboard
     */

    /*
     * Boolean, Disable video
     */

    /*
     * Boolean, Visual override
     */

    /*
     * Short?, Unknown. Only present if version is less than 20140609.
     */

    /*
     * Int, Last modification time (?)
     */

    /*
     * Byte, Mania scroll speed
     */
}

/*
 * An Int indicating the number of following Timing points, then the aforementioned Timing points.
 */
#[derive(Default)]
pub struct OsuDb__TimingPoints {
    pub numPoints: i32,
    pub points: Vec<Box<OsuDb__TimingPoint>>,
}

impl KaitaiStruct for OsuDb__TimingPoints {
    fn new<S: KaitaiStream>(stream: &mut S,
                            _parent: &Option<Box<KaitaiStruct>>,
                            _root: &Option<Box<KaitaiStruct>>)
                            -> Result<Self>
        where Self: Sized {
        let mut s: Self = Default::default();

        s.stream = stream;
        s.read(stream, _parent, _root)?;

        Ok(s)
    }


    fn read<S: KaitaiStream>(&mut self,
                             stream: &mut S,
                             _parent: &Option<Box<KaitaiStruct>>,
                             _root: &Option<Box<KaitaiStruct>>)
                             -> Result<()>
        where Self: Sized {
        self.numPoints = self.stream.read_s4le()?;
        self.points = vec!();
        for i in 0..self.num_points {
            self.points.push(Box::new(OsuDb__TimingPoint::new(self.stream, self, _root)?));
        }
    }
}

impl OsuDb__TimingPoints {
}
#[derive(Default)]
pub struct OsuDb__Bool {
    pub byte: i8,
    pub value: Option<bool>,
}

impl KaitaiStruct for OsuDb__Bool {
    fn new<S: KaitaiStream>(stream: &mut S,
                            _parent: &Option<Box<KaitaiStruct>>,
                            _root: &Option<Box<KaitaiStruct>>)
                            -> Result<Self>
        where Self: Sized {
        let mut s: Self = Default::default();

        s.stream = stream;
        s.read(stream, _parent, _root)?;

        Ok(s)
    }


    fn read<S: KaitaiStream>(&mut self,
                             stream: &mut S,
                             _parent: &Option<Box<KaitaiStruct>>,
                             _root: &Option<Box<KaitaiStruct>>)
                             -> Result<()>
        where Self: Sized {
        self.byte = self.stream.read_s1()?;
    }
}

impl OsuDb__Bool {
    fn value(&mut self) -> bool {
        if let Some(x) = self.value {
            return x;
        }

        self.value = if self.byte == 0 { false } else { true};
        return self.value;
    }
}

/*
 * The first byte is 0x08, followed by an Int, then 0x0d, followed by a Double.
 * These extraneous bytes are presumably flags to signify different data types
 * in these slots, though in practice no other such flags have been seen.
 * Currently the purpose of this data type is unknown.
 */
#[derive(Default)]
pub struct OsuDb__IntDoublePair {
    pub magic1: Vec<u8>,
    pub int: i32,
    pub magic2: Vec<u8>,
    pub double: f64,
}

impl KaitaiStruct for OsuDb__IntDoublePair {
    fn new<S: KaitaiStream>(stream: &mut S,
                            _parent: &Option<Box<KaitaiStruct>>,
                            _root: &Option<Box<KaitaiStruct>>)
                            -> Result<Self>
        where Self: Sized {
        let mut s: Self = Default::default();

        s.stream = stream;
        s.read(stream, _parent, _root)?;

        Ok(s)
    }


    fn read<S: KaitaiStream>(&mut self,
                             stream: &mut S,
                             _parent: &Option<Box<KaitaiStruct>>,
                             _root: &Option<Box<KaitaiStruct>>)
                             -> Result<()>
        where Self: Sized {
        self.magic1 = self.stream.read_bytes(1)?;
        self.int = self.stream.read_s4le()?;
        self.magic2 = self.stream.read_bytes(1)?;
        self.double = self.stream.read_f8le()?;
    }
}

impl OsuDb__IntDoublePair {
}

/*
 * An Int indicating the number of following Int-Double pairs, then the aforementioned pairs.
 */
#[derive(Default)]
pub struct OsuDb__IntDoublePairs {
    pub numPairs: i32,
    pub pairs: Vec<Box<OsuDb__IntDoublePair>>,
}

impl KaitaiStruct for OsuDb__IntDoublePairs {
    fn new<S: KaitaiStream>(stream: &mut S,
                            _parent: &Option<Box<KaitaiStruct>>,
                            _root: &Option<Box<KaitaiStruct>>)
                            -> Result<Self>
        where Self: Sized {
        let mut s: Self = Default::default();

        s.stream = stream;
        s.read(stream, _parent, _root)?;

        Ok(s)
    }


    fn read<S: KaitaiStream>(&mut self,
                             stream: &mut S,
                             _parent: &Option<Box<KaitaiStruct>>,
                             _root: &Option<Box<KaitaiStruct>>)
                             -> Result<()>
        where Self: Sized {
        self.numPairs = self.stream.read_s4le()?;
        self.pairs = vec!();
        for i in 0..self.num_pairs {
            self.pairs.push(Box::new(OsuDb__IntDoublePair::new(self.stream, self, _root)?));
        }
    }
}

impl OsuDb__IntDoublePairs {
}
