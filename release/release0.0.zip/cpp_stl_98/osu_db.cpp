// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

#include "osu_db.h"
#include "kaitai/exceptions.h"

osu_db_t::osu_db_t(kaitai::kstream* p__io, kaitai::kstruct* p__parent, osu_db_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = this;
    m_account_unlocked = 0;
    m_player_name = 0;
    m_beatmaps = 0;

    try {
        _read();
    } catch(...) {
        _clean_up();
        throw;
    }
}

void osu_db_t::_read() {
    m_osu_version = m__io->read_s4le();
    m_folder_count = m__io->read_s4le();
    m_account_unlocked = new bool_t(m__io, this, m__root);
    m_account_unlock_date = m__io->read_s8le();
    m_player_name = new string_t(m__io, this, m__root);
    m_num_beatmaps = m__io->read_s4le();
    int l_beatmaps = num_beatmaps();
    m_beatmaps = new std::vector<beatmap_t*>();
    m_beatmaps->reserve(l_beatmaps);
    for (int i = 0; i < l_beatmaps; i++) {
        m_beatmaps->push_back(new beatmap_t(m__io, this, m__root));
    }
    m_user_permissions = m__io->read_s4le();
}

osu_db_t::~osu_db_t() {
    _clean_up();
}

void osu_db_t::_clean_up() {
    if (m_account_unlocked) {
        delete m_account_unlocked; m_account_unlocked = 0;
    }
    if (m_player_name) {
        delete m_player_name; m_player_name = 0;
    }
    if (m_beatmaps) {
        for (std::vector<beatmap_t*>::iterator it = m_beatmaps->begin(); it != m_beatmaps->end(); ++it) {
            delete *it;
        }
        delete m_beatmaps; m_beatmaps = 0;
    }
}

osu_db_t::timing_point_t::timing_point_t(kaitai::kstream* p__io, osu_db_t::timing_points_t* p__parent, osu_db_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    m_not_inherited = 0;

    try {
        _read();
    } catch(...) {
        _clean_up();
        throw;
    }
}

void osu_db_t::timing_point_t::_read() {
    m_bpm = m__io->read_f8le();
    m_offset = m__io->read_f8le();
    m_not_inherited = new bool_t(m__io, this, m__root);
}

osu_db_t::timing_point_t::~timing_point_t() {
    _clean_up();
}

void osu_db_t::timing_point_t::_clean_up() {
    if (m_not_inherited) {
        delete m_not_inherited; m_not_inherited = 0;
    }
}

osu_db_t::string_t::string_t(kaitai::kstream* p__io, kaitai::kstruct* p__parent, osu_db_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    m_len_str = 0;

    try {
        _read();
    } catch(...) {
        _clean_up();
        throw;
    }
}

void osu_db_t::string_t::_read() {
    m_is_present = m__io->read_s1();
    n_len_str = true;
    if (is_present() == 11) {
        n_len_str = false;
        m_len_str = new vlq_base128_le_t(m__io);
    }
    n_value = true;
    if (is_present() == 11) {
        n_value = false;
        m_value = kaitai::kstream::bytes_to_str(m__io->read_bytes(len_str()->value()), std::string("UTF-8"));
    }
}

osu_db_t::string_t::~string_t() {
    _clean_up();
}

void osu_db_t::string_t::_clean_up() {
    if (!n_len_str) {
        if (m_len_str) {
            delete m_len_str; m_len_str = 0;
        }
    }
    if (!n_value) {
    }
}

osu_db_t::beatmap_t::beatmap_t(kaitai::kstream* p__io, osu_db_t* p__parent, osu_db_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    m_artist_name = 0;
    m_artist_name_unicode = 0;
    m_song_title = 0;
    m_song_title_unicode = 0;
    m_creator_name = 0;
    m_difficulty = 0;
    m_audio_file_name = 0;
    m_md5_hash = 0;
    m_osu_file_name = 0;
    m_star_rating_osu = 0;
    m_star_rating_taiko = 0;
    m_star_rating_ctb = 0;
    m_star_rating_mania = 0;
    m_timing_points = 0;
    m_song_source = 0;
    m_song_tags = 0;
    m_song_title_font = 0;
    m_is_unplayed = 0;
    m_is_osz2 = 0;
    m_folder_name = 0;
    m_ignore_sound = 0;
    m_ignore_skin = 0;
    m_disable_storyboard = 0;
    m_disable_video = 0;
    m_visual_override = 0;

    try {
        _read();
    } catch(...) {
        _clean_up();
        throw;
    }
}

void osu_db_t::beatmap_t::_read() {
    n_len_beatmap = true;
    if (_root()->osu_version() < 20191106) {
        n_len_beatmap = false;
        m_len_beatmap = m__io->read_s4le();
    }
    m_artist_name = new string_t(m__io, this, m__root);
    m_artist_name_unicode = new string_t(m__io, this, m__root);
    m_song_title = new string_t(m__io, this, m__root);
    m_song_title_unicode = new string_t(m__io, this, m__root);
    m_creator_name = new string_t(m__io, this, m__root);
    m_difficulty = new string_t(m__io, this, m__root);
    m_audio_file_name = new string_t(m__io, this, m__root);
    m_md5_hash = new string_t(m__io, this, m__root);
    m_osu_file_name = new string_t(m__io, this, m__root);
    m_ranked_status = m__io->read_s1();
    m_num_hitcircles = m__io->read_s2le();
    m_num_sliders = m__io->read_s2le();
    m_num_spinners = m__io->read_s2le();
    m_last_modification_time = m__io->read_s8le();
    n_approach_rate_byte = true;
    if (_root()->osu_version() < 20140609) {
        n_approach_rate_byte = false;
        m_approach_rate_byte = m__io->read_s1();
    }
    n_approach_rate = true;
    if (_root()->osu_version() >= 20140609) {
        n_approach_rate = false;
        m_approach_rate = m__io->read_f4le();
    }
    n_circle_size_byte = true;
    if (_root()->osu_version() < 20140609) {
        n_circle_size_byte = false;
        m_circle_size_byte = m__io->read_s1();
    }
    n_circle_size = true;
    if (_root()->osu_version() >= 20140609) {
        n_circle_size = false;
        m_circle_size = m__io->read_f4le();
    }
    n_hp_drain_byte = true;
    if (_root()->osu_version() < 20140609) {
        n_hp_drain_byte = false;
        m_hp_drain_byte = m__io->read_s1();
    }
    n_hp_drain = true;
    if (_root()->osu_version() >= 20140609) {
        n_hp_drain = false;
        m_hp_drain = m__io->read_f4le();
    }
    n_overall_difficulty_byte = true;
    if (_root()->osu_version() < 20140609) {
        n_overall_difficulty_byte = false;
        m_overall_difficulty_byte = m__io->read_s1();
    }
    n_overall_difficulty = true;
    if (_root()->osu_version() >= 20140609) {
        n_overall_difficulty = false;
        m_overall_difficulty = m__io->read_f4le();
    }
    m_slider_velocity = m__io->read_f8le();
    n_star_rating_osu = true;
    if (_root()->osu_version() >= 20140609) {
        n_star_rating_osu = false;
        m_star_rating_osu = new int_double_pairs_t(m__io, this, m__root);
    }
    n_star_rating_taiko = true;
    if (_root()->osu_version() >= 20140609) {
        n_star_rating_taiko = false;
        m_star_rating_taiko = new int_double_pairs_t(m__io, this, m__root);
    }
    n_star_rating_ctb = true;
    if (_root()->osu_version() >= 20140609) {
        n_star_rating_ctb = false;
        m_star_rating_ctb = new int_double_pairs_t(m__io, this, m__root);
    }
    n_star_rating_mania = true;
    if (_root()->osu_version() >= 20140609) {
        n_star_rating_mania = false;
        m_star_rating_mania = new int_double_pairs_t(m__io, this, m__root);
    }
    m_drain_time = m__io->read_s4le();
    m_total_time = m__io->read_s4le();
    m_audio_preview_start_time = m__io->read_s4le();
    m_timing_points = new timing_points_t(m__io, this, m__root);
    m_beatmap_id = m__io->read_s4le();
    m_beatmap_set_id = m__io->read_s4le();
    m_thread_id = m__io->read_s4le();
    m_grade_osu = m__io->read_s1();
    m_grade_taiko = m__io->read_s1();
    m_grade_ctb = m__io->read_s1();
    m_grade_mania = m__io->read_s1();
    m_local_beatmap_offset = m__io->read_s2le();
    m_stack_leniency = m__io->read_f4le();
    m_gameplay_mode = m__io->read_s1();
    m_song_source = new string_t(m__io, this, m__root);
    m_song_tags = new string_t(m__io, this, m__root);
    m_online_offset = m__io->read_s2le();
    m_song_title_font = new string_t(m__io, this, m__root);
    m_is_unplayed = new bool_t(m__io, this, m__root);
    m_last_played_time = m__io->read_s8le();
    m_is_osz2 = new bool_t(m__io, this, m__root);
    m_folder_name = new string_t(m__io, this, m__root);
    m_last_check_repo_time = m__io->read_s8le();
    m_ignore_sound = new bool_t(m__io, this, m__root);
    m_ignore_skin = new bool_t(m__io, this, m__root);
    m_disable_storyboard = new bool_t(m__io, this, m__root);
    m_disable_video = new bool_t(m__io, this, m__root);
    m_visual_override = new bool_t(m__io, this, m__root);
    n_unknown_short = true;
    if (_root()->osu_version() < 20140609) {
        n_unknown_short = false;
        m_unknown_short = m__io->read_s2le();
    }
    m_last_modification_time_int = m__io->read_s4le();
    m_mania_scroll_speed = m__io->read_s1();
}

osu_db_t::beatmap_t::~beatmap_t() {
    _clean_up();
}

void osu_db_t::beatmap_t::_clean_up() {
    if (!n_len_beatmap) {
    }
    if (m_artist_name) {
        delete m_artist_name; m_artist_name = 0;
    }
    if (m_artist_name_unicode) {
        delete m_artist_name_unicode; m_artist_name_unicode = 0;
    }
    if (m_song_title) {
        delete m_song_title; m_song_title = 0;
    }
    if (m_song_title_unicode) {
        delete m_song_title_unicode; m_song_title_unicode = 0;
    }
    if (m_creator_name) {
        delete m_creator_name; m_creator_name = 0;
    }
    if (m_difficulty) {
        delete m_difficulty; m_difficulty = 0;
    }
    if (m_audio_file_name) {
        delete m_audio_file_name; m_audio_file_name = 0;
    }
    if (m_md5_hash) {
        delete m_md5_hash; m_md5_hash = 0;
    }
    if (m_osu_file_name) {
        delete m_osu_file_name; m_osu_file_name = 0;
    }
    if (!n_approach_rate_byte) {
    }
    if (!n_approach_rate) {
    }
    if (!n_circle_size_byte) {
    }
    if (!n_circle_size) {
    }
    if (!n_hp_drain_byte) {
    }
    if (!n_hp_drain) {
    }
    if (!n_overall_difficulty_byte) {
    }
    if (!n_overall_difficulty) {
    }
    if (!n_star_rating_osu) {
        if (m_star_rating_osu) {
            delete m_star_rating_osu; m_star_rating_osu = 0;
        }
    }
    if (!n_star_rating_taiko) {
        if (m_star_rating_taiko) {
            delete m_star_rating_taiko; m_star_rating_taiko = 0;
        }
    }
    if (!n_star_rating_ctb) {
        if (m_star_rating_ctb) {
            delete m_star_rating_ctb; m_star_rating_ctb = 0;
        }
    }
    if (!n_star_rating_mania) {
        if (m_star_rating_mania) {
            delete m_star_rating_mania; m_star_rating_mania = 0;
        }
    }
    if (m_timing_points) {
        delete m_timing_points; m_timing_points = 0;
    }
    if (m_song_source) {
        delete m_song_source; m_song_source = 0;
    }
    if (m_song_tags) {
        delete m_song_tags; m_song_tags = 0;
    }
    if (m_song_title_font) {
        delete m_song_title_font; m_song_title_font = 0;
    }
    if (m_is_unplayed) {
        delete m_is_unplayed; m_is_unplayed = 0;
    }
    if (m_is_osz2) {
        delete m_is_osz2; m_is_osz2 = 0;
    }
    if (m_folder_name) {
        delete m_folder_name; m_folder_name = 0;
    }
    if (m_ignore_sound) {
        delete m_ignore_sound; m_ignore_sound = 0;
    }
    if (m_ignore_skin) {
        delete m_ignore_skin; m_ignore_skin = 0;
    }
    if (m_disable_storyboard) {
        delete m_disable_storyboard; m_disable_storyboard = 0;
    }
    if (m_disable_video) {
        delete m_disable_video; m_disable_video = 0;
    }
    if (m_visual_override) {
        delete m_visual_override; m_visual_override = 0;
    }
    if (!n_unknown_short) {
    }
}

osu_db_t::timing_points_t::timing_points_t(kaitai::kstream* p__io, osu_db_t::beatmap_t* p__parent, osu_db_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    m_points = 0;

    try {
        _read();
    } catch(...) {
        _clean_up();
        throw;
    }
}

void osu_db_t::timing_points_t::_read() {
    m_num_points = m__io->read_s4le();
    int l_points = num_points();
    m_points = new std::vector<timing_point_t*>();
    m_points->reserve(l_points);
    for (int i = 0; i < l_points; i++) {
        m_points->push_back(new timing_point_t(m__io, this, m__root));
    }
}

osu_db_t::timing_points_t::~timing_points_t() {
    _clean_up();
}

void osu_db_t::timing_points_t::_clean_up() {
    if (m_points) {
        for (std::vector<timing_point_t*>::iterator it = m_points->begin(); it != m_points->end(); ++it) {
            delete *it;
        }
        delete m_points; m_points = 0;
    }
}

osu_db_t::bool_t::bool_t(kaitai::kstream* p__io, kaitai::kstruct* p__parent, osu_db_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    f_value = false;

    try {
        _read();
    } catch(...) {
        _clean_up();
        throw;
    }
}

void osu_db_t::bool_t::_read() {
    m_byte = m__io->read_s1();
}

osu_db_t::bool_t::~bool_t() {
    _clean_up();
}

void osu_db_t::bool_t::_clean_up() {
}

bool osu_db_t::bool_t::value() {
    if (f_value)
        return m_value;
    m_value = ((byte() == 0) ? (false) : (true));
    f_value = true;
    return m_value;
}

osu_db_t::int_double_pair_t::int_double_pair_t(kaitai::kstream* p__io, osu_db_t::int_double_pairs_t* p__parent, osu_db_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;

    try {
        _read();
    } catch(...) {
        _clean_up();
        throw;
    }
}

void osu_db_t::int_double_pair_t::_read() {
    m_magic1 = m__io->read_bytes(1);
    if (!(magic1() == std::string("\x08", 1))) {
        throw kaitai::validation_not_equal_error<std::string>(std::string("\x08", 1), magic1(), _io(), std::string("/types/int_double_pair/seq/0"));
    }
    m_int = m__io->read_s4le();
    m_magic2 = m__io->read_bytes(1);
    if (!(magic2() == std::string("\x0D", 1))) {
        throw kaitai::validation_not_equal_error<std::string>(std::string("\x0D", 1), magic2(), _io(), std::string("/types/int_double_pair/seq/2"));
    }
    m_double = m__io->read_f8le();
}

osu_db_t::int_double_pair_t::~int_double_pair_t() {
    _clean_up();
}

void osu_db_t::int_double_pair_t::_clean_up() {
}

osu_db_t::int_double_pairs_t::int_double_pairs_t(kaitai::kstream* p__io, osu_db_t::beatmap_t* p__parent, osu_db_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    m_pairs = 0;

    try {
        _read();
    } catch(...) {
        _clean_up();
        throw;
    }
}

void osu_db_t::int_double_pairs_t::_read() {
    m_num_pairs = m__io->read_s4le();
    int l_pairs = num_pairs();
    m_pairs = new std::vector<int_double_pair_t*>();
    m_pairs->reserve(l_pairs);
    for (int i = 0; i < l_pairs; i++) {
        m_pairs->push_back(new int_double_pair_t(m__io, this, m__root));
    }
}

osu_db_t::int_double_pairs_t::~int_double_pairs_t() {
    _clean_up();
}

void osu_db_t::int_double_pairs_t::_clean_up() {
    if (m_pairs) {
        for (std::vector<int_double_pair_t*>::iterator it = m_pairs->begin(); it != m_pairs->end(); ++it) {
            delete *it;
        }
        delete m_pairs; m_pairs = 0;
    }
}
