// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

using System.Collections.Generic;

namespace Kaitai
{

    /// <summary>
    /// osu!.db file format in rhythm game, osu!.
    /// </summary>
    /// <remarks>
    /// Reference: <a href="https://osu.ppy.sh/wiki/zh-tw/osu%21_File_Formats/Db_%28file_format%29">Source</a>
    /// </remarks>
    public partial class OsuDb : KaitaiStruct
    {
        public static OsuDb FromFile(string fileName)
        {
            return new OsuDb(new KaitaiStream(fileName));
        }

        public OsuDb(KaitaiStream p__io, KaitaiStruct p__parent = null, OsuDb p__root = null) : base(p__io)
        {
            m_parent = p__parent;
            m_root = p__root ?? this;
            _read();
        }
        private void _read()
        {
            _osuVersion = m_io.ReadS4le();
            _folderCount = m_io.ReadS4le();
            _accountUnlocked = new Bool(m_io, this, m_root);
            _accountUnlockDate = m_io.ReadS8le();
            _playerName = new String(m_io, this, m_root);
            _numBeatmaps = m_io.ReadS4le();
            _beatmaps = new List<Beatmap>((int) (NumBeatmaps));
            for (var i = 0; i < NumBeatmaps; i++)
            {
                _beatmaps.Add(new Beatmap(m_io, this, m_root));
            }
            _userPermissions = m_io.ReadS4le();
        }

        /// <summary>
        /// Consists of a Double, signifying the BPM, another Double,
        /// signifying the offset into the song, in milliseconds, and a Boolean;
        /// if false, then this timing point is inherited.
        /// See Osu (file format) for more information regarding timing points.
        /// </summary>
        public partial class TimingPoint : KaitaiStruct
        {
            public static TimingPoint FromFile(string fileName)
            {
                return new TimingPoint(new KaitaiStream(fileName));
            }

            public TimingPoint(KaitaiStream p__io, OsuDb.TimingPoints p__parent = null, OsuDb p__root = null) : base(p__io)
            {
                m_parent = p__parent;
                m_root = p__root;
                _read();
            }
            private void _read()
            {
                _bpm = m_io.ReadF8le();
                _offset = m_io.ReadF8le();
                _notInherited = new Bool(m_io, this, m_root);
            }
            private double _bpm;
            private double _offset;
            private Bool _notInherited;
            private OsuDb m_root;
            private OsuDb.TimingPoints m_parent;
            public double Bpm { get { return _bpm; } }
            public double Offset { get { return _offset; } }
            public Bool NotInherited { get { return _notInherited; } }
            public OsuDb M_Root { get { return m_root; } }
            public OsuDb.TimingPoints M_Parent { get { return m_parent; } }
        }
        public partial class String : KaitaiStruct
        {
            public static String FromFile(string fileName)
            {
                return new String(new KaitaiStream(fileName));
            }

            public String(KaitaiStream p__io, KaitaiStruct p__parent = null, OsuDb p__root = null) : base(p__io)
            {
                m_parent = p__parent;
                m_root = p__root;
                _read();
            }
            private void _read()
            {
                _isPresent = m_io.ReadS1();
                if (IsPresent == 11) {
                    _lenStr = new VlqBase128Le(m_io);
                }
                if (IsPresent == 11) {
                    _value = System.Text.Encoding.GetEncoding("UTF-8").GetString(m_io.ReadBytes(LenStr.Value));
                }
            }
            private sbyte _isPresent;
            private VlqBase128Le _lenStr;
            private string _value;
            private OsuDb m_root;
            private KaitaiStruct m_parent;
            public sbyte IsPresent { get { return _isPresent; } }
            public VlqBase128Le LenStr { get { return _lenStr; } }
            public string Value { get { return _value; } }
            public OsuDb M_Root { get { return m_root; } }
            public KaitaiStruct M_Parent { get { return m_parent; } }
        }
        public partial class Beatmap : KaitaiStruct
        {
            public static Beatmap FromFile(string fileName)
            {
                return new Beatmap(new KaitaiStream(fileName));
            }

            public Beatmap(KaitaiStream p__io, OsuDb p__parent = null, OsuDb p__root = null) : base(p__io)
            {
                m_parent = p__parent;
                m_root = p__root;
                _read();
            }
            private void _read()
            {
                if (M_Root.OsuVersion < 20191106) {
                    _lenBeatmap = m_io.ReadS4le();
                }
                _artistName = new String(m_io, this, m_root);
                _artistNameUnicode = new String(m_io, this, m_root);
                _songTitle = new String(m_io, this, m_root);
                _songTitleUnicode = new String(m_io, this, m_root);
                _creatorName = new String(m_io, this, m_root);
                _difficulty = new String(m_io, this, m_root);
                _audioFileName = new String(m_io, this, m_root);
                _md5Hash = new String(m_io, this, m_root);
                _osuFileName = new String(m_io, this, m_root);
                _rankedStatus = m_io.ReadS1();
                _numHitcircles = m_io.ReadS2le();
                _numSliders = m_io.ReadS2le();
                _numSpinners = m_io.ReadS2le();
                _lastModificationTime = m_io.ReadS8le();
                if (M_Root.OsuVersion < 20140609) {
                    _approachRateByte = m_io.ReadS1();
                }
                if (M_Root.OsuVersion >= 20140609) {
                    _approachRate = m_io.ReadF4le();
                }
                if (M_Root.OsuVersion < 20140609) {
                    _circleSizeByte = m_io.ReadS1();
                }
                if (M_Root.OsuVersion >= 20140609) {
                    _circleSize = m_io.ReadF4le();
                }
                if (M_Root.OsuVersion < 20140609) {
                    _hpDrainByte = m_io.ReadS1();
                }
                if (M_Root.OsuVersion >= 20140609) {
                    _hpDrain = m_io.ReadF4le();
                }
                if (M_Root.OsuVersion < 20140609) {
                    _overallDifficultyByte = m_io.ReadS1();
                }
                if (M_Root.OsuVersion >= 20140609) {
                    _overallDifficulty = m_io.ReadF4le();
                }
                _sliderVelocity = m_io.ReadF8le();
                if (M_Root.OsuVersion >= 20140609) {
                    _starRatingOsu = new IntDoublePairs(m_io, this, m_root);
                }
                if (M_Root.OsuVersion >= 20140609) {
                    _starRatingTaiko = new IntDoublePairs(m_io, this, m_root);
                }
                if (M_Root.OsuVersion >= 20140609) {
                    _starRatingCtb = new IntDoublePairs(m_io, this, m_root);
                }
                if (M_Root.OsuVersion >= 20140609) {
                    _starRatingMania = new IntDoublePairs(m_io, this, m_root);
                }
                _drainTime = m_io.ReadS4le();
                _totalTime = m_io.ReadS4le();
                _audioPreviewStartTime = m_io.ReadS4le();
                _timingPoints = new TimingPoints(m_io, this, m_root);
                _beatmapId = m_io.ReadS4le();
                _beatmapSetId = m_io.ReadS4le();
                _threadId = m_io.ReadS4le();
                _gradeOsu = m_io.ReadS1();
                _gradeTaiko = m_io.ReadS1();
                _gradeCtb = m_io.ReadS1();
                _gradeMania = m_io.ReadS1();
                _localBeatmapOffset = m_io.ReadS2le();
                _stackLeniency = m_io.ReadF4le();
                _gameplayMode = m_io.ReadS1();
                _songSource = new String(m_io, this, m_root);
                _songTags = new String(m_io, this, m_root);
                _onlineOffset = m_io.ReadS2le();
                _songTitleFont = new String(m_io, this, m_root);
                _isUnplayed = new Bool(m_io, this, m_root);
                _lastPlayedTime = m_io.ReadS8le();
                _isOsz2 = new Bool(m_io, this, m_root);
                _folderName = new String(m_io, this, m_root);
                _lastCheckRepoTime = m_io.ReadS8le();
                _ignoreSound = new Bool(m_io, this, m_root);
                _ignoreSkin = new Bool(m_io, this, m_root);
                _disableStoryboard = new Bool(m_io, this, m_root);
                _disableVideo = new Bool(m_io, this, m_root);
                _visualOverride = new Bool(m_io, this, m_root);
                if (M_Root.OsuVersion < 20140609) {
                    _unknownShort = m_io.ReadS2le();
                }
                _lastModificationTimeInt = m_io.ReadS4le();
                _maniaScrollSpeed = m_io.ReadS1();
            }
            private int? _lenBeatmap;
            private String _artistName;
            private String _artistNameUnicode;
            private String _songTitle;
            private String _songTitleUnicode;
            private String _creatorName;
            private String _difficulty;
            private String _audioFileName;
            private String _md5Hash;
            private String _osuFileName;
            private sbyte _rankedStatus;
            private short _numHitcircles;
            private short _numSliders;
            private short _numSpinners;
            private long _lastModificationTime;
            private sbyte? _approachRateByte;
            private float? _approachRate;
            private sbyte? _circleSizeByte;
            private float? _circleSize;
            private sbyte? _hpDrainByte;
            private float? _hpDrain;
            private sbyte? _overallDifficultyByte;
            private float? _overallDifficulty;
            private double _sliderVelocity;
            private IntDoublePairs _starRatingOsu;
            private IntDoublePairs _starRatingTaiko;
            private IntDoublePairs _starRatingCtb;
            private IntDoublePairs _starRatingMania;
            private int _drainTime;
            private int _totalTime;
            private int _audioPreviewStartTime;
            private TimingPoints _timingPoints;
            private int _beatmapId;
            private int _beatmapSetId;
            private int _threadId;
            private sbyte _gradeOsu;
            private sbyte _gradeTaiko;
            private sbyte _gradeCtb;
            private sbyte _gradeMania;
            private short _localBeatmapOffset;
            private float _stackLeniency;
            private sbyte _gameplayMode;
            private String _songSource;
            private String _songTags;
            private short _onlineOffset;
            private String _songTitleFont;
            private Bool _isUnplayed;
            private long _lastPlayedTime;
            private Bool _isOsz2;
            private String _folderName;
            private long _lastCheckRepoTime;
            private Bool _ignoreSound;
            private Bool _ignoreSkin;
            private Bool _disableStoryboard;
            private Bool _disableVideo;
            private Bool _visualOverride;
            private short? _unknownShort;
            private int _lastModificationTimeInt;
            private sbyte _maniaScrollSpeed;
            private OsuDb m_root;
            private OsuDb m_parent;

            /// <summary>
            /// Int,	Size in bytes of the beatmap entry. Only present if version is less than 20191106.
            /// </summary>
            public int? LenBeatmap { get { return _lenBeatmap; } }

            /// <summary>
            /// String, Artist name
            /// </summary>
            public String ArtistName { get { return _artistName; } }

            /// <summary>
            /// String, Artist name, in Unicode
            /// </summary>
            public String ArtistNameUnicode { get { return _artistNameUnicode; } }

            /// <summary>
            /// String, Song title
            /// </summary>
            public String SongTitle { get { return _songTitle; } }

            /// <summary>
            /// String, Song title, in Unicode
            /// </summary>
            public String SongTitleUnicode { get { return _songTitleUnicode; } }

            /// <summary>
            /// String, Creator name
            /// </summary>
            public String CreatorName { get { return _creatorName; } }

            /// <summary>
            /// String, Difficulty (e.g. Hard, Insane, etc.)
            /// </summary>
            public String Difficulty { get { return _difficulty; } }

            /// <summary>
            /// String, Audio file name
            /// </summary>
            public String AudioFileName { get { return _audioFileName; } }

            /// <summary>
            /// String, MD5 hash of the beatmap
            /// </summary>
            public String Md5Hash { get { return _md5Hash; } }

            /// <summary>
            /// String, Name of the .osu file corresponding to this beatmap
            /// </summary>
            public String OsuFileName { get { return _osuFileName; } }

            /// <summary>
            /// Byte, Ranked status (0 = unknown, 1 = unsubmitted, 2 = pending/wip/graveyard, 3 = unused, 4 = ranked, 5 = approved, 6 = qualified, 7 = loved)
            /// </summary>
            public sbyte RankedStatus { get { return _rankedStatus; } }

            /// <summary>
            /// Short, Number of hitcircles
            /// </summary>
            public short NumHitcircles { get { return _numHitcircles; } }

            /// <summary>
            /// Short, Number of sliders (note: this will be present in every mode)
            /// </summary>
            public short NumSliders { get { return _numSliders; } }

            /// <summary>
            /// Short, Number of spinners (note: this will be present in every mode)
            /// </summary>
            public short NumSpinners { get { return _numSpinners; } }

            /// <summary>
            /// Long, Last modification time, Windows ticks.
            /// </summary>
            public long LastModificationTime { get { return _lastModificationTime; } }

            /// <summary>
            /// Byte/Single, Approach rate. Byte if the version is less than 20140609, Single otherwise.
            /// </summary>
            public sbyte? ApproachRateByte { get { return _approachRateByte; } }

            /// <summary>
            /// Byte/Single, Approach rate. Byte if the version is less than 20140609, Single otherwise.
            /// </summary>
            public float? ApproachRate { get { return _approachRate; } }

            /// <summary>
            /// Byte/Single, Circle size. Byte if the version is less than 20140609, Single otherwise.
            /// </summary>
            public sbyte? CircleSizeByte { get { return _circleSizeByte; } }

            /// <summary>
            /// Byte/Single, Circle size. Byte if the version is less than 20140609, Single otherwise.
            /// </summary>
            public float? CircleSize { get { return _circleSize; } }

            /// <summary>
            /// Byte/Single, HP drain. Byte if the version is less than 20140609, Single otherwise.
            /// </summary>
            public sbyte? HpDrainByte { get { return _hpDrainByte; } }

            /// <summary>
            /// Byte/Single, HP drain. Byte if the version is less than 20140609, Single otherwise.
            /// </summary>
            public float? HpDrain { get { return _hpDrain; } }

            /// <summary>
            /// Byte/Single, Overall difficulty. Byte if the version is less than 20140609, Single otherwise.
            /// </summary>
            public sbyte? OverallDifficultyByte { get { return _overallDifficultyByte; } }

            /// <summary>
            /// Byte/Single, Overall difficulty. Byte if the version is less than 20140609, Single otherwise.
            /// </summary>
            public float? OverallDifficulty { get { return _overallDifficulty; } }

            /// <summary>
            /// Double, Slider velocity
            /// </summary>
            public double SliderVelocity { get { return _sliderVelocity; } }

            /// <summary>
            /// Int-Double pair*, Star Rating info for osu! standard, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
            /// </summary>
            public IntDoublePairs StarRatingOsu { get { return _starRatingOsu; } }

            /// <summary>
            /// Int-Double pair*, Star Rating info for Taiko, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
            /// </summary>
            public IntDoublePairs StarRatingTaiko { get { return _starRatingTaiko; } }

            /// <summary>
            /// Int-Double pair*, Star Rating info for CTB, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
            /// </summary>
            public IntDoublePairs StarRatingCtb { get { return _starRatingCtb; } }

            /// <summary>
            /// Int-Double pair*, Star Rating info for osu!mania, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
            /// </summary>
            public IntDoublePairs StarRatingMania { get { return _starRatingMania; } }

            /// <summary>
            /// Int, Drain time, in seconds
            /// </summary>
            public int DrainTime { get { return _drainTime; } }

            /// <summary>
            /// Int, Total time, in milliseconds
            /// </summary>
            public int TotalTime { get { return _totalTime; } }

            /// <summary>
            /// Int, Time when the audio preview when hovering over a beatmap in beatmap select starts, in milliseconds.
            /// </summary>
            public int AudioPreviewStartTime { get { return _audioPreviewStartTime; } }

            /// <summary>
            /// Timing point+, An Int indicating the number of following Timing points, then the aforementioned Timing points.
            /// </summary>
            public TimingPoints TimingPoints { get { return _timingPoints; } }

            /// <summary>
            /// Int, Beatmap ID
            /// </summary>
            public int BeatmapId { get { return _beatmapId; } }

            /// <summary>
            /// Int, Beatmap set ID
            /// </summary>
            public int BeatmapSetId { get { return _beatmapSetId; } }

            /// <summary>
            /// Int, Thread ID
            /// </summary>
            public int ThreadId { get { return _threadId; } }

            /// <summary>
            /// Byte, Grade achieved in osu! standard.
            /// </summary>
            public sbyte GradeOsu { get { return _gradeOsu; } }

            /// <summary>
            /// Byte, Grade achieved in Taiko.
            /// </summary>
            public sbyte GradeTaiko { get { return _gradeTaiko; } }

            /// <summary>
            /// Byte, Grade achieved in CTB.
            /// </summary>
            public sbyte GradeCtb { get { return _gradeCtb; } }

            /// <summary>
            /// Byte, Grade achieved in osu!mania.
            /// </summary>
            public sbyte GradeMania { get { return _gradeMania; } }

            /// <summary>
            /// Short, Local beatmap offset
            /// </summary>
            public short LocalBeatmapOffset { get { return _localBeatmapOffset; } }

            /// <summary>
            /// Single, Stack leniency
            /// </summary>
            public float StackLeniency { get { return _stackLeniency; } }

            /// <summary>
            /// Byte, Osu gameplay mode. 0x00 = osu!Standard, 0x01 = Taiko, 0x02 = CTB, 0x03 = Mania
            /// </summary>
            public sbyte GameplayMode { get { return _gameplayMode; } }

            /// <summary>
            /// String, Song source
            /// </summary>
            public String SongSource { get { return _songSource; } }

            /// <summary>
            /// String, Song tags
            /// </summary>
            public String SongTags { get { return _songTags; } }

            /// <summary>
            /// Short, Online offset
            /// </summary>
            public short OnlineOffset { get { return _onlineOffset; } }

            /// <summary>
            /// String, Font used for the title of the song
            /// </summary>
            public String SongTitleFont { get { return _songTitleFont; } }

            /// <summary>
            /// Boolean, Is beatmap unplayed
            /// </summary>
            public Bool IsUnplayed { get { return _isUnplayed; } }

            /// <summary>
            /// Long, Last time when beatmap was played
            /// </summary>
            public long LastPlayedTime { get { return _lastPlayedTime; } }

            /// <summary>
            /// Boolean, Is the beatmap osz2
            /// </summary>
            public Bool IsOsz2 { get { return _isOsz2; } }

            /// <summary>
            /// String, Folder name of the beatmap, relative to Songs folder
            /// </summary>
            public String FolderName { get { return _folderName; } }

            /// <summary>
            /// Long, Last time when beatmap was checked against osu! repository
            /// </summary>
            public long LastCheckRepoTime { get { return _lastCheckRepoTime; } }

            /// <summary>
            /// Boolean, Ignore beatmap sound
            /// </summary>
            public Bool IgnoreSound { get { return _ignoreSound; } }

            /// <summary>
            /// Boolean, Ignore beatmap skin
            /// </summary>
            public Bool IgnoreSkin { get { return _ignoreSkin; } }

            /// <summary>
            /// Boolean, Disable storyboard
            /// </summary>
            public Bool DisableStoryboard { get { return _disableStoryboard; } }

            /// <summary>
            /// Boolean, Disable video
            /// </summary>
            public Bool DisableVideo { get { return _disableVideo; } }

            /// <summary>
            /// Boolean, Visual override
            /// </summary>
            public Bool VisualOverride { get { return _visualOverride; } }

            /// <summary>
            /// Short?, Unknown. Only present if version is less than 20140609.
            /// </summary>
            public short? UnknownShort { get { return _unknownShort; } }

            /// <summary>
            /// Int, Last modification time (?)
            /// </summary>
            public int LastModificationTimeInt { get { return _lastModificationTimeInt; } }

            /// <summary>
            /// Byte, Mania scroll speed
            /// </summary>
            public sbyte ManiaScrollSpeed { get { return _maniaScrollSpeed; } }
            public OsuDb M_Root { get { return m_root; } }
            public OsuDb M_Parent { get { return m_parent; } }
        }

        /// <summary>
        /// An Int indicating the number of following Timing points, then the aforementioned Timing points.
        /// </summary>
        public partial class TimingPoints : KaitaiStruct
        {
            public static TimingPoints FromFile(string fileName)
            {
                return new TimingPoints(new KaitaiStream(fileName));
            }

            public TimingPoints(KaitaiStream p__io, OsuDb.Beatmap p__parent = null, OsuDb p__root = null) : base(p__io)
            {
                m_parent = p__parent;
                m_root = p__root;
                _read();
            }
            private void _read()
            {
                _numPoints = m_io.ReadS4le();
                _points = new List<TimingPoint>((int) (NumPoints));
                for (var i = 0; i < NumPoints; i++)
                {
                    _points.Add(new TimingPoint(m_io, this, m_root));
                }
            }
            private int _numPoints;
            private List<TimingPoint> _points;
            private OsuDb m_root;
            private OsuDb.Beatmap m_parent;
            public int NumPoints { get { return _numPoints; } }
            public List<TimingPoint> Points { get { return _points; } }
            public OsuDb M_Root { get { return m_root; } }
            public OsuDb.Beatmap M_Parent { get { return m_parent; } }
        }
        public partial class Bool : KaitaiStruct
        {
            public static Bool FromFile(string fileName)
            {
                return new Bool(new KaitaiStream(fileName));
            }

            public Bool(KaitaiStream p__io, KaitaiStruct p__parent = null, OsuDb p__root = null) : base(p__io)
            {
                m_parent = p__parent;
                m_root = p__root;
                f_value = false;
                _read();
            }
            private void _read()
            {
                _byte = m_io.ReadS1();
            }
            private bool f_value;
            private bool _value;
            public bool Value
            {
                get
                {
                    if (f_value)
                        return _value;
                    _value = (bool) ((Byte == 0 ? false : true));
                    f_value = true;
                    return _value;
                }
            }
            private sbyte _byte;
            private OsuDb m_root;
            private KaitaiStruct m_parent;
            public sbyte Byte { get { return _byte; } }
            public OsuDb M_Root { get { return m_root; } }
            public KaitaiStruct M_Parent { get { return m_parent; } }
        }

        /// <summary>
        /// The first byte is 0x08, followed by an Int, then 0x0d, followed by a Double.
        /// These extraneous bytes are presumably flags to signify different data types
        /// in these slots, though in practice no other such flags have been seen.
        /// Currently the purpose of this data type is unknown.
        /// </summary>
        public partial class IntDoublePair : KaitaiStruct
        {
            public static IntDoublePair FromFile(string fileName)
            {
                return new IntDoublePair(new KaitaiStream(fileName));
            }

            public IntDoublePair(KaitaiStream p__io, OsuDb.IntDoublePairs p__parent = null, OsuDb p__root = null) : base(p__io)
            {
                m_parent = p__parent;
                m_root = p__root;
                _read();
            }
            private void _read()
            {
                _magic1 = m_io.ReadBytes(1);
                if (!((KaitaiStream.ByteArrayCompare(Magic1, new byte[] { 8 }) == 0)))
                {
                    throw new ValidationNotEqualError(new byte[] { 8 }, Magic1, M_Io, "/types/int_double_pair/seq/0");
                }
                _int = m_io.ReadS4le();
                _magic2 = m_io.ReadBytes(1);
                if (!((KaitaiStream.ByteArrayCompare(Magic2, new byte[] { 13 }) == 0)))
                {
                    throw new ValidationNotEqualError(new byte[] { 13 }, Magic2, M_Io, "/types/int_double_pair/seq/2");
                }
                _double = m_io.ReadF8le();
            }
            private byte[] _magic1;
            private int _int;
            private byte[] _magic2;
            private double _double;
            private OsuDb m_root;
            private OsuDb.IntDoublePairs m_parent;
            public byte[] Magic1 { get { return _magic1; } }
            public int Int { get { return _int; } }
            public byte[] Magic2 { get { return _magic2; } }
            public double Double { get { return _double; } }
            public OsuDb M_Root { get { return m_root; } }
            public OsuDb.IntDoublePairs M_Parent { get { return m_parent; } }
        }

        /// <summary>
        /// An Int indicating the number of following Int-Double pairs, then the aforementioned pairs.
        /// </summary>
        public partial class IntDoublePairs : KaitaiStruct
        {
            public static IntDoublePairs FromFile(string fileName)
            {
                return new IntDoublePairs(new KaitaiStream(fileName));
            }

            public IntDoublePairs(KaitaiStream p__io, OsuDb.Beatmap p__parent = null, OsuDb p__root = null) : base(p__io)
            {
                m_parent = p__parent;
                m_root = p__root;
                _read();
            }
            private void _read()
            {
                _numPairs = m_io.ReadS4le();
                _pairs = new List<IntDoublePair>((int) (NumPairs));
                for (var i = 0; i < NumPairs; i++)
                {
                    _pairs.Add(new IntDoublePair(m_io, this, m_root));
                }
            }
            private int _numPairs;
            private List<IntDoublePair> _pairs;
            private OsuDb m_root;
            private OsuDb.Beatmap m_parent;
            public int NumPairs { get { return _numPairs; } }
            public List<IntDoublePair> Pairs { get { return _pairs; } }
            public OsuDb M_Root { get { return m_root; } }
            public OsuDb.Beatmap M_Parent { get { return m_parent; } }
        }
        private int _osuVersion;
        private int _folderCount;
        private Bool _accountUnlocked;
        private long _accountUnlockDate;
        private String _playerName;
        private int _numBeatmaps;
        private List<Beatmap> _beatmaps;
        private int _userPermissions;
        private OsuDb m_root;
        private KaitaiStruct m_parent;

        /// <summary>
        /// Int, osu! version (e.g. 20150203)
        /// </summary>
        public int OsuVersion { get { return _osuVersion; } }

        /// <summary>
        /// Int, Folder Count
        /// </summary>
        public int FolderCount { get { return _folderCount; } }

        /// <summary>
        /// Bool, AccountUnlocked (only false when the account is locked or banned in any way)
        /// </summary>
        public Bool AccountUnlocked { get { return _accountUnlocked; } }

        /// <summary>
        /// DateTime, Date the account will be unlocked
        /// </summary>
        public long AccountUnlockDate { get { return _accountUnlockDate; } }

        /// <summary>
        /// String, Player name
        /// </summary>
        public String PlayerName { get { return _playerName; } }

        /// <summary>
        /// Int, Number of beatmaps
        /// </summary>
        public int NumBeatmaps { get { return _numBeatmaps; } }

        /// <summary>
        /// Beatmaps*, Aforementioned beatmaps
        /// </summary>
        public List<Beatmap> Beatmaps { get { return _beatmaps; } }

        /// <summary>
        /// Int, User permissions (0 = None, 1 = Normal, 2 = Moderator, 4 = Supporter, 8 = Friend, 16 = peppy, 32 = World Cup staff)
        /// </summary>
        public int UserPermissions { get { return _userPermissions; } }
        public OsuDb M_Root { get { return m_root; } }
        public KaitaiStruct M_Parent { get { return m_parent; } }
    }
}
