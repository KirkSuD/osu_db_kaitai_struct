// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

(function (root, factory) {
  if (typeof define === 'function' && define.amd) {
    define(['kaitai-struct/KaitaiStream', './VlqBase128Le'], factory);
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory(require('kaitai-struct/KaitaiStream'), require('./VlqBase128Le'));
  } else {
    root.OsuDb = factory(root.KaitaiStream, root.VlqBase128Le);
  }
}(this, function (KaitaiStream, VlqBase128Le) {
/**
 * osu!.db file format in rhythm game, osu!.
 * @see {@link https://osu.ppy.sh/wiki/zh-tw/osu%21_File_Formats/Db_%28file_format%29|Source}
 */

var OsuDb = (function() {
  function OsuDb(_io, _parent, _root) {
    this._io = _io;
    this._parent = _parent;
    this._root = _root || this;

    this._read();
  }
  OsuDb.prototype._read = function() {
    this.osuVersion = this._io.readS4le();
    this.folderCount = this._io.readS4le();
    this.accountUnlocked = new Bool(this._io, this, this._root);
    this.accountUnlockDate = this._io.readS8le();
    this.playerName = new String(this._io, this, this._root);
    this.numBeatmaps = this._io.readS4le();
    this.beatmaps = new Array(this.numBeatmaps);
    for (var i = 0; i < this.numBeatmaps; i++) {
      this.beatmaps[i] = new Beatmap(this._io, this, this._root);
    }
    this.userPermissions = this._io.readS4le();
  }

  /**
   * Consists of a Double, signifying the BPM, another Double,
   * signifying the offset into the song, in milliseconds, and a Boolean;
   * if false, then this timing point is inherited.
   * See Osu (file format) for more information regarding timing points.
   */

  var TimingPoint = OsuDb.TimingPoint = (function() {
    function TimingPoint(_io, _parent, _root) {
      this._io = _io;
      this._parent = _parent;
      this._root = _root || this;

      this._read();
    }
    TimingPoint.prototype._read = function() {
      this.bpm = this._io.readF8le();
      this.offset = this._io.readF8le();
      this.notInherited = new Bool(this._io, this, this._root);
    }

    return TimingPoint;
  })();

  var String = OsuDb.String = (function() {
    function String(_io, _parent, _root) {
      this._io = _io;
      this._parent = _parent;
      this._root = _root || this;

      this._read();
    }
    String.prototype._read = function() {
      this.isPresent = this._io.readS1();
      if (this.isPresent == 11) {
        this.lenStr = new VlqBase128Le(this._io, this, null);
      }
      if (this.isPresent == 11) {
        this.value = KaitaiStream.bytesToStr(this._io.readBytes(this.lenStr.value), "UTF-8");
      }
    }

    return String;
  })();

  var Beatmap = OsuDb.Beatmap = (function() {
    function Beatmap(_io, _parent, _root) {
      this._io = _io;
      this._parent = _parent;
      this._root = _root || this;

      this._read();
    }
    Beatmap.prototype._read = function() {
      if (this._root.osuVersion < 20191106) {
        this.lenBeatmap = this._io.readS4le();
      }
      this.artistName = new String(this._io, this, this._root);
      this.artistNameUnicode = new String(this._io, this, this._root);
      this.songTitle = new String(this._io, this, this._root);
      this.songTitleUnicode = new String(this._io, this, this._root);
      this.creatorName = new String(this._io, this, this._root);
      this.difficulty = new String(this._io, this, this._root);
      this.audioFileName = new String(this._io, this, this._root);
      this.md5Hash = new String(this._io, this, this._root);
      this.osuFileName = new String(this._io, this, this._root);
      this.rankedStatus = this._io.readS1();
      this.numHitcircles = this._io.readS2le();
      this.numSliders = this._io.readS2le();
      this.numSpinners = this._io.readS2le();
      this.lastModificationTime = this._io.readS8le();
      if (this._root.osuVersion < 20140609) {
        this.approachRateByte = this._io.readS1();
      }
      if (this._root.osuVersion >= 20140609) {
        this.approachRate = this._io.readF4le();
      }
      if (this._root.osuVersion < 20140609) {
        this.circleSizeByte = this._io.readS1();
      }
      if (this._root.osuVersion >= 20140609) {
        this.circleSize = this._io.readF4le();
      }
      if (this._root.osuVersion < 20140609) {
        this.hpDrainByte = this._io.readS1();
      }
      if (this._root.osuVersion >= 20140609) {
        this.hpDrain = this._io.readF4le();
      }
      if (this._root.osuVersion < 20140609) {
        this.overallDifficultyByte = this._io.readS1();
      }
      if (this._root.osuVersion >= 20140609) {
        this.overallDifficulty = this._io.readF4le();
      }
      this.sliderVelocity = this._io.readF8le();
      if (this._root.osuVersion >= 20140609) {
        this.starRatingOsu = new IntDoublePairs(this._io, this, this._root);
      }
      if (this._root.osuVersion >= 20140609) {
        this.starRatingTaiko = new IntDoublePairs(this._io, this, this._root);
      }
      if (this._root.osuVersion >= 20140609) {
        this.starRatingCtb = new IntDoublePairs(this._io, this, this._root);
      }
      if (this._root.osuVersion >= 20140609) {
        this.starRatingMania = new IntDoublePairs(this._io, this, this._root);
      }
      this.drainTime = this._io.readS4le();
      this.totalTime = this._io.readS4le();
      this.audioPreviewStartTime = this._io.readS4le();
      this.timingPoints = new TimingPoints(this._io, this, this._root);
      this.beatmapId = this._io.readS4le();
      this.beatmapSetId = this._io.readS4le();
      this.threadId = this._io.readS4le();
      this.gradeOsu = this._io.readS1();
      this.gradeTaiko = this._io.readS1();
      this.gradeCtb = this._io.readS1();
      this.gradeMania = this._io.readS1();
      this.localBeatmapOffset = this._io.readS2le();
      this.stackLeniency = this._io.readF4le();
      this.gameplayMode = this._io.readS1();
      this.songSource = new String(this._io, this, this._root);
      this.songTags = new String(this._io, this, this._root);
      this.onlineOffset = this._io.readS2le();
      this.songTitleFont = new String(this._io, this, this._root);
      this.isUnplayed = new Bool(this._io, this, this._root);
      this.lastPlayedTime = this._io.readS8le();
      this.isOsz2 = new Bool(this._io, this, this._root);
      this.folderName = new String(this._io, this, this._root);
      this.lastCheckRepoTime = this._io.readS8le();
      this.ignoreSound = new Bool(this._io, this, this._root);
      this.ignoreSkin = new Bool(this._io, this, this._root);
      this.disableStoryboard = new Bool(this._io, this, this._root);
      this.disableVideo = new Bool(this._io, this, this._root);
      this.visualOverride = new Bool(this._io, this, this._root);
      if (this._root.osuVersion < 20140609) {
        this.unknownShort = this._io.readS2le();
      }
      this.lastModificationTimeInt = this._io.readS4le();
      this.maniaScrollSpeed = this._io.readS1();
    }

    /**
     * Int,	Size in bytes of the beatmap entry. Only present if version is less than 20191106.
     */

    /**
     * String, Artist name
     */

    /**
     * String, Artist name, in Unicode
     */

    /**
     * String, Song title
     */

    /**
     * String, Song title, in Unicode
     */

    /**
     * String, Creator name
     */

    /**
     * String, Difficulty (e.g. Hard, Insane, etc.)
     */

    /**
     * String, Audio file name
     */

    /**
     * String, MD5 hash of the beatmap
     */

    /**
     * String, Name of the .osu file corresponding to this beatmap
     */

    /**
     * Byte, Ranked status (0 = unknown, 1 = unsubmitted, 2 = pending/wip/graveyard, 3 = unused, 4 = ranked, 5 = approved, 6 = qualified, 7 = loved)
     */

    /**
     * Short, Number of hitcircles
     */

    /**
     * Short, Number of sliders (note: this will be present in every mode)
     */

    /**
     * Short, Number of spinners (note: this will be present in every mode)
     */

    /**
     * Long, Last modification time, Windows ticks.
     */

    /**
     * Byte/Single, Approach rate. Byte if the version is less than 20140609, Single otherwise.
     */

    /**
     * Byte/Single, Approach rate. Byte if the version is less than 20140609, Single otherwise.
     */

    /**
     * Byte/Single, Circle size. Byte if the version is less than 20140609, Single otherwise.
     */

    /**
     * Byte/Single, Circle size. Byte if the version is less than 20140609, Single otherwise.
     */

    /**
     * Byte/Single, HP drain. Byte if the version is less than 20140609, Single otherwise.
     */

    /**
     * Byte/Single, HP drain. Byte if the version is less than 20140609, Single otherwise.
     */

    /**
     * Byte/Single, Overall difficulty. Byte if the version is less than 20140609, Single otherwise.
     */

    /**
     * Byte/Single, Overall difficulty. Byte if the version is less than 20140609, Single otherwise.
     */

    /**
     * Double, Slider velocity
     */

    /**
     * Int-Double pair*, Star Rating info for osu! standard, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
     */

    /**
     * Int-Double pair*, Star Rating info for Taiko, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
     */

    /**
     * Int-Double pair*, Star Rating info for CTB, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
     */

    /**
     * Int-Double pair*, Star Rating info for osu!mania, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
     */

    /**
     * Int, Drain time, in seconds
     */

    /**
     * Int, Total time, in milliseconds
     */

    /**
     * Int, Time when the audio preview when hovering over a beatmap in beatmap select starts, in milliseconds.
     */

    /**
     * Timing point+, An Int indicating the number of following Timing points, then the aforementioned Timing points.
     */

    /**
     * Int, Beatmap ID
     */

    /**
     * Int, Beatmap set ID
     */

    /**
     * Int, Thread ID
     */

    /**
     * Byte, Grade achieved in osu! standard.
     */

    /**
     * Byte, Grade achieved in Taiko.
     */

    /**
     * Byte, Grade achieved in CTB.
     */

    /**
     * Byte, Grade achieved in osu!mania.
     */

    /**
     * Short, Local beatmap offset
     */

    /**
     * Single, Stack leniency
     */

    /**
     * Byte, Osu gameplay mode. 0x00 = osu!Standard, 0x01 = Taiko, 0x02 = CTB, 0x03 = Mania
     */

    /**
     * String, Song source
     */

    /**
     * String, Song tags
     */

    /**
     * Short, Online offset
     */

    /**
     * String, Font used for the title of the song
     */

    /**
     * Boolean, Is beatmap unplayed
     */

    /**
     * Long, Last time when beatmap was played
     */

    /**
     * Boolean, Is the beatmap osz2
     */

    /**
     * String, Folder name of the beatmap, relative to Songs folder
     */

    /**
     * Long, Last time when beatmap was checked against osu! repository
     */

    /**
     * Boolean, Ignore beatmap sound
     */

    /**
     * Boolean, Ignore beatmap skin
     */

    /**
     * Boolean, Disable storyboard
     */

    /**
     * Boolean, Disable video
     */

    /**
     * Boolean, Visual override
     */

    /**
     * Short?, Unknown. Only present if version is less than 20140609.
     */

    /**
     * Int, Last modification time (?)
     */

    /**
     * Byte, Mania scroll speed
     */

    return Beatmap;
  })();

  /**
   * An Int indicating the number of following Timing points, then the aforementioned Timing points.
   */

  var TimingPoints = OsuDb.TimingPoints = (function() {
    function TimingPoints(_io, _parent, _root) {
      this._io = _io;
      this._parent = _parent;
      this._root = _root || this;

      this._read();
    }
    TimingPoints.prototype._read = function() {
      this.numPoints = this._io.readS4le();
      this.points = new Array(this.numPoints);
      for (var i = 0; i < this.numPoints; i++) {
        this.points[i] = new TimingPoint(this._io, this, this._root);
      }
    }

    return TimingPoints;
  })();

  var Bool = OsuDb.Bool = (function() {
    function Bool(_io, _parent, _root) {
      this._io = _io;
      this._parent = _parent;
      this._root = _root || this;

      this._read();
    }
    Bool.prototype._read = function() {
      this.byte = this._io.readS1();
    }
    Object.defineProperty(Bool.prototype, 'value', {
      get: function() {
        if (this._m_value !== undefined)
          return this._m_value;
        this._m_value = (this.byte == 0 ? false : true);
        return this._m_value;
      }
    });

    return Bool;
  })();

  /**
   * The first byte is 0x08, followed by an Int, then 0x0d, followed by a Double.
   * These extraneous bytes are presumably flags to signify different data types
   * in these slots, though in practice no other such flags have been seen.
   * Currently the purpose of this data type is unknown.
   */

  var IntDoublePair = OsuDb.IntDoublePair = (function() {
    function IntDoublePair(_io, _parent, _root) {
      this._io = _io;
      this._parent = _parent;
      this._root = _root || this;

      this._read();
    }
    IntDoublePair.prototype._read = function() {
      this.magic1 = this._io.readBytes(1);
      if (!((KaitaiStream.byteArrayCompare(this.magic1, [8]) == 0))) {
        throw new KaitaiStream.ValidationNotEqualError([8], this.magic1, this._io, "/types/int_double_pair/seq/0");
      }
      this.int = this._io.readS4le();
      this.magic2 = this._io.readBytes(1);
      if (!((KaitaiStream.byteArrayCompare(this.magic2, [13]) == 0))) {
        throw new KaitaiStream.ValidationNotEqualError([13], this.magic2, this._io, "/types/int_double_pair/seq/2");
      }
      this.double = this._io.readF8le();
    }

    return IntDoublePair;
  })();

  /**
   * An Int indicating the number of following Int-Double pairs, then the aforementioned pairs.
   */

  var IntDoublePairs = OsuDb.IntDoublePairs = (function() {
    function IntDoublePairs(_io, _parent, _root) {
      this._io = _io;
      this._parent = _parent;
      this._root = _root || this;

      this._read();
    }
    IntDoublePairs.prototype._read = function() {
      this.numPairs = this._io.readS4le();
      this.pairs = new Array(this.numPairs);
      for (var i = 0; i < this.numPairs; i++) {
        this.pairs[i] = new IntDoublePair(this._io, this, this._root);
      }
    }

    return IntDoublePairs;
  })();

  /**
   * Int, osu! version (e.g. 20150203)
   */

  /**
   * Int, Folder Count
   */

  /**
   * Bool, AccountUnlocked (only false when the account is locked or banned in any way)
   */

  /**
   * DateTime, Date the account will be unlocked
   */

  /**
   * String, Player name
   */

  /**
   * Int, Number of beatmaps
   */

  /**
   * Beatmaps*, Aforementioned beatmaps
   */

  /**
   * Int, User permissions (0 = None, 1 = Normal, 2 = Moderator, 4 = Supporter, 8 = Friend, 16 = peppy, 32 = World Cup staff)
   */

  return OsuDb;
})();
return OsuDb;
}));
