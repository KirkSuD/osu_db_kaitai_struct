# This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

require 'kaitai/struct/struct'

unless Gem::Version.new(Kaitai::Struct::VERSION) >= Gem::Version.new('0.9')
  raise "Incompatible Kaitai Struct Ruby API: 0.9 or later is required, but you have #{Kaitai::Struct::VERSION}"
end


##
# osu!.db file format in rhythm game, osu!.
# @see https://osu.ppy.sh/wiki/zh-tw/osu%21_File_Formats/Db_%28file_format%29 Source
class OsuDb < Kaitai::Struct::Struct
  def initialize(_io, _parent = nil, _root = self)
    super(_io, _parent, _root)
    _read
  end

  def _read
    @osu_version = @_io.read_s4le
    @folder_count = @_io.read_s4le
    @account_unlocked = Bool.new(@_io, self, @_root)
    @account_unlock_date = @_io.read_s8le
    @player_name = String.new(@_io, self, @_root)
    @num_beatmaps = @_io.read_s4le
    @beatmaps = Array.new(num_beatmaps)
    (num_beatmaps).times { |i|
      @beatmaps[i] = Beatmap.new(@_io, self, @_root)
    }
    @user_permissions = @_io.read_s4le
    self
  end

  ##
  # Consists of a Double, signifying the BPM, another Double,
  # signifying the offset into the song, in milliseconds, and a Boolean;
  # if false, then this timing point is inherited.
  # See Osu (file format) for more information regarding timing points.
  class TimingPoint < Kaitai::Struct::Struct
    def initialize(_io, _parent = nil, _root = self)
      super(_io, _parent, _root)
      _read
    end

    def _read
      @bpm = @_io.read_f8le
      @offset = @_io.read_f8le
      @not_inherited = Bool.new(@_io, self, @_root)
      self
    end
    attr_reader :bpm
    attr_reader :offset
    attr_reader :not_inherited
  end
  class String < Kaitai::Struct::Struct
    def initialize(_io, _parent = nil, _root = self)
      super(_io, _parent, _root)
      _read
    end

    def _read
      @is_present = @_io.read_s1
      if is_present == 11
        @len_str = VlqBase128Le.new(@_io)
      end
      if is_present == 11
        @value = (@_io.read_bytes(len_str.value)).force_encoding("UTF-8")
      end
      self
    end
    attr_reader :is_present
    attr_reader :len_str
    attr_reader :value
  end
  class Beatmap < Kaitai::Struct::Struct
    def initialize(_io, _parent = nil, _root = self)
      super(_io, _parent, _root)
      _read
    end

    def _read
      if _root.osu_version < 20191106
        @len_beatmap = @_io.read_s4le
      end
      @artist_name = String.new(@_io, self, @_root)
      @artist_name_unicode = String.new(@_io, self, @_root)
      @song_title = String.new(@_io, self, @_root)
      @song_title_unicode = String.new(@_io, self, @_root)
      @creator_name = String.new(@_io, self, @_root)
      @difficulty = String.new(@_io, self, @_root)
      @audio_file_name = String.new(@_io, self, @_root)
      @md5_hash = String.new(@_io, self, @_root)
      @osu_file_name = String.new(@_io, self, @_root)
      @ranked_status = @_io.read_s1
      @num_hitcircles = @_io.read_s2le
      @num_sliders = @_io.read_s2le
      @num_spinners = @_io.read_s2le
      @last_modification_time = @_io.read_s8le
      if _root.osu_version < 20140609
        @approach_rate_byte = @_io.read_s1
      end
      if _root.osu_version >= 20140609
        @approach_rate = @_io.read_f4le
      end
      if _root.osu_version < 20140609
        @circle_size_byte = @_io.read_s1
      end
      if _root.osu_version >= 20140609
        @circle_size = @_io.read_f4le
      end
      if _root.osu_version < 20140609
        @hp_drain_byte = @_io.read_s1
      end
      if _root.osu_version >= 20140609
        @hp_drain = @_io.read_f4le
      end
      if _root.osu_version < 20140609
        @overall_difficulty_byte = @_io.read_s1
      end
      if _root.osu_version >= 20140609
        @overall_difficulty = @_io.read_f4le
      end
      @slider_velocity = @_io.read_f8le
      if _root.osu_version >= 20140609
        @star_rating_osu = IntDoublePairs.new(@_io, self, @_root)
      end
      if _root.osu_version >= 20140609
        @star_rating_taiko = IntDoublePairs.new(@_io, self, @_root)
      end
      if _root.osu_version >= 20140609
        @star_rating_ctb = IntDoublePairs.new(@_io, self, @_root)
      end
      if _root.osu_version >= 20140609
        @star_rating_mania = IntDoublePairs.new(@_io, self, @_root)
      end
      @drain_time = @_io.read_s4le
      @total_time = @_io.read_s4le
      @audio_preview_start_time = @_io.read_s4le
      @timing_points = TimingPoints.new(@_io, self, @_root)
      @beatmap_id = @_io.read_s4le
      @beatmap_set_id = @_io.read_s4le
      @thread_id = @_io.read_s4le
      @grade_osu = @_io.read_s1
      @grade_taiko = @_io.read_s1
      @grade_ctb = @_io.read_s1
      @grade_mania = @_io.read_s1
      @local_beatmap_offset = @_io.read_s2le
      @stack_leniency = @_io.read_f4le
      @gameplay_mode = @_io.read_s1
      @song_source = String.new(@_io, self, @_root)
      @song_tags = String.new(@_io, self, @_root)
      @online_offset = @_io.read_s2le
      @song_title_font = String.new(@_io, self, @_root)
      @is_unplayed = Bool.new(@_io, self, @_root)
      @last_played_time = @_io.read_s8le
      @is_osz2 = Bool.new(@_io, self, @_root)
      @folder_name = String.new(@_io, self, @_root)
      @last_check_repo_time = @_io.read_s8le
      @ignore_sound = Bool.new(@_io, self, @_root)
      @ignore_skin = Bool.new(@_io, self, @_root)
      @disable_storyboard = Bool.new(@_io, self, @_root)
      @disable_video = Bool.new(@_io, self, @_root)
      @visual_override = Bool.new(@_io, self, @_root)
      if _root.osu_version < 20140609
        @unknown_short = @_io.read_s2le
      end
      @last_modification_time_int = @_io.read_s4le
      @mania_scroll_speed = @_io.read_s1
      self
    end

    ##
    # Int,	Size in bytes of the beatmap entry. Only present if version is less than 20191106.
    attr_reader :len_beatmap

    ##
    # String, Artist name
    attr_reader :artist_name

    ##
    # String, Artist name, in Unicode
    attr_reader :artist_name_unicode

    ##
    # String, Song title
    attr_reader :song_title

    ##
    # String, Song title, in Unicode
    attr_reader :song_title_unicode

    ##
    # String, Creator name
    attr_reader :creator_name

    ##
    # String, Difficulty (e.g. Hard, Insane, etc.)
    attr_reader :difficulty

    ##
    # String, Audio file name
    attr_reader :audio_file_name

    ##
    # String, MD5 hash of the beatmap
    attr_reader :md5_hash

    ##
    # String, Name of the .osu file corresponding to this beatmap
    attr_reader :osu_file_name

    ##
    # Byte, Ranked status (0 = unknown, 1 = unsubmitted, 2 = pending/wip/graveyard, 3 = unused, 4 = ranked, 5 = approved, 6 = qualified, 7 = loved)
    attr_reader :ranked_status

    ##
    # Short, Number of hitcircles
    attr_reader :num_hitcircles

    ##
    # Short, Number of sliders (note: this will be present in every mode)
    attr_reader :num_sliders

    ##
    # Short, Number of spinners (note: this will be present in every mode)
    attr_reader :num_spinners

    ##
    # Long, Last modification time, Windows ticks.
    attr_reader :last_modification_time

    ##
    # Byte/Single, Approach rate. Byte if the version is less than 20140609, Single otherwise.
    attr_reader :approach_rate_byte

    ##
    # Byte/Single, Approach rate. Byte if the version is less than 20140609, Single otherwise.
    attr_reader :approach_rate

    ##
    # Byte/Single, Circle size. Byte if the version is less than 20140609, Single otherwise.
    attr_reader :circle_size_byte

    ##
    # Byte/Single, Circle size. Byte if the version is less than 20140609, Single otherwise.
    attr_reader :circle_size

    ##
    # Byte/Single, HP drain. Byte if the version is less than 20140609, Single otherwise.
    attr_reader :hp_drain_byte

    ##
    # Byte/Single, HP drain. Byte if the version is less than 20140609, Single otherwise.
    attr_reader :hp_drain

    ##
    # Byte/Single, Overall difficulty. Byte if the version is less than 20140609, Single otherwise.
    attr_reader :overall_difficulty_byte

    ##
    # Byte/Single, Overall difficulty. Byte if the version is less than 20140609, Single otherwise.
    attr_reader :overall_difficulty

    ##
    # Double, Slider velocity
    attr_reader :slider_velocity

    ##
    # Int-Double pair*, Star Rating info for osu! standard, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
    attr_reader :star_rating_osu

    ##
    # Int-Double pair*, Star Rating info for Taiko, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
    attr_reader :star_rating_taiko

    ##
    # Int-Double pair*, Star Rating info for CTB, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
    attr_reader :star_rating_ctb

    ##
    # Int-Double pair*, Star Rating info for osu!mania, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
    attr_reader :star_rating_mania

    ##
    # Int, Drain time, in seconds
    attr_reader :drain_time

    ##
    # Int, Total time, in milliseconds
    attr_reader :total_time

    ##
    # Int, Time when the audio preview when hovering over a beatmap in beatmap select starts, in milliseconds.
    attr_reader :audio_preview_start_time

    ##
    # Timing point+, An Int indicating the number of following Timing points, then the aforementioned Timing points.
    attr_reader :timing_points

    ##
    # Int, Beatmap ID
    attr_reader :beatmap_id

    ##
    # Int, Beatmap set ID
    attr_reader :beatmap_set_id

    ##
    # Int, Thread ID
    attr_reader :thread_id

    ##
    # Byte, Grade achieved in osu! standard.
    attr_reader :grade_osu

    ##
    # Byte, Grade achieved in Taiko.
    attr_reader :grade_taiko

    ##
    # Byte, Grade achieved in CTB.
    attr_reader :grade_ctb

    ##
    # Byte, Grade achieved in osu!mania.
    attr_reader :grade_mania

    ##
    # Short, Local beatmap offset
    attr_reader :local_beatmap_offset

    ##
    # Single, Stack leniency
    attr_reader :stack_leniency

    ##
    # Byte, Osu gameplay mode. 0x00 = osu!Standard, 0x01 = Taiko, 0x02 = CTB, 0x03 = Mania
    attr_reader :gameplay_mode

    ##
    # String, Song source
    attr_reader :song_source

    ##
    # String, Song tags
    attr_reader :song_tags

    ##
    # Short, Online offset
    attr_reader :online_offset

    ##
    # String, Font used for the title of the song
    attr_reader :song_title_font

    ##
    # Boolean, Is beatmap unplayed
    attr_reader :is_unplayed

    ##
    # Long, Last time when beatmap was played
    attr_reader :last_played_time

    ##
    # Boolean, Is the beatmap osz2
    attr_reader :is_osz2

    ##
    # String, Folder name of the beatmap, relative to Songs folder
    attr_reader :folder_name

    ##
    # Long, Last time when beatmap was checked against osu! repository
    attr_reader :last_check_repo_time

    ##
    # Boolean, Ignore beatmap sound
    attr_reader :ignore_sound

    ##
    # Boolean, Ignore beatmap skin
    attr_reader :ignore_skin

    ##
    # Boolean, Disable storyboard
    attr_reader :disable_storyboard

    ##
    # Boolean, Disable video
    attr_reader :disable_video

    ##
    # Boolean, Visual override
    attr_reader :visual_override

    ##
    # Short?, Unknown. Only present if version is less than 20140609.
    attr_reader :unknown_short

    ##
    # Int, Last modification time (?)
    attr_reader :last_modification_time_int

    ##
    # Byte, Mania scroll speed
    attr_reader :mania_scroll_speed
  end

  ##
  # An Int indicating the number of following Timing points, then the aforementioned Timing points.
  class TimingPoints < Kaitai::Struct::Struct
    def initialize(_io, _parent = nil, _root = self)
      super(_io, _parent, _root)
      _read
    end

    def _read
      @num_points = @_io.read_s4le
      @points = Array.new(num_points)
      (num_points).times { |i|
        @points[i] = TimingPoint.new(@_io, self, @_root)
      }
      self
    end
    attr_reader :num_points
    attr_reader :points
  end
  class Bool < Kaitai::Struct::Struct
    def initialize(_io, _parent = nil, _root = self)
      super(_io, _parent, _root)
      _read
    end

    def _read
      @byte = @_io.read_s1
      self
    end
    def value
      return @value unless @value.nil?
      @value = (byte == 0 ? false : true)
      @value
    end
    attr_reader :byte
  end

  ##
  # The first byte is 0x08, followed by an Int, then 0x0d, followed by a Double.
  # These extraneous bytes are presumably flags to signify different data types
  # in these slots, though in practice no other such flags have been seen.
  # Currently the purpose of this data type is unknown.
  class IntDoublePair < Kaitai::Struct::Struct
    def initialize(_io, _parent = nil, _root = self)
      super(_io, _parent, _root)
      _read
    end

    def _read
      @magic1 = @_io.read_bytes(1)
      raise Kaitai::Struct::ValidationNotEqualError.new([8].pack('C*'), magic1, _io, "/types/int_double_pair/seq/0") if not magic1 == [8].pack('C*')
      @int = @_io.read_s4le
      @magic2 = @_io.read_bytes(1)
      raise Kaitai::Struct::ValidationNotEqualError.new([13].pack('C*'), magic2, _io, "/types/int_double_pair/seq/2") if not magic2 == [13].pack('C*')
      @double = @_io.read_f8le
      self
    end
    attr_reader :magic1
    attr_reader :int
    attr_reader :magic2
    attr_reader :double
  end

  ##
  # An Int indicating the number of following Int-Double pairs, then the aforementioned pairs.
  class IntDoublePairs < Kaitai::Struct::Struct
    def initialize(_io, _parent = nil, _root = self)
      super(_io, _parent, _root)
      _read
    end

    def _read
      @num_pairs = @_io.read_s4le
      @pairs = Array.new(num_pairs)
      (num_pairs).times { |i|
        @pairs[i] = IntDoublePair.new(@_io, self, @_root)
      }
      self
    end
    attr_reader :num_pairs
    attr_reader :pairs
  end

  ##
  # Int, osu! version (e.g. 20150203)
  attr_reader :osu_version

  ##
  # Int, Folder Count
  attr_reader :folder_count

  ##
  # Bool, AccountUnlocked (only false when the account is locked or banned in any way)
  attr_reader :account_unlocked

  ##
  # DateTime, Date the account will be unlocked
  attr_reader :account_unlock_date

  ##
  # String, Player name
  attr_reader :player_name

  ##
  # Int, Number of beatmaps
  attr_reader :num_beatmaps

  ##
  # Beatmaps*, Aforementioned beatmaps
  attr_reader :beatmaps

  ##
  # Int, User permissions (0 = None, 1 = Normal, 2 = Moderator, 4 = Supporter, 8 = Friend, 16 = peppy, 32 = World Cup staff)
  attr_reader :user_permissions
end
