<?php
// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

/**
 * osu!.db file format in rhythm game, osu!.
 */

namespace {
    class OsuDb extends \Kaitai\Struct\Struct {
        public function __construct(\Kaitai\Struct\Stream $_io, \Kaitai\Struct\Struct $_parent = null, \OsuDb $_root = null) {
            parent::__construct($_io, $_parent, $_root);
            $this->_read();
        }

        private function _read() {
            $this->_m_osuVersion = $this->_io->readS4le();
            $this->_m_folderCount = $this->_io->readS4le();
            $this->_m_accountUnlocked = new \OsuDb\Bool($this->_io, $this, $this->_root);
            $this->_m_accountUnlockDate = $this->_io->readS8le();
            $this->_m_playerName = new \OsuDb\String($this->_io, $this, $this->_root);
            $this->_m_numBeatmaps = $this->_io->readS4le();
            $this->_m_beatmaps = [];
            $n = $this->numBeatmaps();
            for ($i = 0; $i < $n; $i++) {
                $this->_m_beatmaps[] = new \OsuDb\Beatmap($this->_io, $this, $this->_root);
            }
            $this->_m_userPermissions = $this->_io->readS4le();
        }
        protected $_m_osuVersion;
        protected $_m_folderCount;
        protected $_m_accountUnlocked;
        protected $_m_accountUnlockDate;
        protected $_m_playerName;
        protected $_m_numBeatmaps;
        protected $_m_beatmaps;
        protected $_m_userPermissions;

        /**
         * Int, osu! version (e.g. 20150203)
         */
        public function osuVersion() { return $this->_m_osuVersion; }

        /**
         * Int, Folder Count
         */
        public function folderCount() { return $this->_m_folderCount; }

        /**
         * Bool, AccountUnlocked (only false when the account is locked or banned in any way)
         */
        public function accountUnlocked() { return $this->_m_accountUnlocked; }

        /**
         * DateTime, Date the account will be unlocked
         */
        public function accountUnlockDate() { return $this->_m_accountUnlockDate; }

        /**
         * String, Player name
         */
        public function playerName() { return $this->_m_playerName; }

        /**
         * Int, Number of beatmaps
         */
        public function numBeatmaps() { return $this->_m_numBeatmaps; }

        /**
         * Beatmaps*, Aforementioned beatmaps
         */
        public function beatmaps() { return $this->_m_beatmaps; }

        /**
         * Int, User permissions (0 = None, 1 = Normal, 2 = Moderator, 4 = Supporter, 8 = Friend, 16 = peppy, 32 = World Cup staff)
         */
        public function userPermissions() { return $this->_m_userPermissions; }
    }
}

/**
 * Consists of a Double, signifying the BPM, another Double,
 * signifying the offset into the song, in milliseconds, and a Boolean;
 * if false, then this timing point is inherited.
 * See Osu (file format) for more information regarding timing points.
 */

namespace OsuDb {
    class TimingPoint extends \Kaitai\Struct\Struct {
        public function __construct(\Kaitai\Struct\Stream $_io, \OsuDb\TimingPoints $_parent = null, \OsuDb $_root = null) {
            parent::__construct($_io, $_parent, $_root);
            $this->_read();
        }

        private function _read() {
            $this->_m_bpm = $this->_io->readF8le();
            $this->_m_offset = $this->_io->readF8le();
            $this->_m_notInherited = new \OsuDb\Bool($this->_io, $this, $this->_root);
        }
        protected $_m_bpm;
        protected $_m_offset;
        protected $_m_notInherited;
        public function bpm() { return $this->_m_bpm; }
        public function offset() { return $this->_m_offset; }
        public function notInherited() { return $this->_m_notInherited; }
    }
}

namespace OsuDb {
    class String extends \Kaitai\Struct\Struct {
        public function __construct(\Kaitai\Struct\Stream $_io, \Kaitai\Struct\Struct $_parent = null, \OsuDb $_root = null) {
            parent::__construct($_io, $_parent, $_root);
            $this->_read();
        }

        private function _read() {
            $this->_m_isPresent = $this->_io->readS1();
            if ($this->isPresent() == 11) {
                $this->_m_lenStr = new \VlqBase128Le($this->_io);
            }
            if ($this->isPresent() == 11) {
                $this->_m_value = \Kaitai\Struct\Stream::bytesToStr($this->_io->readBytes($this->lenStr()->value()), "UTF-8");
            }
        }
        protected $_m_isPresent;
        protected $_m_lenStr;
        protected $_m_value;
        public function isPresent() { return $this->_m_isPresent; }
        public function lenStr() { return $this->_m_lenStr; }
        public function value() { return $this->_m_value; }
    }
}

namespace OsuDb {
    class Beatmap extends \Kaitai\Struct\Struct {
        public function __construct(\Kaitai\Struct\Stream $_io, \OsuDb $_parent = null, \OsuDb $_root = null) {
            parent::__construct($_io, $_parent, $_root);
            $this->_read();
        }

        private function _read() {
            if ($this->_root()->osuVersion() < 20191106) {
                $this->_m_lenBeatmap = $this->_io->readS4le();
            }
            $this->_m_artistName = new \OsuDb\String($this->_io, $this, $this->_root);
            $this->_m_artistNameUnicode = new \OsuDb\String($this->_io, $this, $this->_root);
            $this->_m_songTitle = new \OsuDb\String($this->_io, $this, $this->_root);
            $this->_m_songTitleUnicode = new \OsuDb\String($this->_io, $this, $this->_root);
            $this->_m_creatorName = new \OsuDb\String($this->_io, $this, $this->_root);
            $this->_m_difficulty = new \OsuDb\String($this->_io, $this, $this->_root);
            $this->_m_audioFileName = new \OsuDb\String($this->_io, $this, $this->_root);
            $this->_m_md5Hash = new \OsuDb\String($this->_io, $this, $this->_root);
            $this->_m_osuFileName = new \OsuDb\String($this->_io, $this, $this->_root);
            $this->_m_rankedStatus = $this->_io->readS1();
            $this->_m_numHitcircles = $this->_io->readS2le();
            $this->_m_numSliders = $this->_io->readS2le();
            $this->_m_numSpinners = $this->_io->readS2le();
            $this->_m_lastModificationTime = $this->_io->readS8le();
            if ($this->_root()->osuVersion() < 20140609) {
                $this->_m_approachRateByte = $this->_io->readS1();
            }
            if ($this->_root()->osuVersion() >= 20140609) {
                $this->_m_approachRate = $this->_io->readF4le();
            }
            if ($this->_root()->osuVersion() < 20140609) {
                $this->_m_circleSizeByte = $this->_io->readS1();
            }
            if ($this->_root()->osuVersion() >= 20140609) {
                $this->_m_circleSize = $this->_io->readF4le();
            }
            if ($this->_root()->osuVersion() < 20140609) {
                $this->_m_hpDrainByte = $this->_io->readS1();
            }
            if ($this->_root()->osuVersion() >= 20140609) {
                $this->_m_hpDrain = $this->_io->readF4le();
            }
            if ($this->_root()->osuVersion() < 20140609) {
                $this->_m_overallDifficultyByte = $this->_io->readS1();
            }
            if ($this->_root()->osuVersion() >= 20140609) {
                $this->_m_overallDifficulty = $this->_io->readF4le();
            }
            $this->_m_sliderVelocity = $this->_io->readF8le();
            if ($this->_root()->osuVersion() >= 20140609) {
                $this->_m_starRatingOsu = new \OsuDb\IntDoublePairs($this->_io, $this, $this->_root);
            }
            if ($this->_root()->osuVersion() >= 20140609) {
                $this->_m_starRatingTaiko = new \OsuDb\IntDoublePairs($this->_io, $this, $this->_root);
            }
            if ($this->_root()->osuVersion() >= 20140609) {
                $this->_m_starRatingCtb = new \OsuDb\IntDoublePairs($this->_io, $this, $this->_root);
            }
            if ($this->_root()->osuVersion() >= 20140609) {
                $this->_m_starRatingMania = new \OsuDb\IntDoublePairs($this->_io, $this, $this->_root);
            }
            $this->_m_drainTime = $this->_io->readS4le();
            $this->_m_totalTime = $this->_io->readS4le();
            $this->_m_audioPreviewStartTime = $this->_io->readS4le();
            $this->_m_timingPoints = new \OsuDb\TimingPoints($this->_io, $this, $this->_root);
            $this->_m_beatmapId = $this->_io->readS4le();
            $this->_m_beatmapSetId = $this->_io->readS4le();
            $this->_m_threadId = $this->_io->readS4le();
            $this->_m_gradeOsu = $this->_io->readS1();
            $this->_m_gradeTaiko = $this->_io->readS1();
            $this->_m_gradeCtb = $this->_io->readS1();
            $this->_m_gradeMania = $this->_io->readS1();
            $this->_m_localBeatmapOffset = $this->_io->readS2le();
            $this->_m_stackLeniency = $this->_io->readF4le();
            $this->_m_gameplayMode = $this->_io->readS1();
            $this->_m_songSource = new \OsuDb\String($this->_io, $this, $this->_root);
            $this->_m_songTags = new \OsuDb\String($this->_io, $this, $this->_root);
            $this->_m_onlineOffset = $this->_io->readS2le();
            $this->_m_songTitleFont = new \OsuDb\String($this->_io, $this, $this->_root);
            $this->_m_isUnplayed = new \OsuDb\Bool($this->_io, $this, $this->_root);
            $this->_m_lastPlayedTime = $this->_io->readS8le();
            $this->_m_isOsz2 = new \OsuDb\Bool($this->_io, $this, $this->_root);
            $this->_m_folderName = new \OsuDb\String($this->_io, $this, $this->_root);
            $this->_m_lastCheckRepoTime = $this->_io->readS8le();
            $this->_m_ignoreSound = new \OsuDb\Bool($this->_io, $this, $this->_root);
            $this->_m_ignoreSkin = new \OsuDb\Bool($this->_io, $this, $this->_root);
            $this->_m_disableStoryboard = new \OsuDb\Bool($this->_io, $this, $this->_root);
            $this->_m_disableVideo = new \OsuDb\Bool($this->_io, $this, $this->_root);
            $this->_m_visualOverride = new \OsuDb\Bool($this->_io, $this, $this->_root);
            if ($this->_root()->osuVersion() < 20140609) {
                $this->_m_unknownShort = $this->_io->readS2le();
            }
            $this->_m_lastModificationTimeInt = $this->_io->readS4le();
            $this->_m_maniaScrollSpeed = $this->_io->readS1();
        }
        protected $_m_lenBeatmap;
        protected $_m_artistName;
        protected $_m_artistNameUnicode;
        protected $_m_songTitle;
        protected $_m_songTitleUnicode;
        protected $_m_creatorName;
        protected $_m_difficulty;
        protected $_m_audioFileName;
        protected $_m_md5Hash;
        protected $_m_osuFileName;
        protected $_m_rankedStatus;
        protected $_m_numHitcircles;
        protected $_m_numSliders;
        protected $_m_numSpinners;
        protected $_m_lastModificationTime;
        protected $_m_approachRateByte;
        protected $_m_approachRate;
        protected $_m_circleSizeByte;
        protected $_m_circleSize;
        protected $_m_hpDrainByte;
        protected $_m_hpDrain;
        protected $_m_overallDifficultyByte;
        protected $_m_overallDifficulty;
        protected $_m_sliderVelocity;
        protected $_m_starRatingOsu;
        protected $_m_starRatingTaiko;
        protected $_m_starRatingCtb;
        protected $_m_starRatingMania;
        protected $_m_drainTime;
        protected $_m_totalTime;
        protected $_m_audioPreviewStartTime;
        protected $_m_timingPoints;
        protected $_m_beatmapId;
        protected $_m_beatmapSetId;
        protected $_m_threadId;
        protected $_m_gradeOsu;
        protected $_m_gradeTaiko;
        protected $_m_gradeCtb;
        protected $_m_gradeMania;
        protected $_m_localBeatmapOffset;
        protected $_m_stackLeniency;
        protected $_m_gameplayMode;
        protected $_m_songSource;
        protected $_m_songTags;
        protected $_m_onlineOffset;
        protected $_m_songTitleFont;
        protected $_m_isUnplayed;
        protected $_m_lastPlayedTime;
        protected $_m_isOsz2;
        protected $_m_folderName;
        protected $_m_lastCheckRepoTime;
        protected $_m_ignoreSound;
        protected $_m_ignoreSkin;
        protected $_m_disableStoryboard;
        protected $_m_disableVideo;
        protected $_m_visualOverride;
        protected $_m_unknownShort;
        protected $_m_lastModificationTimeInt;
        protected $_m_maniaScrollSpeed;

        /**
         * Int,	Size in bytes of the beatmap entry. Only present if version is less than 20191106.
         */
        public function lenBeatmap() { return $this->_m_lenBeatmap; }

        /**
         * String, Artist name
         */
        public function artistName() { return $this->_m_artistName; }

        /**
         * String, Artist name, in Unicode
         */
        public function artistNameUnicode() { return $this->_m_artistNameUnicode; }

        /**
         * String, Song title
         */
        public function songTitle() { return $this->_m_songTitle; }

        /**
         * String, Song title, in Unicode
         */
        public function songTitleUnicode() { return $this->_m_songTitleUnicode; }

        /**
         * String, Creator name
         */
        public function creatorName() { return $this->_m_creatorName; }

        /**
         * String, Difficulty (e.g. Hard, Insane, etc.)
         */
        public function difficulty() { return $this->_m_difficulty; }

        /**
         * String, Audio file name
         */
        public function audioFileName() { return $this->_m_audioFileName; }

        /**
         * String, MD5 hash of the beatmap
         */
        public function md5Hash() { return $this->_m_md5Hash; }

        /**
         * String, Name of the .osu file corresponding to this beatmap
         */
        public function osuFileName() { return $this->_m_osuFileName; }

        /**
         * Byte, Ranked status (0 = unknown, 1 = unsubmitted, 2 = pending/wip/graveyard, 3 = unused, 4 = ranked, 5 = approved, 6 = qualified, 7 = loved)
         */
        public function rankedStatus() { return $this->_m_rankedStatus; }

        /**
         * Short, Number of hitcircles
         */
        public function numHitcircles() { return $this->_m_numHitcircles; }

        /**
         * Short, Number of sliders (note: this will be present in every mode)
         */
        public function numSliders() { return $this->_m_numSliders; }

        /**
         * Short, Number of spinners (note: this will be present in every mode)
         */
        public function numSpinners() { return $this->_m_numSpinners; }

        /**
         * Long, Last modification time, Windows ticks.
         */
        public function lastModificationTime() { return $this->_m_lastModificationTime; }

        /**
         * Byte/Single, Approach rate. Byte if the version is less than 20140609, Single otherwise.
         */
        public function approachRateByte() { return $this->_m_approachRateByte; }

        /**
         * Byte/Single, Approach rate. Byte if the version is less than 20140609, Single otherwise.
         */
        public function approachRate() { return $this->_m_approachRate; }

        /**
         * Byte/Single, Circle size. Byte if the version is less than 20140609, Single otherwise.
         */
        public function circleSizeByte() { return $this->_m_circleSizeByte; }

        /**
         * Byte/Single, Circle size. Byte if the version is less than 20140609, Single otherwise.
         */
        public function circleSize() { return $this->_m_circleSize; }

        /**
         * Byte/Single, HP drain. Byte if the version is less than 20140609, Single otherwise.
         */
        public function hpDrainByte() { return $this->_m_hpDrainByte; }

        /**
         * Byte/Single, HP drain. Byte if the version is less than 20140609, Single otherwise.
         */
        public function hpDrain() { return $this->_m_hpDrain; }

        /**
         * Byte/Single, Overall difficulty. Byte if the version is less than 20140609, Single otherwise.
         */
        public function overallDifficultyByte() { return $this->_m_overallDifficultyByte; }

        /**
         * Byte/Single, Overall difficulty. Byte if the version is less than 20140609, Single otherwise.
         */
        public function overallDifficulty() { return $this->_m_overallDifficulty; }

        /**
         * Double, Slider velocity
         */
        public function sliderVelocity() { return $this->_m_sliderVelocity; }

        /**
         * Int-Double pair*, Star Rating info for osu! standard, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
         */
        public function starRatingOsu() { return $this->_m_starRatingOsu; }

        /**
         * Int-Double pair*, Star Rating info for Taiko, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
         */
        public function starRatingTaiko() { return $this->_m_starRatingTaiko; }

        /**
         * Int-Double pair*, Star Rating info for CTB, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
         */
        public function starRatingCtb() { return $this->_m_starRatingCtb; }

        /**
         * Int-Double pair*, Star Rating info for osu!mania, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
         */
        public function starRatingMania() { return $this->_m_starRatingMania; }

        /**
         * Int, Drain time, in seconds
         */
        public function drainTime() { return $this->_m_drainTime; }

        /**
         * Int, Total time, in milliseconds
         */
        public function totalTime() { return $this->_m_totalTime; }

        /**
         * Int, Time when the audio preview when hovering over a beatmap in beatmap select starts, in milliseconds.
         */
        public function audioPreviewStartTime() { return $this->_m_audioPreviewStartTime; }

        /**
         * Timing point+, An Int indicating the number of following Timing points, then the aforementioned Timing points.
         */
        public function timingPoints() { return $this->_m_timingPoints; }

        /**
         * Int, Beatmap ID
         */
        public function beatmapId() { return $this->_m_beatmapId; }

        /**
         * Int, Beatmap set ID
         */
        public function beatmapSetId() { return $this->_m_beatmapSetId; }

        /**
         * Int, Thread ID
         */
        public function threadId() { return $this->_m_threadId; }

        /**
         * Byte, Grade achieved in osu! standard.
         */
        public function gradeOsu() { return $this->_m_gradeOsu; }

        /**
         * Byte, Grade achieved in Taiko.
         */
        public function gradeTaiko() { return $this->_m_gradeTaiko; }

        /**
         * Byte, Grade achieved in CTB.
         */
        public function gradeCtb() { return $this->_m_gradeCtb; }

        /**
         * Byte, Grade achieved in osu!mania.
         */
        public function gradeMania() { return $this->_m_gradeMania; }

        /**
         * Short, Local beatmap offset
         */
        public function localBeatmapOffset() { return $this->_m_localBeatmapOffset; }

        /**
         * Single, Stack leniency
         */
        public function stackLeniency() { return $this->_m_stackLeniency; }

        /**
         * Byte, Osu gameplay mode. 0x00 = osu!Standard, 0x01 = Taiko, 0x02 = CTB, 0x03 = Mania
         */
        public function gameplayMode() { return $this->_m_gameplayMode; }

        /**
         * String, Song source
         */
        public function songSource() { return $this->_m_songSource; }

        /**
         * String, Song tags
         */
        public function songTags() { return $this->_m_songTags; }

        /**
         * Short, Online offset
         */
        public function onlineOffset() { return $this->_m_onlineOffset; }

        /**
         * String, Font used for the title of the song
         */
        public function songTitleFont() { return $this->_m_songTitleFont; }

        /**
         * Boolean, Is beatmap unplayed
         */
        public function isUnplayed() { return $this->_m_isUnplayed; }

        /**
         * Long, Last time when beatmap was played
         */
        public function lastPlayedTime() { return $this->_m_lastPlayedTime; }

        /**
         * Boolean, Is the beatmap osz2
         */
        public function isOsz2() { return $this->_m_isOsz2; }

        /**
         * String, Folder name of the beatmap, relative to Songs folder
         */
        public function folderName() { return $this->_m_folderName; }

        /**
         * Long, Last time when beatmap was checked against osu! repository
         */
        public function lastCheckRepoTime() { return $this->_m_lastCheckRepoTime; }

        /**
         * Boolean, Ignore beatmap sound
         */
        public function ignoreSound() { return $this->_m_ignoreSound; }

        /**
         * Boolean, Ignore beatmap skin
         */
        public function ignoreSkin() { return $this->_m_ignoreSkin; }

        /**
         * Boolean, Disable storyboard
         */
        public function disableStoryboard() { return $this->_m_disableStoryboard; }

        /**
         * Boolean, Disable video
         */
        public function disableVideo() { return $this->_m_disableVideo; }

        /**
         * Boolean, Visual override
         */
        public function visualOverride() { return $this->_m_visualOverride; }

        /**
         * Short?, Unknown. Only present if version is less than 20140609.
         */
        public function unknownShort() { return $this->_m_unknownShort; }

        /**
         * Int, Last modification time (?)
         */
        public function lastModificationTimeInt() { return $this->_m_lastModificationTimeInt; }

        /**
         * Byte, Mania scroll speed
         */
        public function maniaScrollSpeed() { return $this->_m_maniaScrollSpeed; }
    }
}

/**
 * An Int indicating the number of following Timing points, then the aforementioned Timing points.
 */

namespace OsuDb {
    class TimingPoints extends \Kaitai\Struct\Struct {
        public function __construct(\Kaitai\Struct\Stream $_io, \OsuDb\Beatmap $_parent = null, \OsuDb $_root = null) {
            parent::__construct($_io, $_parent, $_root);
            $this->_read();
        }

        private function _read() {
            $this->_m_numPoints = $this->_io->readS4le();
            $this->_m_points = [];
            $n = $this->numPoints();
            for ($i = 0; $i < $n; $i++) {
                $this->_m_points[] = new \OsuDb\TimingPoint($this->_io, $this, $this->_root);
            }
        }
        protected $_m_numPoints;
        protected $_m_points;
        public function numPoints() { return $this->_m_numPoints; }
        public function points() { return $this->_m_points; }
    }
}

namespace OsuDb {
    class Bool extends \Kaitai\Struct\Struct {
        public function __construct(\Kaitai\Struct\Stream $_io, \Kaitai\Struct\Struct $_parent = null, \OsuDb $_root = null) {
            parent::__construct($_io, $_parent, $_root);
            $this->_read();
        }

        private function _read() {
            $this->_m_byte = $this->_io->readS1();
        }
        protected $_m_value;
        public function value() {
            if ($this->_m_value !== null)
                return $this->_m_value;
            $this->_m_value = ($this->byte() == 0 ? false : true);
            return $this->_m_value;
        }
        protected $_m_byte;
        public function byte() { return $this->_m_byte; }
    }
}

/**
 * The first byte is 0x08, followed by an Int, then 0x0d, followed by a Double.
 * These extraneous bytes are presumably flags to signify different data types
 * in these slots, though in practice no other such flags have been seen.
 * Currently the purpose of this data type is unknown.
 */

namespace OsuDb {
    class IntDoublePair extends \Kaitai\Struct\Struct {
        public function __construct(\Kaitai\Struct\Stream $_io, \OsuDb\IntDoublePairs $_parent = null, \OsuDb $_root = null) {
            parent::__construct($_io, $_parent, $_root);
            $this->_read();
        }

        private function _read() {
            $this->_m_magic1 = $this->_io->readBytes(1);
            if (!($this->magic1() == "\x08")) {
                throw new \Kaitai\Struct\Error\ValidationNotEqualError("\x08", $this->magic1(), $this->_io(), "/types/int_double_pair/seq/0");
            }
            $this->_m_int = $this->_io->readS4le();
            $this->_m_magic2 = $this->_io->readBytes(1);
            if (!($this->magic2() == "\x0D")) {
                throw new \Kaitai\Struct\Error\ValidationNotEqualError("\x0D", $this->magic2(), $this->_io(), "/types/int_double_pair/seq/2");
            }
            $this->_m_double = $this->_io->readF8le();
        }
        protected $_m_magic1;
        protected $_m_int;
        protected $_m_magic2;
        protected $_m_double;
        public function magic1() { return $this->_m_magic1; }
        public function int() { return $this->_m_int; }
        public function magic2() { return $this->_m_magic2; }
        public function double() { return $this->_m_double; }
    }
}

/**
 * An Int indicating the number of following Int-Double pairs, then the aforementioned pairs.
 */

namespace OsuDb {
    class IntDoublePairs extends \Kaitai\Struct\Struct {
        public function __construct(\Kaitai\Struct\Stream $_io, \OsuDb\Beatmap $_parent = null, \OsuDb $_root = null) {
            parent::__construct($_io, $_parent, $_root);
            $this->_read();
        }

        private function _read() {
            $this->_m_numPairs = $this->_io->readS4le();
            $this->_m_pairs = [];
            $n = $this->numPairs();
            for ($i = 0; $i < $n; $i++) {
                $this->_m_pairs[] = new \OsuDb\IntDoublePair($this->_io, $this, $this->_root);
            }
        }
        protected $_m_numPairs;
        protected $_m_pairs;
        public function numPairs() { return $this->_m_numPairs; }
        public function pairs() { return $this->_m_pairs; }
    }
}
