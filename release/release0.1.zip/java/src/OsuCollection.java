// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

import io.kaitai.struct.ByteBufferKaitaiStream;
import io.kaitai.struct.KaitaiStruct;
import io.kaitai.struct.KaitaiStream;
import java.io.IOException;
import java.util.ArrayList;
import java.nio.charset.Charset;


/**
 * collection.db file format in rhythm game, osu!.
 * @see <a href="https://osu.ppy.sh/wiki/zh-tw/osu%21_File_Formats/Db_%28file_format%29">Source</a>
 */
public class OsuCollection extends KaitaiStruct {
    public static OsuCollection fromFile(String fileName) throws IOException {
        return new OsuCollection(new ByteBufferKaitaiStream(fileName));
    }

    public OsuCollection(KaitaiStream _io) {
        this(_io, null, null);
    }

    public OsuCollection(KaitaiStream _io, KaitaiStruct _parent) {
        this(_io, _parent, null);
    }

    public OsuCollection(KaitaiStream _io, KaitaiStruct _parent, OsuCollection _root) {
        super(_io);
        this._parent = _parent;
        this._root = _root == null ? this : _root;
        _read();
    }
    private void _read() {
        this.version = this._io.readS4le();
        this.numCollections = this._io.readS4le();
        collections = new ArrayList<Collection>(((Number) (numCollections())).intValue());
        for (int i = 0; i < numCollections(); i++) {
            this.collections.add(new Collection(this._io, this, _root));
        }
    }
    public static class Collection extends KaitaiStruct {
        public static Collection fromFile(String fileName) throws IOException {
            return new Collection(new ByteBufferKaitaiStream(fileName));
        }

        public Collection(KaitaiStream _io) {
            this(_io, null, null);
        }

        public Collection(KaitaiStream _io, OsuCollection _parent) {
            this(_io, _parent, null);
        }

        public Collection(KaitaiStream _io, OsuCollection _parent, OsuCollection _root) {
            super(_io);
            this._parent = _parent;
            this._root = _root;
            _read();
        }
        private void _read() {
            this.name = new String(this._io, this, _root);
            this.numBeatmaps = this._io.readS4le();
            beatmapsMd5s = new ArrayList<String>(((Number) (numBeatmaps())).intValue());
            for (int i = 0; i < numBeatmaps(); i++) {
                this.beatmapsMd5s.add(new String(this._io, this, _root));
            }
        }
        private String name;
        private int numBeatmaps;
        private ArrayList<String> beatmapsMd5s;
        private OsuCollection _root;
        private OsuCollection _parent;

        /**
         * String, Name of the collection
         */
        public String name() { return name; }

        /**
         * Int, Number of beatmaps in the collection
         */
        public int numBeatmaps() { return numBeatmaps; }

        /**
         * String*, Beatmap MD5 hash. Repeated for as many beatmaps as are in the collection.
         */
        public ArrayList<String> beatmapsMd5s() { return beatmapsMd5s; }
        public OsuCollection _root() { return _root; }
        public OsuCollection _parent() { return _parent; }
    }
    public static class String extends KaitaiStruct {
        public static String fromFile(String fileName) throws IOException {
            return new String(new ByteBufferKaitaiStream(fileName));
        }

        public String(KaitaiStream _io) {
            this(_io, null, null);
        }

        public String(KaitaiStream _io, OsuCollection.Collection _parent) {
            this(_io, _parent, null);
        }

        public String(KaitaiStream _io, OsuCollection.Collection _parent, OsuCollection _root) {
            super(_io);
            this._parent = _parent;
            this._root = _root;
            _read();
        }
        private void _read() {
            this.isPresent = this._io.readS1();
            if (isPresent() == 11) {
                this.lenStr = new VlqBase128Le(this._io);
            }
            if (isPresent() == 11) {
                this.value = new String(this._io.readBytes(lenStr().value()), Charset.forName("UTF-8"));
            }
        }
        private byte isPresent;
        private VlqBase128Le lenStr;
        private String value;
        private OsuCollection _root;
        private OsuCollection.Collection _parent;
        public byte isPresent() { return isPresent; }
        public VlqBase128Le lenStr() { return lenStr; }
        public String value() { return value; }
        public OsuCollection _root() { return _root; }
        public OsuCollection.Collection _parent() { return _parent; }
    }
    private int version;
    private int numCollections;
    private ArrayList<Collection> collections;
    private OsuCollection _root;
    private KaitaiStruct _parent;

    /**
     * Int, Version (e.g. 20150203)
     */
    public int version() { return version; }

    /**
     * Int, Number of collections
     */
    public int numCollections() { return numCollections; }
    public ArrayList<Collection> collections() { return collections; }
    public OsuCollection _root() { return _root; }
    public KaitaiStruct _parent() { return _parent; }
}
