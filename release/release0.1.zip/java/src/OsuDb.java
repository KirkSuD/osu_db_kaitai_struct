// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

import io.kaitai.struct.ByteBufferKaitaiStream;
import io.kaitai.struct.KaitaiStruct;
import io.kaitai.struct.KaitaiStream;
import java.io.IOException;
import java.util.ArrayList;
import java.nio.charset.Charset;
import java.util.Arrays;


/**
 * osu!.db file format in rhythm game, osu!.
 * @see <a href="https://osu.ppy.sh/wiki/zh-tw/osu%21_File_Formats/Db_%28file_format%29">Source</a>
 */
public class OsuDb extends KaitaiStruct {
    public static OsuDb fromFile(String fileName) throws IOException {
        return new OsuDb(new ByteBufferKaitaiStream(fileName));
    }

    public OsuDb(KaitaiStream _io) {
        this(_io, null, null);
    }

    public OsuDb(KaitaiStream _io, KaitaiStruct _parent) {
        this(_io, _parent, null);
    }

    public OsuDb(KaitaiStream _io, KaitaiStruct _parent, OsuDb _root) {
        super(_io);
        this._parent = _parent;
        this._root = _root == null ? this : _root;
        _read();
    }
    private void _read() {
        this.osuVersion = this._io.readS4le();
        this.folderCount = this._io.readS4le();
        this.accountUnlocked = new Bool(this._io, this, _root);
        this.accountUnlockDate = this._io.readS8le();
        this.playerName = new String(this._io, this, _root);
        this.numBeatmaps = this._io.readS4le();
        beatmaps = new ArrayList<Beatmap>(((Number) (numBeatmaps())).intValue());
        for (int i = 0; i < numBeatmaps(); i++) {
            this.beatmaps.add(new Beatmap(this._io, this, _root));
        }
        this.userPermissions = this._io.readS4le();
    }

    /**
     * Consists of a Double, signifying the BPM, another Double,
     * signifying the offset into the song, in milliseconds, and a Boolean;
     * if false, then this timing point is inherited.
     * See Osu (file format) for more information regarding timing points.
     */
    public static class TimingPoint extends KaitaiStruct {
        public static TimingPoint fromFile(String fileName) throws IOException {
            return new TimingPoint(new ByteBufferKaitaiStream(fileName));
        }

        public TimingPoint(KaitaiStream _io) {
            this(_io, null, null);
        }

        public TimingPoint(KaitaiStream _io, OsuDb.TimingPoints _parent) {
            this(_io, _parent, null);
        }

        public TimingPoint(KaitaiStream _io, OsuDb.TimingPoints _parent, OsuDb _root) {
            super(_io);
            this._parent = _parent;
            this._root = _root;
            _read();
        }
        private void _read() {
            this.bpm = this._io.readF8le();
            this.offset = this._io.readF8le();
            this.notInherited = new Bool(this._io, this, _root);
        }
        private double bpm;
        private double offset;
        private Bool notInherited;
        private OsuDb _root;
        private OsuDb.TimingPoints _parent;
        public double bpm() { return bpm; }
        public double offset() { return offset; }
        public Bool notInherited() { return notInherited; }
        public OsuDb _root() { return _root; }
        public OsuDb.TimingPoints _parent() { return _parent; }
    }
    public static class String extends KaitaiStruct {
        public static String fromFile(String fileName) throws IOException {
            return new String(new ByteBufferKaitaiStream(fileName));
        }

        public String(KaitaiStream _io) {
            this(_io, null, null);
        }

        public String(KaitaiStream _io, KaitaiStruct _parent) {
            this(_io, _parent, null);
        }

        public String(KaitaiStream _io, KaitaiStruct _parent, OsuDb _root) {
            super(_io);
            this._parent = _parent;
            this._root = _root;
            _read();
        }
        private void _read() {
            this.isPresent = this._io.readS1();
            if (isPresent() == 11) {
                this.lenStr = new VlqBase128Le(this._io);
            }
            if (isPresent() == 11) {
                this.value = new String(this._io.readBytes(lenStr().value()), Charset.forName("UTF-8"));
            }
        }
        private byte isPresent;
        private VlqBase128Le lenStr;
        private String value;
        private OsuDb _root;
        private KaitaiStruct _parent;
        public byte isPresent() { return isPresent; }
        public VlqBase128Le lenStr() { return lenStr; }
        public String value() { return value; }
        public OsuDb _root() { return _root; }
        public KaitaiStruct _parent() { return _parent; }
    }
    public static class Beatmap extends KaitaiStruct {
        public static Beatmap fromFile(String fileName) throws IOException {
            return new Beatmap(new ByteBufferKaitaiStream(fileName));
        }

        public Beatmap(KaitaiStream _io) {
            this(_io, null, null);
        }

        public Beatmap(KaitaiStream _io, OsuDb _parent) {
            this(_io, _parent, null);
        }

        public Beatmap(KaitaiStream _io, OsuDb _parent, OsuDb _root) {
            super(_io);
            this._parent = _parent;
            this._root = _root;
            _read();
        }
        private void _read() {
            if (_root.osuVersion() < 20191106) {
                this.lenBeatmap = this._io.readS4le();
            }
            this.artistName = new String(this._io, this, _root);
            this.artistNameUnicode = new String(this._io, this, _root);
            this.songTitle = new String(this._io, this, _root);
            this.songTitleUnicode = new String(this._io, this, _root);
            this.creatorName = new String(this._io, this, _root);
            this.difficulty = new String(this._io, this, _root);
            this.audioFileName = new String(this._io, this, _root);
            this.md5Hash = new String(this._io, this, _root);
            this.osuFileName = new String(this._io, this, _root);
            this.rankedStatus = this._io.readS1();
            this.numHitcircles = this._io.readS2le();
            this.numSliders = this._io.readS2le();
            this.numSpinners = this._io.readS2le();
            this.lastModificationTime = this._io.readS8le();
            if (_root.osuVersion() < 20140609) {
                this.approachRateByte = this._io.readS1();
            }
            if (_root.osuVersion() >= 20140609) {
                this.approachRate = this._io.readF4le();
            }
            if (_root.osuVersion() < 20140609) {
                this.circleSizeByte = this._io.readS1();
            }
            if (_root.osuVersion() >= 20140609) {
                this.circleSize = this._io.readF4le();
            }
            if (_root.osuVersion() < 20140609) {
                this.hpDrainByte = this._io.readS1();
            }
            if (_root.osuVersion() >= 20140609) {
                this.hpDrain = this._io.readF4le();
            }
            if (_root.osuVersion() < 20140609) {
                this.overallDifficultyByte = this._io.readS1();
            }
            if (_root.osuVersion() >= 20140609) {
                this.overallDifficulty = this._io.readF4le();
            }
            this.sliderVelocity = this._io.readF8le();
            if (_root.osuVersion() >= 20140609) {
                this.starRatingOsu = new IntDoublePairs(this._io, this, _root);
            }
            if (_root.osuVersion() >= 20140609) {
                this.starRatingTaiko = new IntDoublePairs(this._io, this, _root);
            }
            if (_root.osuVersion() >= 20140609) {
                this.starRatingCtb = new IntDoublePairs(this._io, this, _root);
            }
            if (_root.osuVersion() >= 20140609) {
                this.starRatingMania = new IntDoublePairs(this._io, this, _root);
            }
            this.drainTime = this._io.readS4le();
            this.totalTime = this._io.readS4le();
            this.audioPreviewStartTime = this._io.readS4le();
            this.timingPoints = new TimingPoints(this._io, this, _root);
            this.beatmapId = this._io.readS4le();
            this.beatmapSetId = this._io.readS4le();
            this.threadId = this._io.readS4le();
            this.gradeOsu = this._io.readS1();
            this.gradeTaiko = this._io.readS1();
            this.gradeCtb = this._io.readS1();
            this.gradeMania = this._io.readS1();
            this.localBeatmapOffset = this._io.readS2le();
            this.stackLeniency = this._io.readF4le();
            this.gameplayMode = this._io.readS1();
            this.songSource = new String(this._io, this, _root);
            this.songTags = new String(this._io, this, _root);
            this.onlineOffset = this._io.readS2le();
            this.songTitleFont = new String(this._io, this, _root);
            this.isUnplayed = new Bool(this._io, this, _root);
            this.lastPlayedTime = this._io.readS8le();
            this.isOsz2 = new Bool(this._io, this, _root);
            this.folderName = new String(this._io, this, _root);
            this.lastCheckRepoTime = this._io.readS8le();
            this.ignoreSound = new Bool(this._io, this, _root);
            this.ignoreSkin = new Bool(this._io, this, _root);
            this.disableStoryboard = new Bool(this._io, this, _root);
            this.disableVideo = new Bool(this._io, this, _root);
            this.visualOverride = new Bool(this._io, this, _root);
            if (_root.osuVersion() < 20140609) {
                this.unknownShort = this._io.readS2le();
            }
            this.lastModificationTimeInt = this._io.readS4le();
            this.maniaScrollSpeed = this._io.readS1();
        }
        private Integer lenBeatmap;
        private String artistName;
        private String artistNameUnicode;
        private String songTitle;
        private String songTitleUnicode;
        private String creatorName;
        private String difficulty;
        private String audioFileName;
        private String md5Hash;
        private String osuFileName;
        private byte rankedStatus;
        private short numHitcircles;
        private short numSliders;
        private short numSpinners;
        private long lastModificationTime;
        private Byte approachRateByte;
        private Float approachRate;
        private Byte circleSizeByte;
        private Float circleSize;
        private Byte hpDrainByte;
        private Float hpDrain;
        private Byte overallDifficultyByte;
        private Float overallDifficulty;
        private double sliderVelocity;
        private IntDoublePairs starRatingOsu;
        private IntDoublePairs starRatingTaiko;
        private IntDoublePairs starRatingCtb;
        private IntDoublePairs starRatingMania;
        private int drainTime;
        private int totalTime;
        private int audioPreviewStartTime;
        private TimingPoints timingPoints;
        private int beatmapId;
        private int beatmapSetId;
        private int threadId;
        private byte gradeOsu;
        private byte gradeTaiko;
        private byte gradeCtb;
        private byte gradeMania;
        private short localBeatmapOffset;
        private float stackLeniency;
        private byte gameplayMode;
        private String songSource;
        private String songTags;
        private short onlineOffset;
        private String songTitleFont;
        private Bool isUnplayed;
        private long lastPlayedTime;
        private Bool isOsz2;
        private String folderName;
        private long lastCheckRepoTime;
        private Bool ignoreSound;
        private Bool ignoreSkin;
        private Bool disableStoryboard;
        private Bool disableVideo;
        private Bool visualOverride;
        private Short unknownShort;
        private int lastModificationTimeInt;
        private byte maniaScrollSpeed;
        private OsuDb _root;
        private OsuDb _parent;

        /**
         * Int,	Size in bytes of the beatmap entry. Only present if version is less than 20191106.
         */
        public Integer lenBeatmap() { return lenBeatmap; }

        /**
         * String, Artist name
         */
        public String artistName() { return artistName; }

        /**
         * String, Artist name, in Unicode
         */
        public String artistNameUnicode() { return artistNameUnicode; }

        /**
         * String, Song title
         */
        public String songTitle() { return songTitle; }

        /**
         * String, Song title, in Unicode
         */
        public String songTitleUnicode() { return songTitleUnicode; }

        /**
         * String, Creator name
         */
        public String creatorName() { return creatorName; }

        /**
         * String, Difficulty (e.g. Hard, Insane, etc.)
         */
        public String difficulty() { return difficulty; }

        /**
         * String, Audio file name
         */
        public String audioFileName() { return audioFileName; }

        /**
         * String, MD5 hash of the beatmap
         */
        public String md5Hash() { return md5Hash; }

        /**
         * String, Name of the .osu file corresponding to this beatmap
         */
        public String osuFileName() { return osuFileName; }

        /**
         * Byte, Ranked status (0 = unknown, 1 = unsubmitted, 2 = pending/wip/graveyard, 3 = unused, 4 = ranked, 5 = approved, 6 = qualified, 7 = loved)
         */
        public byte rankedStatus() { return rankedStatus; }

        /**
         * Short, Number of hitcircles
         */
        public short numHitcircles() { return numHitcircles; }

        /**
         * Short, Number of sliders (note: this will be present in every mode)
         */
        public short numSliders() { return numSliders; }

        /**
         * Short, Number of spinners (note: this will be present in every mode)
         */
        public short numSpinners() { return numSpinners; }

        /**
         * Long, Last modification time, Windows ticks.
         */
        public long lastModificationTime() { return lastModificationTime; }

        /**
         * Byte/Single, Approach rate. Byte if the version is less than 20140609, Single otherwise.
         */
        public Byte approachRateByte() { return approachRateByte; }

        /**
         * Byte/Single, Approach rate. Byte if the version is less than 20140609, Single otherwise.
         */
        public Float approachRate() { return approachRate; }

        /**
         * Byte/Single, Circle size. Byte if the version is less than 20140609, Single otherwise.
         */
        public Byte circleSizeByte() { return circleSizeByte; }

        /**
         * Byte/Single, Circle size. Byte if the version is less than 20140609, Single otherwise.
         */
        public Float circleSize() { return circleSize; }

        /**
         * Byte/Single, HP drain. Byte if the version is less than 20140609, Single otherwise.
         */
        public Byte hpDrainByte() { return hpDrainByte; }

        /**
         * Byte/Single, HP drain. Byte if the version is less than 20140609, Single otherwise.
         */
        public Float hpDrain() { return hpDrain; }

        /**
         * Byte/Single, Overall difficulty. Byte if the version is less than 20140609, Single otherwise.
         */
        public Byte overallDifficultyByte() { return overallDifficultyByte; }

        /**
         * Byte/Single, Overall difficulty. Byte if the version is less than 20140609, Single otherwise.
         */
        public Float overallDifficulty() { return overallDifficulty; }

        /**
         * Double, Slider velocity
         */
        public double sliderVelocity() { return sliderVelocity; }

        /**
         * Int-Double pair*, Star Rating info for osu! standard, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
         */
        public IntDoublePairs starRatingOsu() { return starRatingOsu; }

        /**
         * Int-Double pair*, Star Rating info for Taiko, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
         */
        public IntDoublePairs starRatingTaiko() { return starRatingTaiko; }

        /**
         * Int-Double pair*, Star Rating info for CTB, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
         */
        public IntDoublePairs starRatingCtb() { return starRatingCtb; }

        /**
         * Int-Double pair*, Star Rating info for osu!mania, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
         */
        public IntDoublePairs starRatingMania() { return starRatingMania; }

        /**
         * Int, Drain time, in seconds
         */
        public int drainTime() { return drainTime; }

        /**
         * Int, Total time, in milliseconds
         */
        public int totalTime() { return totalTime; }

        /**
         * Int, Time when the audio preview when hovering over a beatmap in beatmap select starts, in milliseconds.
         */
        public int audioPreviewStartTime() { return audioPreviewStartTime; }

        /**
         * Timing point+, An Int indicating the number of following Timing points, then the aforementioned Timing points.
         */
        public TimingPoints timingPoints() { return timingPoints; }

        /**
         * Int, Beatmap ID
         */
        public int beatmapId() { return beatmapId; }

        /**
         * Int, Beatmap set ID
         */
        public int beatmapSetId() { return beatmapSetId; }

        /**
         * Int, Thread ID
         */
        public int threadId() { return threadId; }

        /**
         * Byte, Grade achieved in osu! standard.
         */
        public byte gradeOsu() { return gradeOsu; }

        /**
         * Byte, Grade achieved in Taiko.
         */
        public byte gradeTaiko() { return gradeTaiko; }

        /**
         * Byte, Grade achieved in CTB.
         */
        public byte gradeCtb() { return gradeCtb; }

        /**
         * Byte, Grade achieved in osu!mania.
         */
        public byte gradeMania() { return gradeMania; }

        /**
         * Short, Local beatmap offset
         */
        public short localBeatmapOffset() { return localBeatmapOffset; }

        /**
         * Single, Stack leniency
         */
        public float stackLeniency() { return stackLeniency; }

        /**
         * Byte, Osu gameplay mode. 0x00 = osu!Standard, 0x01 = Taiko, 0x02 = CTB, 0x03 = Mania
         */
        public byte gameplayMode() { return gameplayMode; }

        /**
         * String, Song source
         */
        public String songSource() { return songSource; }

        /**
         * String, Song tags
         */
        public String songTags() { return songTags; }

        /**
         * Short, Online offset
         */
        public short onlineOffset() { return onlineOffset; }

        /**
         * String, Font used for the title of the song
         */
        public String songTitleFont() { return songTitleFont; }

        /**
         * Boolean, Is beatmap unplayed
         */
        public Bool isUnplayed() { return isUnplayed; }

        /**
         * Long, Last time when beatmap was played
         */
        public long lastPlayedTime() { return lastPlayedTime; }

        /**
         * Boolean, Is the beatmap osz2
         */
        public Bool isOsz2() { return isOsz2; }

        /**
         * String, Folder name of the beatmap, relative to Songs folder
         */
        public String folderName() { return folderName; }

        /**
         * Long, Last time when beatmap was checked against osu! repository
         */
        public long lastCheckRepoTime() { return lastCheckRepoTime; }

        /**
         * Boolean, Ignore beatmap sound
         */
        public Bool ignoreSound() { return ignoreSound; }

        /**
         * Boolean, Ignore beatmap skin
         */
        public Bool ignoreSkin() { return ignoreSkin; }

        /**
         * Boolean, Disable storyboard
         */
        public Bool disableStoryboard() { return disableStoryboard; }

        /**
         * Boolean, Disable video
         */
        public Bool disableVideo() { return disableVideo; }

        /**
         * Boolean, Visual override
         */
        public Bool visualOverride() { return visualOverride; }

        /**
         * Short?, Unknown. Only present if version is less than 20140609.
         */
        public Short unknownShort() { return unknownShort; }

        /**
         * Int, Last modification time (?)
         */
        public int lastModificationTimeInt() { return lastModificationTimeInt; }

        /**
         * Byte, Mania scroll speed
         */
        public byte maniaScrollSpeed() { return maniaScrollSpeed; }
        public OsuDb _root() { return _root; }
        public OsuDb _parent() { return _parent; }
    }

    /**
     * An Int indicating the number of following Timing points, then the aforementioned Timing points.
     */
    public static class TimingPoints extends KaitaiStruct {
        public static TimingPoints fromFile(String fileName) throws IOException {
            return new TimingPoints(new ByteBufferKaitaiStream(fileName));
        }

        public TimingPoints(KaitaiStream _io) {
            this(_io, null, null);
        }

        public TimingPoints(KaitaiStream _io, OsuDb.Beatmap _parent) {
            this(_io, _parent, null);
        }

        public TimingPoints(KaitaiStream _io, OsuDb.Beatmap _parent, OsuDb _root) {
            super(_io);
            this._parent = _parent;
            this._root = _root;
            _read();
        }
        private void _read() {
            this.numPoints = this._io.readS4le();
            points = new ArrayList<TimingPoint>(((Number) (numPoints())).intValue());
            for (int i = 0; i < numPoints(); i++) {
                this.points.add(new TimingPoint(this._io, this, _root));
            }
        }
        private int numPoints;
        private ArrayList<TimingPoint> points;
        private OsuDb _root;
        private OsuDb.Beatmap _parent;
        public int numPoints() { return numPoints; }
        public ArrayList<TimingPoint> points() { return points; }
        public OsuDb _root() { return _root; }
        public OsuDb.Beatmap _parent() { return _parent; }
    }
    public static class Bool extends KaitaiStruct {
        public static Bool fromFile(String fileName) throws IOException {
            return new Bool(new ByteBufferKaitaiStream(fileName));
        }

        public Bool(KaitaiStream _io) {
            this(_io, null, null);
        }

        public Bool(KaitaiStream _io, KaitaiStruct _parent) {
            this(_io, _parent, null);
        }

        public Bool(KaitaiStream _io, KaitaiStruct _parent, OsuDb _root) {
            super(_io);
            this._parent = _parent;
            this._root = _root;
            _read();
        }
        private void _read() {
            this.byte = this._io.readS1();
        }
        private Boolean value;
        public Boolean value() {
            if (this.value != null)
                return this.value;
            boolean _tmp = (boolean) ((byte() == 0 ? false : true));
            this.value = _tmp;
            return this.value;
        }
        private byte byte;
        private OsuDb _root;
        private KaitaiStruct _parent;
        public byte byte() { return byte; }
        public OsuDb _root() { return _root; }
        public KaitaiStruct _parent() { return _parent; }
    }

    /**
     * The first byte is 0x08, followed by an Int, then 0x0d, followed by a Double.
     * These extraneous bytes are presumably flags to signify different data types
     * in these slots, though in practice no other such flags have been seen.
     * Currently the purpose of this data type is unknown.
     */
    public static class IntDoublePair extends KaitaiStruct {
        public static IntDoublePair fromFile(String fileName) throws IOException {
            return new IntDoublePair(new ByteBufferKaitaiStream(fileName));
        }

        public IntDoublePair(KaitaiStream _io) {
            this(_io, null, null);
        }

        public IntDoublePair(KaitaiStream _io, OsuDb.IntDoublePairs _parent) {
            this(_io, _parent, null);
        }

        public IntDoublePair(KaitaiStream _io, OsuDb.IntDoublePairs _parent, OsuDb _root) {
            super(_io);
            this._parent = _parent;
            this._root = _root;
            _read();
        }
        private void _read() {
            this.magic1 = this._io.readBytes(1);
            if (!(Arrays.equals(magic1(), new byte[] { 8 }))) {
                throw new KaitaiStream.ValidationNotEqualError(new byte[] { 8 }, magic1(), _io(), "/types/int_double_pair/seq/0");
            }
            this.int = this._io.readS4le();
            this.magic2 = this._io.readBytes(1);
            if (!(Arrays.equals(magic2(), new byte[] { 13 }))) {
                throw new KaitaiStream.ValidationNotEqualError(new byte[] { 13 }, magic2(), _io(), "/types/int_double_pair/seq/2");
            }
            this.double = this._io.readF8le();
        }
        private byte[] magic1;
        private int int;
        private byte[] magic2;
        private double double;
        private OsuDb _root;
        private OsuDb.IntDoublePairs _parent;
        public byte[] magic1() { return magic1; }
        public int int() { return int; }
        public byte[] magic2() { return magic2; }
        public double double() { return double; }
        public OsuDb _root() { return _root; }
        public OsuDb.IntDoublePairs _parent() { return _parent; }
    }

    /**
     * An Int indicating the number of following Int-Double pairs, then the aforementioned pairs.
     */
    public static class IntDoublePairs extends KaitaiStruct {
        public static IntDoublePairs fromFile(String fileName) throws IOException {
            return new IntDoublePairs(new ByteBufferKaitaiStream(fileName));
        }

        public IntDoublePairs(KaitaiStream _io) {
            this(_io, null, null);
        }

        public IntDoublePairs(KaitaiStream _io, OsuDb.Beatmap _parent) {
            this(_io, _parent, null);
        }

        public IntDoublePairs(KaitaiStream _io, OsuDb.Beatmap _parent, OsuDb _root) {
            super(_io);
            this._parent = _parent;
            this._root = _root;
            _read();
        }
        private void _read() {
            this.numPairs = this._io.readS4le();
            pairs = new ArrayList<IntDoublePair>(((Number) (numPairs())).intValue());
            for (int i = 0; i < numPairs(); i++) {
                this.pairs.add(new IntDoublePair(this._io, this, _root));
            }
        }
        private int numPairs;
        private ArrayList<IntDoublePair> pairs;
        private OsuDb _root;
        private OsuDb.Beatmap _parent;
        public int numPairs() { return numPairs; }
        public ArrayList<IntDoublePair> pairs() { return pairs; }
        public OsuDb _root() { return _root; }
        public OsuDb.Beatmap _parent() { return _parent; }
    }
    private int osuVersion;
    private int folderCount;
    private Bool accountUnlocked;
    private long accountUnlockDate;
    private String playerName;
    private int numBeatmaps;
    private ArrayList<Beatmap> beatmaps;
    private int userPermissions;
    private OsuDb _root;
    private KaitaiStruct _parent;

    /**
     * Int, osu! version (e.g. 20150203)
     */
    public int osuVersion() { return osuVersion; }

    /**
     * Int, Folder Count
     */
    public int folderCount() { return folderCount; }

    /**
     * Bool, AccountUnlocked (only false when the account is locked or banned in any way)
     */
    public Bool accountUnlocked() { return accountUnlocked; }

    /**
     * DateTime, Date the account will be unlocked
     */
    public long accountUnlockDate() { return accountUnlockDate; }

    /**
     * String, Player name
     */
    public String playerName() { return playerName; }

    /**
     * Int, Number of beatmaps
     */
    public int numBeatmaps() { return numBeatmaps; }

    /**
     * Beatmaps*, Aforementioned beatmaps
     */
    public ArrayList<Beatmap> beatmaps() { return beatmaps; }

    /**
     * Int, User permissions (0 = None, 1 = Normal, 2 = Moderator, 4 = Supporter, 8 = Friend, 16 = peppy, 32 = World Cup staff)
     */
    public int userPermissions() { return userPermissions; }
    public OsuDb _root() { return _root; }
    public KaitaiStruct _parent() { return _parent; }
}
