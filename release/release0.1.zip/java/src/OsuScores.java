// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

import io.kaitai.struct.ByteBufferKaitaiStream;
import io.kaitai.struct.KaitaiStruct;
import io.kaitai.struct.KaitaiStream;
import java.io.IOException;
import java.util.ArrayList;
import java.nio.charset.Charset;
import java.util.Arrays;


/**
 * scores.db file format in rhythm game, osu!.
 * @see <a href="https://osu.ppy.sh/wiki/zh-tw/osu%21_File_Formats/Db_%28file_format%29">Source</a>
 */
public class OsuScores extends KaitaiStruct {
    public static OsuScores fromFile(String fileName) throws IOException {
        return new OsuScores(new ByteBufferKaitaiStream(fileName));
    }

    public OsuScores(KaitaiStream _io) {
        this(_io, null, null);
    }

    public OsuScores(KaitaiStream _io, KaitaiStruct _parent) {
        this(_io, _parent, null);
    }

    public OsuScores(KaitaiStream _io, KaitaiStruct _parent, OsuScores _root) {
        super(_io);
        this._parent = _parent;
        this._root = _root == null ? this : _root;
        _read();
    }
    private void _read() {
        this.version = this._io.readS4le();
        this.numBeatmaps = this._io.readS4le();
        beatmaps = new ArrayList<Beatmap>(((Number) (numBeatmaps())).intValue());
        for (int i = 0; i < numBeatmaps(); i++) {
            this.beatmaps.add(new Beatmap(this._io, this, _root));
        }
    }
    public static class Bool extends KaitaiStruct {
        public static Bool fromFile(String fileName) throws IOException {
            return new Bool(new ByteBufferKaitaiStream(fileName));
        }

        public Bool(KaitaiStream _io) {
            this(_io, null, null);
        }

        public Bool(KaitaiStream _io, OsuScores.Score _parent) {
            this(_io, _parent, null);
        }

        public Bool(KaitaiStream _io, OsuScores.Score _parent, OsuScores _root) {
            super(_io);
            this._parent = _parent;
            this._root = _root;
            _read();
        }
        private void _read() {
            this.byte = this._io.readS1();
        }
        private Boolean value;
        public Boolean value() {
            if (this.value != null)
                return this.value;
            boolean _tmp = (boolean) ((byte() == 0 ? false : true));
            this.value = _tmp;
            return this.value;
        }
        private byte byte;
        private OsuScores _root;
        private OsuScores.Score _parent;
        public byte byte() { return byte; }
        public OsuScores _root() { return _root; }
        public OsuScores.Score _parent() { return _parent; }
    }
    public static class String extends KaitaiStruct {
        public static String fromFile(String fileName) throws IOException {
            return new String(new ByteBufferKaitaiStream(fileName));
        }

        public String(KaitaiStream _io) {
            this(_io, null, null);
        }

        public String(KaitaiStream _io, KaitaiStruct _parent) {
            this(_io, _parent, null);
        }

        public String(KaitaiStream _io, KaitaiStruct _parent, OsuScores _root) {
            super(_io);
            this._parent = _parent;
            this._root = _root;
            _read();
        }
        private void _read() {
            this.isPresent = this._io.readS1();
            if (isPresent() == 11) {
                this.lenStr = new VlqBase128Le(this._io);
            }
            if (isPresent() == 11) {
                this.value = new String(this._io.readBytes(lenStr().value()), Charset.forName("UTF-8"));
            }
        }
        private byte isPresent;
        private VlqBase128Le lenStr;
        private String value;
        private OsuScores _root;
        private KaitaiStruct _parent;
        public byte isPresent() { return isPresent; }
        public VlqBase128Le lenStr() { return lenStr; }
        public String value() { return value; }
        public OsuScores _root() { return _root; }
        public KaitaiStruct _parent() { return _parent; }
    }
    public static class Beatmap extends KaitaiStruct {
        public static Beatmap fromFile(String fileName) throws IOException {
            return new Beatmap(new ByteBufferKaitaiStream(fileName));
        }

        public Beatmap(KaitaiStream _io) {
            this(_io, null, null);
        }

        public Beatmap(KaitaiStream _io, OsuScores _parent) {
            this(_io, _parent, null);
        }

        public Beatmap(KaitaiStream _io, OsuScores _parent, OsuScores _root) {
            super(_io);
            this._parent = _parent;
            this._root = _root;
            _read();
        }
        private void _read() {
            this.md5Hash = new String(this._io, this, _root);
            this.numScores = this._io.readS4le();
            scores = new ArrayList<Score>(((Number) (numScores())).intValue());
            for (int i = 0; i < numScores(); i++) {
                this.scores.add(new Score(this._io, this, _root));
            }
        }
        private String md5Hash;
        private int numScores;
        private ArrayList<Score> scores;
        private OsuScores _root;
        private OsuScores _parent;

        /**
         * String, Beatmap MD5 hash
         */
        public String md5Hash() { return md5Hash; }

        /**
         * Int, Number of scores on this beatmap
         */
        public int numScores() { return numScores; }

        /**
         * Score*, Aforementioned scores
         */
        public ArrayList<Score> scores() { return scores; }
        public OsuScores _root() { return _root; }
        public OsuScores _parent() { return _parent; }
    }
    public static class Score extends KaitaiStruct {
        public static Score fromFile(String fileName) throws IOException {
            return new Score(new ByteBufferKaitaiStream(fileName));
        }

        public Score(KaitaiStream _io) {
            this(_io, null, null);
        }

        public Score(KaitaiStream _io, OsuScores.Beatmap _parent) {
            this(_io, _parent, null);
        }

        public Score(KaitaiStream _io, OsuScores.Beatmap _parent, OsuScores _root) {
            super(_io);
            this._parent = _parent;
            this._root = _root;
            _read();
        }
        private void _read() {
            this.gameplayMode = this._io.readS1();
            this.version = this._io.readS4le();
            this.beatmapMd5Hash = new String(this._io, this, _root);
            this.playerName = new String(this._io, this, _root);
            this.replayMd5Hash = new String(this._io, this, _root);
            this.num300 = this._io.readS2le();
            this.num100 = this._io.readS2le();
            this.num50 = this._io.readS2le();
            this.numGekis = this._io.readS2le();
            this.numKatus = this._io.readS2le();
            this.numMiss = this._io.readS2le();
            this.replayScore = this._io.readS4le();
            this.maxCombo = this._io.readS2le();
            this.perfectCombo = new Bool(this._io, this, _root);
            this.mods = this._io.readS4le();
            this.empty = new String(this._io, this, _root);
            this.replayTimestamp = this._io.readS8le();
            this.minusOne = this._io.readBytes(4);
            if (!(Arrays.equals(minusOne(), new byte[] { -1, -1, -1, -1 }))) {
                throw new KaitaiStream.ValidationNotEqualError(new byte[] { -1, -1, -1, -1 }, minusOne(), _io(), "/types/score/seq/17");
            }
            this.onlineScoreId = this._io.readS8le();
        }
        private byte gameplayMode;
        private int version;
        private String beatmapMd5Hash;
        private String playerName;
        private String replayMd5Hash;
        private short num300;
        private short num100;
        private short num50;
        private short numGekis;
        private short numKatus;
        private short numMiss;
        private int replayScore;
        private short maxCombo;
        private Bool perfectCombo;
        private int mods;
        private String empty;
        private long replayTimestamp;
        private byte[] minusOne;
        private long onlineScoreId;
        private OsuScores _root;
        private OsuScores.Beatmap _parent;

        /**
         * Byte, osu! gameplay mode (0x00 = osu!Standard, 0x01 = Taiko, 0x02 = CTB, 0x03 = Mania)
         */
        public byte gameplayMode() { return gameplayMode; }

        /**
         * Int, Version of this score/replay (e.g. 20150203)
         */
        public int version() { return version; }

        /**
         * String, Beatmap MD5 hash
         */
        public String beatmapMd5Hash() { return beatmapMd5Hash; }

        /**
         * String, Player name
         */
        public String playerName() { return playerName; }

        /**
         * String, Replay MD5 hash
         */
        public String replayMd5Hash() { return replayMd5Hash; }

        /**
         * Short, Number of 300's
         */
        public short num300() { return num300; }

        /**
         * Short, Number of 100's in osu!Standard, 150's in Taiko, 100's in CTB, 100's in Mania
         */
        public short num100() { return num100; }

        /**
         * Short, Number of 50's in osu!Standard, small fruit in CTB, 50's in Mania
         */
        public short num50() { return num50; }

        /**
         * Short, Number of Gekis in osu!Standard, Max 300's in Mania
         */
        public short numGekis() { return numGekis; }

        /**
         * Short, Number of Katus in osu!Standard, 200's in Mania
         */
        public short numKatus() { return numKatus; }

        /**
         * Short, Number of misses
         */
        public short numMiss() { return numMiss; }

        /**
         * Int, Replay score
         */
        public int replayScore() { return replayScore; }

        /**
         * Short, Max Combo
         */
        public short maxCombo() { return maxCombo; }

        /**
         * Boolean, Perfect combo
         */
        public Bool perfectCombo() { return perfectCombo; }

        /**
         * Int, Bitwise combination of mods used. See Osr (file format) for more information.
         */
        public int mods() { return mods; }

        /**
         * String, Should always be empty
         */
        public String empty() { return empty; }

        /**
         * Long, Timestamp of replay, in Windows ticks
         */
        public long replayTimestamp() { return replayTimestamp; }

        /**
         * Int, Should always be 0xffffffff (-1).
         */
        public byte[] minusOne() { return minusOne; }

        /**
         * Long, Online Score ID
         */
        public long onlineScoreId() { return onlineScoreId; }
        public OsuScores _root() { return _root; }
        public OsuScores.Beatmap _parent() { return _parent; }
    }
    private int version;
    private int numBeatmaps;
    private ArrayList<Beatmap> beatmaps;
    private OsuScores _root;
    private KaitaiStruct _parent;

    /**
     * Int, Version (e.g. 20150204)
     */
    public int version() { return version; }

    /**
     * Int, Number of beatmaps
     */
    public int numBeatmaps() { return numBeatmaps; }

    /**
     * Beatmaps*, Aforementioned beatmaps
     */
    public ArrayList<Beatmap> beatmaps() { return beatmaps; }
    public OsuScores _root() { return _root; }
    public KaitaiStruct _parent() { return _parent; }
}
