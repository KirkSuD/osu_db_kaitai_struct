# This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

use strict;
use warnings;
use IO::KaitaiStruct 0.009_000;
use Encode;
use VlqBase128Le;

########################################################################
package OsuScores;

our @ISA = 'IO::KaitaiStruct::Struct';

sub from_file {
    my ($class, $filename) = @_;
    my $fd;

    open($fd, '<', $filename) or return undef;
    binmode($fd);
    return new($class, IO::KaitaiStruct::Stream->new($fd));
}

sub new {
    my ($class, $_io, $_parent, $_root) = @_;
    my $self = IO::KaitaiStruct::Struct->new($_io);

    bless $self, $class;
    $self->{_parent} = $_parent;
    $self->{_root} = $_root || $self;;

    $self->_read();

    return $self;
}

sub _read {
    my ($self) = @_;

    $self->{version} = $self->{_io}->read_s4le();
    $self->{num_beatmaps} = $self->{_io}->read_s4le();
    $self->{beatmaps} = ();
    my $n_beatmaps = $self->num_beatmaps();
    for (my $i = 0; $i < $n_beatmaps; $i++) {
        $self->{beatmaps}[$i] = OsuScores::Beatmap->new($self->{_io}, $self, $self->{_root});
    }
}

sub version {
    my ($self) = @_;
    return $self->{version};
}

sub num_beatmaps {
    my ($self) = @_;
    return $self->{num_beatmaps};
}

sub beatmaps {
    my ($self) = @_;
    return $self->{beatmaps};
}

########################################################################
package OsuScores::Bool;

our @ISA = 'IO::KaitaiStruct::Struct';

sub from_file {
    my ($class, $filename) = @_;
    my $fd;

    open($fd, '<', $filename) or return undef;
    binmode($fd);
    return new($class, IO::KaitaiStruct::Stream->new($fd));
}

sub new {
    my ($class, $_io, $_parent, $_root) = @_;
    my $self = IO::KaitaiStruct::Struct->new($_io);

    bless $self, $class;
    $self->{_parent} = $_parent;
    $self->{_root} = $_root || $self;;

    $self->_read();

    return $self;
}

sub _read {
    my ($self) = @_;

    $self->{byte} = $self->{_io}->read_s1();
}

sub value {
    my ($self) = @_;
    return $self->{value} if ($self->{value});
    $self->{value} = ($self->byte() == 0 ? 0 : 1);
    return $self->{value};
}

sub byte {
    my ($self) = @_;
    return $self->{byte};
}

########################################################################
package OsuScores::String;

our @ISA = 'IO::KaitaiStruct::Struct';

sub from_file {
    my ($class, $filename) = @_;
    my $fd;

    open($fd, '<', $filename) or return undef;
    binmode($fd);
    return new($class, IO::KaitaiStruct::Stream->new($fd));
}

sub new {
    my ($class, $_io, $_parent, $_root) = @_;
    my $self = IO::KaitaiStruct::Struct->new($_io);

    bless $self, $class;
    $self->{_parent} = $_parent;
    $self->{_root} = $_root || $self;;

    $self->_read();

    return $self;
}

sub _read {
    my ($self) = @_;

    $self->{is_present} = $self->{_io}->read_s1();
    if ($self->is_present() == 11) {
        $self->{len_str} = VlqBase128Le->new($self->{_io});
    }
    if ($self->is_present() == 11) {
        $self->{value} = Encode::decode("UTF-8", $self->{_io}->read_bytes($self->len_str()->value()));
    }
}

sub is_present {
    my ($self) = @_;
    return $self->{is_present};
}

sub len_str {
    my ($self) = @_;
    return $self->{len_str};
}

sub value {
    my ($self) = @_;
    return $self->{value};
}

########################################################################
package OsuScores::Beatmap;

our @ISA = 'IO::KaitaiStruct::Struct';

sub from_file {
    my ($class, $filename) = @_;
    my $fd;

    open($fd, '<', $filename) or return undef;
    binmode($fd);
    return new($class, IO::KaitaiStruct::Stream->new($fd));
}

sub new {
    my ($class, $_io, $_parent, $_root) = @_;
    my $self = IO::KaitaiStruct::Struct->new($_io);

    bless $self, $class;
    $self->{_parent} = $_parent;
    $self->{_root} = $_root || $self;;

    $self->_read();

    return $self;
}

sub _read {
    my ($self) = @_;

    $self->{md5_hash} = OsuScores::String->new($self->{_io}, $self, $self->{_root});
    $self->{num_scores} = $self->{_io}->read_s4le();
    $self->{scores} = ();
    my $n_scores = $self->num_scores();
    for (my $i = 0; $i < $n_scores; $i++) {
        $self->{scores}[$i] = OsuScores::Score->new($self->{_io}, $self, $self->{_root});
    }
}

sub md5_hash {
    my ($self) = @_;
    return $self->{md5_hash};
}

sub num_scores {
    my ($self) = @_;
    return $self->{num_scores};
}

sub scores {
    my ($self) = @_;
    return $self->{scores};
}

########################################################################
package OsuScores::Score;

our @ISA = 'IO::KaitaiStruct::Struct';

sub from_file {
    my ($class, $filename) = @_;
    my $fd;

    open($fd, '<', $filename) or return undef;
    binmode($fd);
    return new($class, IO::KaitaiStruct::Stream->new($fd));
}

sub new {
    my ($class, $_io, $_parent, $_root) = @_;
    my $self = IO::KaitaiStruct::Struct->new($_io);

    bless $self, $class;
    $self->{_parent} = $_parent;
    $self->{_root} = $_root || $self;;

    $self->_read();

    return $self;
}

sub _read {
    my ($self) = @_;

    $self->{gameplay_mode} = $self->{_io}->read_s1();
    $self->{version} = $self->{_io}->read_s4le();
    $self->{beatmap_md5_hash} = OsuScores::String->new($self->{_io}, $self, $self->{_root});
    $self->{player_name} = OsuScores::String->new($self->{_io}, $self, $self->{_root});
    $self->{replay_md5_hash} = OsuScores::String->new($self->{_io}, $self, $self->{_root});
    $self->{num_300} = $self->{_io}->read_s2le();
    $self->{num_100} = $self->{_io}->read_s2le();
    $self->{num_50} = $self->{_io}->read_s2le();
    $self->{num_gekis} = $self->{_io}->read_s2le();
    $self->{num_katus} = $self->{_io}->read_s2le();
    $self->{num_miss} = $self->{_io}->read_s2le();
    $self->{replay_score} = $self->{_io}->read_s4le();
    $self->{max_combo} = $self->{_io}->read_s2le();
    $self->{perfect_combo} = OsuScores::Bool->new($self->{_io}, $self, $self->{_root});
    $self->{mods} = $self->{_io}->read_s4le();
    $self->{empty} = OsuScores::String->new($self->{_io}, $self, $self->{_root});
    $self->{replay_timestamp} = $self->{_io}->read_s8le();
    $self->{minus_one} = $self->{_io}->read_bytes(4);
    $self->{online_score_id} = $self->{_io}->read_s8le();
}

sub gameplay_mode {
    my ($self) = @_;
    return $self->{gameplay_mode};
}

sub version {
    my ($self) = @_;
    return $self->{version};
}

sub beatmap_md5_hash {
    my ($self) = @_;
    return $self->{beatmap_md5_hash};
}

sub player_name {
    my ($self) = @_;
    return $self->{player_name};
}

sub replay_md5_hash {
    my ($self) = @_;
    return $self->{replay_md5_hash};
}

sub num_300 {
    my ($self) = @_;
    return $self->{num_300};
}

sub num_100 {
    my ($self) = @_;
    return $self->{num_100};
}

sub num_50 {
    my ($self) = @_;
    return $self->{num_50};
}

sub num_gekis {
    my ($self) = @_;
    return $self->{num_gekis};
}

sub num_katus {
    my ($self) = @_;
    return $self->{num_katus};
}

sub num_miss {
    my ($self) = @_;
    return $self->{num_miss};
}

sub replay_score {
    my ($self) = @_;
    return $self->{replay_score};
}

sub max_combo {
    my ($self) = @_;
    return $self->{max_combo};
}

sub perfect_combo {
    my ($self) = @_;
    return $self->{perfect_combo};
}

sub mods {
    my ($self) = @_;
    return $self->{mods};
}

sub empty {
    my ($self) = @_;
    return $self->{empty};
}

sub replay_timestamp {
    my ($self) = @_;
    return $self->{replay_timestamp};
}

sub minus_one {
    my ($self) = @_;
    return $self->{minus_one};
}

sub online_score_id {
    my ($self) = @_;
    return $self->{online_score_id};
}

1;
