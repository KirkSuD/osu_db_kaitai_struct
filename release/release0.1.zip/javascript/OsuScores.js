// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

(function (root, factory) {
  if (typeof define === 'function' && define.amd) {
    define(['kaitai-struct/KaitaiStream', './VlqBase128Le'], factory);
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory(require('kaitai-struct/KaitaiStream'), require('./VlqBase128Le'));
  } else {
    root.OsuScores = factory(root.KaitaiStream, root.VlqBase128Le);
  }
}(this, function (KaitaiStream, VlqBase128Le) {
/**
 * scores.db file format in rhythm game, osu!.
 * @see {@link https://osu.ppy.sh/wiki/zh-tw/osu%21_File_Formats/Db_%28file_format%29|Source}
 */

var OsuScores = (function() {
  function OsuScores(_io, _parent, _root) {
    this._io = _io;
    this._parent = _parent;
    this._root = _root || this;

    this._read();
  }
  OsuScores.prototype._read = function() {
    this.version = this._io.readS4le();
    this.numBeatmaps = this._io.readS4le();
    this.beatmaps = new Array(this.numBeatmaps);
    for (var i = 0; i < this.numBeatmaps; i++) {
      this.beatmaps[i] = new Beatmap(this._io, this, this._root);
    }
  }

  var Bool = OsuScores.Bool = (function() {
    function Bool(_io, _parent, _root) {
      this._io = _io;
      this._parent = _parent;
      this._root = _root || this;

      this._read();
    }
    Bool.prototype._read = function() {
      this.byte = this._io.readS1();
    }
    Object.defineProperty(Bool.prototype, 'value', {
      get: function() {
        if (this._m_value !== undefined)
          return this._m_value;
        this._m_value = (this.byte == 0 ? false : true);
        return this._m_value;
      }
    });

    return Bool;
  })();

  var String = OsuScores.String = (function() {
    function String(_io, _parent, _root) {
      this._io = _io;
      this._parent = _parent;
      this._root = _root || this;

      this._read();
    }
    String.prototype._read = function() {
      this.isPresent = this._io.readS1();
      if (this.isPresent == 11) {
        this.lenStr = new VlqBase128Le(this._io, this, null);
      }
      if (this.isPresent == 11) {
        this.value = KaitaiStream.bytesToStr(this._io.readBytes(this.lenStr.value), "UTF-8");
      }
    }

    return String;
  })();

  var Beatmap = OsuScores.Beatmap = (function() {
    function Beatmap(_io, _parent, _root) {
      this._io = _io;
      this._parent = _parent;
      this._root = _root || this;

      this._read();
    }
    Beatmap.prototype._read = function() {
      this.md5Hash = new String(this._io, this, this._root);
      this.numScores = this._io.readS4le();
      this.scores = new Array(this.numScores);
      for (var i = 0; i < this.numScores; i++) {
        this.scores[i] = new Score(this._io, this, this._root);
      }
    }

    /**
     * String, Beatmap MD5 hash
     */

    /**
     * Int, Number of scores on this beatmap
     */

    /**
     * Score*, Aforementioned scores
     */

    return Beatmap;
  })();

  var Score = OsuScores.Score = (function() {
    function Score(_io, _parent, _root) {
      this._io = _io;
      this._parent = _parent;
      this._root = _root || this;

      this._read();
    }
    Score.prototype._read = function() {
      this.gameplayMode = this._io.readS1();
      this.version = this._io.readS4le();
      this.beatmapMd5Hash = new String(this._io, this, this._root);
      this.playerName = new String(this._io, this, this._root);
      this.replayMd5Hash = new String(this._io, this, this._root);
      this.num300 = this._io.readS2le();
      this.num100 = this._io.readS2le();
      this.num50 = this._io.readS2le();
      this.numGekis = this._io.readS2le();
      this.numKatus = this._io.readS2le();
      this.numMiss = this._io.readS2le();
      this.replayScore = this._io.readS4le();
      this.maxCombo = this._io.readS2le();
      this.perfectCombo = new Bool(this._io, this, this._root);
      this.mods = this._io.readS4le();
      this.empty = new String(this._io, this, this._root);
      this.replayTimestamp = this._io.readS8le();
      this.minusOne = this._io.readBytes(4);
      if (!((KaitaiStream.byteArrayCompare(this.minusOne, [255, 255, 255, 255]) == 0))) {
        throw new KaitaiStream.ValidationNotEqualError([255, 255, 255, 255], this.minusOne, this._io, "/types/score/seq/17");
      }
      this.onlineScoreId = this._io.readS8le();
    }

    /**
     * Byte, osu! gameplay mode (0x00 = osu!Standard, 0x01 = Taiko, 0x02 = CTB, 0x03 = Mania)
     */

    /**
     * Int, Version of this score/replay (e.g. 20150203)
     */

    /**
     * String, Beatmap MD5 hash
     */

    /**
     * String, Player name
     */

    /**
     * String, Replay MD5 hash
     */

    /**
     * Short, Number of 300's
     */

    /**
     * Short, Number of 100's in osu!Standard, 150's in Taiko, 100's in CTB, 100's in Mania
     */

    /**
     * Short, Number of 50's in osu!Standard, small fruit in CTB, 50's in Mania
     */

    /**
     * Short, Number of Gekis in osu!Standard, Max 300's in Mania
     */

    /**
     * Short, Number of Katus in osu!Standard, 200's in Mania
     */

    /**
     * Short, Number of misses
     */

    /**
     * Int, Replay score
     */

    /**
     * Short, Max Combo
     */

    /**
     * Boolean, Perfect combo
     */

    /**
     * Int, Bitwise combination of mods used. See Osr (file format) for more information.
     */

    /**
     * String, Should always be empty
     */

    /**
     * Long, Timestamp of replay, in Windows ticks
     */

    /**
     * Int, Should always be 0xffffffff (-1).
     */

    /**
     * Long, Online Score ID
     */

    return Score;
  })();

  /**
   * Int, Version (e.g. 20150204)
   */

  /**
   * Int, Number of beatmaps
   */

  /**
   * Beatmaps*, Aforementioned beatmaps
   */

  return OsuScores;
})();
return OsuScores;
}));
