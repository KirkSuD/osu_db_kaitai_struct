// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

(function (root, factory) {
  if (typeof define === 'function' && define.amd) {
    define(['kaitai-struct/KaitaiStream', './VlqBase128Le'], factory);
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory(require('kaitai-struct/KaitaiStream'), require('./VlqBase128Le'));
  } else {
    root.OsuCollection = factory(root.KaitaiStream, root.VlqBase128Le);
  }
}(this, function (KaitaiStream, VlqBase128Le) {
/**
 * collection.db file format in rhythm game, osu!.
 * @see {@link https://osu.ppy.sh/wiki/zh-tw/osu%21_File_Formats/Db_%28file_format%29|Source}
 */

var OsuCollection = (function() {
  function OsuCollection(_io, _parent, _root) {
    this._io = _io;
    this._parent = _parent;
    this._root = _root || this;

    this._read();
  }
  OsuCollection.prototype._read = function() {
    this.version = this._io.readS4le();
    this.numCollections = this._io.readS4le();
    this.collections = new Array(this.numCollections);
    for (var i = 0; i < this.numCollections; i++) {
      this.collections[i] = new Collection(this._io, this, this._root);
    }
  }

  var Collection = OsuCollection.Collection = (function() {
    function Collection(_io, _parent, _root) {
      this._io = _io;
      this._parent = _parent;
      this._root = _root || this;

      this._read();
    }
    Collection.prototype._read = function() {
      this.name = new String(this._io, this, this._root);
      this.numBeatmaps = this._io.readS4le();
      this.beatmapsMd5s = new Array(this.numBeatmaps);
      for (var i = 0; i < this.numBeatmaps; i++) {
        this.beatmapsMd5s[i] = new String(this._io, this, this._root);
      }
    }

    /**
     * String, Name of the collection
     */

    /**
     * Int, Number of beatmaps in the collection
     */

    /**
     * String*, Beatmap MD5 hash. Repeated for as many beatmaps as are in the collection.
     */

    return Collection;
  })();

  var String = OsuCollection.String = (function() {
    function String(_io, _parent, _root) {
      this._io = _io;
      this._parent = _parent;
      this._root = _root || this;

      this._read();
    }
    String.prototype._read = function() {
      this.isPresent = this._io.readS1();
      if (this.isPresent == 11) {
        this.lenStr = new VlqBase128Le(this._io, this, null);
      }
      if (this.isPresent == 11) {
        this.value = KaitaiStream.bytesToStr(this._io.readBytes(this.lenStr.value), "UTF-8");
      }
    }

    return String;
  })();

  /**
   * Int, Version (e.g. 20150203)
   */

  /**
   * Int, Number of collections
   */

  return OsuCollection;
})();
return OsuCollection;
}));
