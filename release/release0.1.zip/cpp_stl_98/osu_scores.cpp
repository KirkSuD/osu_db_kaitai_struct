// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

#include "osu_scores.h"
#include "kaitai/exceptions.h"

osu_scores_t::osu_scores_t(kaitai::kstream* p__io, kaitai::kstruct* p__parent, osu_scores_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = this;
    m_beatmaps = 0;

    try {
        _read();
    } catch(...) {
        _clean_up();
        throw;
    }
}

void osu_scores_t::_read() {
    m_version = m__io->read_s4le();
    m_num_beatmaps = m__io->read_s4le();
    int l_beatmaps = num_beatmaps();
    m_beatmaps = new std::vector<beatmap_t*>();
    m_beatmaps->reserve(l_beatmaps);
    for (int i = 0; i < l_beatmaps; i++) {
        m_beatmaps->push_back(new beatmap_t(m__io, this, m__root));
    }
}

osu_scores_t::~osu_scores_t() {
    _clean_up();
}

void osu_scores_t::_clean_up() {
    if (m_beatmaps) {
        for (std::vector<beatmap_t*>::iterator it = m_beatmaps->begin(); it != m_beatmaps->end(); ++it) {
            delete *it;
        }
        delete m_beatmaps; m_beatmaps = 0;
    }
}

osu_scores_t::bool_t::bool_t(kaitai::kstream* p__io, osu_scores_t::score_t* p__parent, osu_scores_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    f_value = false;

    try {
        _read();
    } catch(...) {
        _clean_up();
        throw;
    }
}

void osu_scores_t::bool_t::_read() {
    m_byte = m__io->read_s1();
}

osu_scores_t::bool_t::~bool_t() {
    _clean_up();
}

void osu_scores_t::bool_t::_clean_up() {
}

bool osu_scores_t::bool_t::value() {
    if (f_value)
        return m_value;
    m_value = ((byte() == 0) ? (false) : (true));
    f_value = true;
    return m_value;
}

osu_scores_t::string_t::string_t(kaitai::kstream* p__io, kaitai::kstruct* p__parent, osu_scores_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    m_len_str = 0;

    try {
        _read();
    } catch(...) {
        _clean_up();
        throw;
    }
}

void osu_scores_t::string_t::_read() {
    m_is_present = m__io->read_s1();
    n_len_str = true;
    if (is_present() == 11) {
        n_len_str = false;
        m_len_str = new vlq_base128_le_t(m__io);
    }
    n_value = true;
    if (is_present() == 11) {
        n_value = false;
        m_value = kaitai::kstream::bytes_to_str(m__io->read_bytes(len_str()->value()), std::string("UTF-8"));
    }
}

osu_scores_t::string_t::~string_t() {
    _clean_up();
}

void osu_scores_t::string_t::_clean_up() {
    if (!n_len_str) {
        if (m_len_str) {
            delete m_len_str; m_len_str = 0;
        }
    }
    if (!n_value) {
    }
}

osu_scores_t::beatmap_t::beatmap_t(kaitai::kstream* p__io, osu_scores_t* p__parent, osu_scores_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    m_md5_hash = 0;
    m_scores = 0;

    try {
        _read();
    } catch(...) {
        _clean_up();
        throw;
    }
}

void osu_scores_t::beatmap_t::_read() {
    m_md5_hash = new string_t(m__io, this, m__root);
    m_num_scores = m__io->read_s4le();
    int l_scores = num_scores();
    m_scores = new std::vector<score_t*>();
    m_scores->reserve(l_scores);
    for (int i = 0; i < l_scores; i++) {
        m_scores->push_back(new score_t(m__io, this, m__root));
    }
}

osu_scores_t::beatmap_t::~beatmap_t() {
    _clean_up();
}

void osu_scores_t::beatmap_t::_clean_up() {
    if (m_md5_hash) {
        delete m_md5_hash; m_md5_hash = 0;
    }
    if (m_scores) {
        for (std::vector<score_t*>::iterator it = m_scores->begin(); it != m_scores->end(); ++it) {
            delete *it;
        }
        delete m_scores; m_scores = 0;
    }
}

osu_scores_t::score_t::score_t(kaitai::kstream* p__io, osu_scores_t::beatmap_t* p__parent, osu_scores_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    m_beatmap_md5_hash = 0;
    m_player_name = 0;
    m_replay_md5_hash = 0;
    m_perfect_combo = 0;
    m_empty = 0;

    try {
        _read();
    } catch(...) {
        _clean_up();
        throw;
    }
}

void osu_scores_t::score_t::_read() {
    m_gameplay_mode = m__io->read_s1();
    m_version = m__io->read_s4le();
    m_beatmap_md5_hash = new string_t(m__io, this, m__root);
    m_player_name = new string_t(m__io, this, m__root);
    m_replay_md5_hash = new string_t(m__io, this, m__root);
    m_num_300 = m__io->read_s2le();
    m_num_100 = m__io->read_s2le();
    m_num_50 = m__io->read_s2le();
    m_num_gekis = m__io->read_s2le();
    m_num_katus = m__io->read_s2le();
    m_num_miss = m__io->read_s2le();
    m_replay_score = m__io->read_s4le();
    m_max_combo = m__io->read_s2le();
    m_perfect_combo = new bool_t(m__io, this, m__root);
    m_mods = m__io->read_s4le();
    m_empty = new string_t(m__io, this, m__root);
    m_replay_timestamp = m__io->read_s8le();
    m_minus_one = m__io->read_bytes(4);
    if (!(minus_one() == std::string("\xFF\xFF\xFF\xFF", 4))) {
        throw kaitai::validation_not_equal_error<std::string>(std::string("\xFF\xFF\xFF\xFF", 4), minus_one(), _io(), std::string("/types/score/seq/17"));
    }
    m_online_score_id = m__io->read_s8le();
}

osu_scores_t::score_t::~score_t() {
    _clean_up();
}

void osu_scores_t::score_t::_clean_up() {
    if (m_beatmap_md5_hash) {
        delete m_beatmap_md5_hash; m_beatmap_md5_hash = 0;
    }
    if (m_player_name) {
        delete m_player_name; m_player_name = 0;
    }
    if (m_replay_md5_hash) {
        delete m_replay_md5_hash; m_replay_md5_hash = 0;
    }
    if (m_perfect_combo) {
        delete m_perfect_combo; m_perfect_combo = 0;
    }
    if (m_empty) {
        delete m_empty; m_empty = 0;
    }
}
