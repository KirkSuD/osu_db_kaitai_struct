#ifndef OSU_SCORES_H_
#define OSU_SCORES_H_

// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

#include "kaitai/kaitaistruct.h"
#include <stdint.h>
#include "vlq_base128_le.h"
#include <vector>

#if KAITAI_STRUCT_VERSION < 9000L
#error "Incompatible Kaitai Struct C++/STL API: version 0.9 or later is required"
#endif
class vlq_base128_le_t;

/**
 * scores.db file format in rhythm game, osu!.
 * \sa https://osu.ppy.sh/wiki/zh-tw/osu%21_File_Formats/Db_%28file_format%29 Source
 */

class osu_scores_t : public kaitai::kstruct {

public:
    class bool_t;
    class string_t;
    class beatmap_t;
    class score_t;

    osu_scores_t(kaitai::kstream* p__io, kaitai::kstruct* p__parent = 0, osu_scores_t* p__root = 0);

private:
    void _read();
    void _clean_up();

public:
    ~osu_scores_t();

    class bool_t : public kaitai::kstruct {

    public:

        bool_t(kaitai::kstream* p__io, osu_scores_t::score_t* p__parent = 0, osu_scores_t* p__root = 0);

    private:
        void _read();
        void _clean_up();

    public:
        ~bool_t();

    private:
        bool f_value;
        bool m_value;

    public:
        bool value();

    private:
        int8_t m_byte;
        osu_scores_t* m__root;
        osu_scores_t::score_t* m__parent;

    public:
        int8_t byte() const { return m_byte; }
        osu_scores_t* _root() const { return m__root; }
        osu_scores_t::score_t* _parent() const { return m__parent; }
    };

    class string_t : public kaitai::kstruct {

    public:

        string_t(kaitai::kstream* p__io, kaitai::kstruct* p__parent = 0, osu_scores_t* p__root = 0);

    private:
        void _read();
        void _clean_up();

    public:
        ~string_t();

    private:
        int8_t m_is_present;
        vlq_base128_le_t* m_len_str;
        bool n_len_str;

    public:
        bool _is_null_len_str() { len_str(); return n_len_str; };

    private:
        std::string m_value;
        bool n_value;

    public:
        bool _is_null_value() { value(); return n_value; };

    private:
        osu_scores_t* m__root;
        kaitai::kstruct* m__parent;

    public:
        int8_t is_present() const { return m_is_present; }
        vlq_base128_le_t* len_str() const { return m_len_str; }
        std::string value() const { return m_value; }
        osu_scores_t* _root() const { return m__root; }
        kaitai::kstruct* _parent() const { return m__parent; }
    };

    class beatmap_t : public kaitai::kstruct {

    public:

        beatmap_t(kaitai::kstream* p__io, osu_scores_t* p__parent = 0, osu_scores_t* p__root = 0);

    private:
        void _read();
        void _clean_up();

    public:
        ~beatmap_t();

    private:
        string_t* m_md5_hash;
        int32_t m_num_scores;
        std::vector<score_t*>* m_scores;
        osu_scores_t* m__root;
        osu_scores_t* m__parent;

    public:

        /**
         * String, Beatmap MD5 hash
         */
        string_t* md5_hash() const { return m_md5_hash; }

        /**
         * Int, Number of scores on this beatmap
         */
        int32_t num_scores() const { return m_num_scores; }

        /**
         * Score*, Aforementioned scores
         */
        std::vector<score_t*>* scores() const { return m_scores; }
        osu_scores_t* _root() const { return m__root; }
        osu_scores_t* _parent() const { return m__parent; }
    };

    class score_t : public kaitai::kstruct {

    public:

        score_t(kaitai::kstream* p__io, osu_scores_t::beatmap_t* p__parent = 0, osu_scores_t* p__root = 0);

    private:
        void _read();
        void _clean_up();

    public:
        ~score_t();

    private:
        int8_t m_gameplay_mode;
        int32_t m_version;
        string_t* m_beatmap_md5_hash;
        string_t* m_player_name;
        string_t* m_replay_md5_hash;
        int16_t m_num_300;
        int16_t m_num_100;
        int16_t m_num_50;
        int16_t m_num_gekis;
        int16_t m_num_katus;
        int16_t m_num_miss;
        int32_t m_replay_score;
        int16_t m_max_combo;
        bool_t* m_perfect_combo;
        int32_t m_mods;
        string_t* m_empty;
        int64_t m_replay_timestamp;
        std::string m_minus_one;
        int64_t m_online_score_id;
        osu_scores_t* m__root;
        osu_scores_t::beatmap_t* m__parent;

    public:

        /**
         * Byte, osu! gameplay mode (0x00 = osu!Standard, 0x01 = Taiko, 0x02 = CTB, 0x03 = Mania)
         */
        int8_t gameplay_mode() const { return m_gameplay_mode; }

        /**
         * Int, Version of this score/replay (e.g. 20150203)
         */
        int32_t version() const { return m_version; }

        /**
         * String, Beatmap MD5 hash
         */
        string_t* beatmap_md5_hash() const { return m_beatmap_md5_hash; }

        /**
         * String, Player name
         */
        string_t* player_name() const { return m_player_name; }

        /**
         * String, Replay MD5 hash
         */
        string_t* replay_md5_hash() const { return m_replay_md5_hash; }

        /**
         * Short, Number of 300's
         */
        int16_t num_300() const { return m_num_300; }

        /**
         * Short, Number of 100's in osu!Standard, 150's in Taiko, 100's in CTB, 100's in Mania
         */
        int16_t num_100() const { return m_num_100; }

        /**
         * Short, Number of 50's in osu!Standard, small fruit in CTB, 50's in Mania
         */
        int16_t num_50() const { return m_num_50; }

        /**
         * Short, Number of Gekis in osu!Standard, Max 300's in Mania
         */
        int16_t num_gekis() const { return m_num_gekis; }

        /**
         * Short, Number of Katus in osu!Standard, 200's in Mania
         */
        int16_t num_katus() const { return m_num_katus; }

        /**
         * Short, Number of misses
         */
        int16_t num_miss() const { return m_num_miss; }

        /**
         * Int, Replay score
         */
        int32_t replay_score() const { return m_replay_score; }

        /**
         * Short, Max Combo
         */
        int16_t max_combo() const { return m_max_combo; }

        /**
         * Boolean, Perfect combo
         */
        bool_t* perfect_combo() const { return m_perfect_combo; }

        /**
         * Int, Bitwise combination of mods used. See Osr (file format) for more information.
         */
        int32_t mods() const { return m_mods; }

        /**
         * String, Should always be empty
         */
        string_t* empty() const { return m_empty; }

        /**
         * Long, Timestamp of replay, in Windows ticks
         */
        int64_t replay_timestamp() const { return m_replay_timestamp; }

        /**
         * Int, Should always be 0xffffffff (-1).
         */
        std::string minus_one() const { return m_minus_one; }

        /**
         * Long, Online Score ID
         */
        int64_t online_score_id() const { return m_online_score_id; }
        osu_scores_t* _root() const { return m__root; }
        osu_scores_t::beatmap_t* _parent() const { return m__parent; }
    };

private:
    int32_t m_version;
    int32_t m_num_beatmaps;
    std::vector<beatmap_t*>* m_beatmaps;
    osu_scores_t* m__root;
    kaitai::kstruct* m__parent;

public:

    /**
     * Int, Version (e.g. 20150204)
     */
    int32_t version() const { return m_version; }

    /**
     * Int, Number of beatmaps
     */
    int32_t num_beatmaps() const { return m_num_beatmaps; }

    /**
     * Beatmaps*, Aforementioned beatmaps
     */
    std::vector<beatmap_t*>* beatmaps() const { return m_beatmaps; }
    osu_scores_t* _root() const { return m__root; }
    kaitai::kstruct* _parent() const { return m__parent; }
};

#endif  // OSU_SCORES_H_
