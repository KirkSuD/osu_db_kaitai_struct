// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

#include "osu_collection.h"

osu_collection_t::osu_collection_t(kaitai::kstream* p__io, kaitai::kstruct* p__parent, osu_collection_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = this;
    m_collections = 0;

    try {
        _read();
    } catch(...) {
        _clean_up();
        throw;
    }
}

void osu_collection_t::_read() {
    m_version = m__io->read_s4le();
    m_num_collections = m__io->read_s4le();
    int l_collections = num_collections();
    m_collections = new std::vector<collection_t*>();
    m_collections->reserve(l_collections);
    for (int i = 0; i < l_collections; i++) {
        m_collections->push_back(new collection_t(m__io, this, m__root));
    }
}

osu_collection_t::~osu_collection_t() {
    _clean_up();
}

void osu_collection_t::_clean_up() {
    if (m_collections) {
        for (std::vector<collection_t*>::iterator it = m_collections->begin(); it != m_collections->end(); ++it) {
            delete *it;
        }
        delete m_collections; m_collections = 0;
    }
}

osu_collection_t::collection_t::collection_t(kaitai::kstream* p__io, osu_collection_t* p__parent, osu_collection_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    m_name = 0;
    m_beatmaps_md5s = 0;

    try {
        _read();
    } catch(...) {
        _clean_up();
        throw;
    }
}

void osu_collection_t::collection_t::_read() {
    m_name = new string_t(m__io, this, m__root);
    m_num_beatmaps = m__io->read_s4le();
    int l_beatmaps_md5s = num_beatmaps();
    m_beatmaps_md5s = new std::vector<string_t*>();
    m_beatmaps_md5s->reserve(l_beatmaps_md5s);
    for (int i = 0; i < l_beatmaps_md5s; i++) {
        m_beatmaps_md5s->push_back(new string_t(m__io, this, m__root));
    }
}

osu_collection_t::collection_t::~collection_t() {
    _clean_up();
}

void osu_collection_t::collection_t::_clean_up() {
    if (m_name) {
        delete m_name; m_name = 0;
    }
    if (m_beatmaps_md5s) {
        for (std::vector<string_t*>::iterator it = m_beatmaps_md5s->begin(); it != m_beatmaps_md5s->end(); ++it) {
            delete *it;
        }
        delete m_beatmaps_md5s; m_beatmaps_md5s = 0;
    }
}

osu_collection_t::string_t::string_t(kaitai::kstream* p__io, osu_collection_t::collection_t* p__parent, osu_collection_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    m_len_str = 0;

    try {
        _read();
    } catch(...) {
        _clean_up();
        throw;
    }
}

void osu_collection_t::string_t::_read() {
    m_is_present = m__io->read_s1();
    n_len_str = true;
    if (is_present() == 11) {
        n_len_str = false;
        m_len_str = new vlq_base128_le_t(m__io);
    }
    n_value = true;
    if (is_present() == 11) {
        n_value = false;
        m_value = kaitai::kstream::bytes_to_str(m__io->read_bytes(len_str()->value()), std::string("UTF-8"));
    }
}

osu_collection_t::string_t::~string_t() {
    _clean_up();
}

void osu_collection_t::string_t::_clean_up() {
    if (!n_len_str) {
        if (m_len_str) {
            delete m_len_str; m_len_str = 0;
        }
    }
    if (!n_value) {
    }
}
