-- This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild
--
-- This file is compatible with Lua 5.3

local class = require("class")
require("kaitaistruct")
local utils = require("utils")
local str_decode = require("string_decode")

require("vlq_base128_le")
-- 
-- scores.db file format in rhythm game, osu!.
-- See also: Source (https://osu.ppy.sh/wiki/zh-tw/osu%21_File_Formats/Db_%28file_format%29)
OsuScores = class.class(KaitaiStruct)

function OsuScores:_init(io, parent, root)
  KaitaiStruct._init(self, io)
  self._parent = parent
  self._root = root or self
  self:_read()
end

function OsuScores:_read()
  self.version = self._io:read_s4le()
  self.num_beatmaps = self._io:read_s4le()
  self.beatmaps = {}
  for i = 0, self.num_beatmaps - 1 do
    self.beatmaps[i + 1] = OsuScores.Beatmap(self._io, self, self._root)
  end
end

-- 
-- Int, Version (e.g. 20150204).
-- 
-- Int, Number of beatmaps.
-- 
-- Beatmaps*, Aforementioned beatmaps.

OsuScores.Bool = class.class(KaitaiStruct)

function OsuScores.Bool:_init(io, parent, root)
  KaitaiStruct._init(self, io)
  self._parent = parent
  self._root = root or self
  self:_read()
end

function OsuScores.Bool:_read()
  self.byte = self._io:read_s1()
end

OsuScores.Bool.property.value = {}
function OsuScores.Bool.property.value:get()
  if self._m_value ~= nil then
    return self._m_value
  end

  self._m_value = utils.box_unwrap((self.byte == 0) and utils.box_wrap(false) or (true))
  return self._m_value
end


OsuScores.String = class.class(KaitaiStruct)

function OsuScores.String:_init(io, parent, root)
  KaitaiStruct._init(self, io)
  self._parent = parent
  self._root = root or self
  self:_read()
end

function OsuScores.String:_read()
  self.is_present = self._io:read_s1()
  if self.is_present == 11 then
    self.len_str = VlqBase128Le(self._io)
  end
  if self.is_present == 11 then
    self.value = str_decode.decode(self._io:read_bytes(self.len_str.value), "UTF-8")
  end
end


OsuScores.Beatmap = class.class(KaitaiStruct)

function OsuScores.Beatmap:_init(io, parent, root)
  KaitaiStruct._init(self, io)
  self._parent = parent
  self._root = root or self
  self:_read()
end

function OsuScores.Beatmap:_read()
  self.md5_hash = OsuScores.String(self._io, self, self._root)
  self.num_scores = self._io:read_s4le()
  self.scores = {}
  for i = 0, self.num_scores - 1 do
    self.scores[i + 1] = OsuScores.Score(self._io, self, self._root)
  end
end

-- 
-- String, Beatmap MD5 hash.
-- 
-- Int, Number of scores on this beatmap.
-- 
-- Score*, Aforementioned scores.

OsuScores.Score = class.class(KaitaiStruct)

function OsuScores.Score:_init(io, parent, root)
  KaitaiStruct._init(self, io)
  self._parent = parent
  self._root = root or self
  self:_read()
end

function OsuScores.Score:_read()
  self.gameplay_mode = self._io:read_s1()
  self.version = self._io:read_s4le()
  self.beatmap_md5_hash = OsuScores.String(self._io, self, self._root)
  self.player_name = OsuScores.String(self._io, self, self._root)
  self.replay_md5_hash = OsuScores.String(self._io, self, self._root)
  self.num_300 = self._io:read_s2le()
  self.num_100 = self._io:read_s2le()
  self.num_50 = self._io:read_s2le()
  self.num_gekis = self._io:read_s2le()
  self.num_katus = self._io:read_s2le()
  self.num_miss = self._io:read_s2le()
  self.replay_score = self._io:read_s4le()
  self.max_combo = self._io:read_s2le()
  self.perfect_combo = OsuScores.Bool(self._io, self, self._root)
  self.mods = self._io:read_s4le()
  self.empty = OsuScores.String(self._io, self, self._root)
  self.replay_timestamp = self._io:read_s8le()
  self.minus_one = self._io:read_bytes(4)
  if not(self.minus_one == "\255\255\255\255") then
    error("not equal, expected " ..  "\255\255\255\255" .. ", but got " .. self.minus_one)
  end
  self.online_score_id = self._io:read_s8le()
end

-- 
-- Byte, osu! gameplay mode (0x00 = osu!Standard, 0x01 = Taiko, 0x02 = CTB, 0x03 = Mania).
-- 
-- Int, Version of this score/replay (e.g. 20150203).
-- 
-- String, Beatmap MD5 hash.
-- 
-- String, Player name.
-- 
-- String, Replay MD5 hash.
-- 
-- Short, Number of 300's.
-- 
-- Short, Number of 100's in osu!Standard, 150's in Taiko, 100's in CTB, 100's in Mania.
-- 
-- Short, Number of 50's in osu!Standard, small fruit in CTB, 50's in Mania.
-- 
-- Short, Number of Gekis in osu!Standard, Max 300's in Mania.
-- 
-- Short, Number of Katus in osu!Standard, 200's in Mania.
-- 
-- Short, Number of misses.
-- 
-- Int, Replay score.
-- 
-- Short, Max Combo.
-- 
-- Boolean, Perfect combo.
-- 
-- Int, Bitwise combination of mods used. See Osr (file format) for more information.
-- 
-- String, Should always be empty.
-- 
-- Long, Timestamp of replay, in Windows ticks.
-- 
-- Int, Should always be 0xffffffff (-1).
-- 
-- Long, Online Score ID.

