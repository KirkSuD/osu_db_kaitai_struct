-- This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild
--
-- This file is compatible with Lua 5.3

local class = require("class")
require("kaitaistruct")
local str_decode = require("string_decode")
local utils = require("utils")

require("vlq_base128_le")
-- 
-- osu!.db file format in rhythm game, osu!.
-- See also: Source (https://osu.ppy.sh/wiki/zh-tw/osu%21_File_Formats/Db_%28file_format%29)
OsuDb = class.class(KaitaiStruct)

function OsuDb:_init(io, parent, root)
  KaitaiStruct._init(self, io)
  self._parent = parent
  self._root = root or self
  self:_read()
end

function OsuDb:_read()
  self.osu_version = self._io:read_s4le()
  self.folder_count = self._io:read_s4le()
  self.account_unlocked = OsuDb.Bool(self._io, self, self._root)
  self.account_unlock_date = self._io:read_s8le()
  self.player_name = OsuDb.String(self._io, self, self._root)
  self.num_beatmaps = self._io:read_s4le()
  self.beatmaps = {}
  for i = 0, self.num_beatmaps - 1 do
    self.beatmaps[i + 1] = OsuDb.Beatmap(self._io, self, self._root)
  end
  self.user_permissions = self._io:read_s4le()
end

-- 
-- Int, osu! version (e.g. 20150203).
-- 
-- Int, Folder Count.
-- 
-- Bool, AccountUnlocked (only false when the account is locked or banned in any way).
-- 
-- DateTime, Date the account will be unlocked.
-- 
-- String, Player name.
-- 
-- Int, Number of beatmaps.
-- 
-- Beatmaps*, Aforementioned beatmaps.
-- 
-- Int, User permissions (0 = None, 1 = Normal, 2 = Moderator, 4 = Supporter, 8 = Friend, 16 = peppy, 32 = World Cup staff).

-- 
-- Consists of a Double, signifying the BPM, another Double,
-- signifying the offset into the song, in milliseconds, and a Boolean;
-- if false, then this timing point is inherited.
-- See Osu (file format) for more information regarding timing points.
OsuDb.TimingPoint = class.class(KaitaiStruct)

function OsuDb.TimingPoint:_init(io, parent, root)
  KaitaiStruct._init(self, io)
  self._parent = parent
  self._root = root or self
  self:_read()
end

function OsuDb.TimingPoint:_read()
  self.bpm = self._io:read_f8le()
  self.offset = self._io:read_f8le()
  self.not_inherited = OsuDb.Bool(self._io, self, self._root)
end


OsuDb.String = class.class(KaitaiStruct)

function OsuDb.String:_init(io, parent, root)
  KaitaiStruct._init(self, io)
  self._parent = parent
  self._root = root or self
  self:_read()
end

function OsuDb.String:_read()
  self.is_present = self._io:read_s1()
  if self.is_present == 11 then
    self.len_str = VlqBase128Le(self._io)
  end
  if self.is_present == 11 then
    self.value = str_decode.decode(self._io:read_bytes(self.len_str.value), "UTF-8")
  end
end


OsuDb.Beatmap = class.class(KaitaiStruct)

function OsuDb.Beatmap:_init(io, parent, root)
  KaitaiStruct._init(self, io)
  self._parent = parent
  self._root = root or self
  self:_read()
end

function OsuDb.Beatmap:_read()
  if self._root.osu_version < 20191106 then
    self.len_beatmap = self._io:read_s4le()
  end
  self.artist_name = OsuDb.String(self._io, self, self._root)
  self.artist_name_unicode = OsuDb.String(self._io, self, self._root)
  self.song_title = OsuDb.String(self._io, self, self._root)
  self.song_title_unicode = OsuDb.String(self._io, self, self._root)
  self.creator_name = OsuDb.String(self._io, self, self._root)
  self.difficulty = OsuDb.String(self._io, self, self._root)
  self.audio_file_name = OsuDb.String(self._io, self, self._root)
  self.md5_hash = OsuDb.String(self._io, self, self._root)
  self.osu_file_name = OsuDb.String(self._io, self, self._root)
  self.ranked_status = self._io:read_s1()
  self.num_hitcircles = self._io:read_s2le()
  self.num_sliders = self._io:read_s2le()
  self.num_spinners = self._io:read_s2le()
  self.last_modification_time = self._io:read_s8le()
  if self._root.osu_version < 20140609 then
    self.approach_rate_byte = self._io:read_s1()
  end
  if self._root.osu_version >= 20140609 then
    self.approach_rate = self._io:read_f4le()
  end
  if self._root.osu_version < 20140609 then
    self.circle_size_byte = self._io:read_s1()
  end
  if self._root.osu_version >= 20140609 then
    self.circle_size = self._io:read_f4le()
  end
  if self._root.osu_version < 20140609 then
    self.hp_drain_byte = self._io:read_s1()
  end
  if self._root.osu_version >= 20140609 then
    self.hp_drain = self._io:read_f4le()
  end
  if self._root.osu_version < 20140609 then
    self.overall_difficulty_byte = self._io:read_s1()
  end
  if self._root.osu_version >= 20140609 then
    self.overall_difficulty = self._io:read_f4le()
  end
  self.slider_velocity = self._io:read_f8le()
  if self._root.osu_version >= 20140609 then
    self.star_rating_osu = OsuDb.IntDoublePairs(self._io, self, self._root)
  end
  if self._root.osu_version >= 20140609 then
    self.star_rating_taiko = OsuDb.IntDoublePairs(self._io, self, self._root)
  end
  if self._root.osu_version >= 20140609 then
    self.star_rating_ctb = OsuDb.IntDoublePairs(self._io, self, self._root)
  end
  if self._root.osu_version >= 20140609 then
    self.star_rating_mania = OsuDb.IntDoublePairs(self._io, self, self._root)
  end
  self.drain_time = self._io:read_s4le()
  self.total_time = self._io:read_s4le()
  self.audio_preview_start_time = self._io:read_s4le()
  self.timing_points = OsuDb.TimingPoints(self._io, self, self._root)
  self.beatmap_id = self._io:read_s4le()
  self.beatmap_set_id = self._io:read_s4le()
  self.thread_id = self._io:read_s4le()
  self.grade_osu = self._io:read_s1()
  self.grade_taiko = self._io:read_s1()
  self.grade_ctb = self._io:read_s1()
  self.grade_mania = self._io:read_s1()
  self.local_beatmap_offset = self._io:read_s2le()
  self.stack_leniency = self._io:read_f4le()
  self.gameplay_mode = self._io:read_s1()
  self.song_source = OsuDb.String(self._io, self, self._root)
  self.song_tags = OsuDb.String(self._io, self, self._root)
  self.online_offset = self._io:read_s2le()
  self.song_title_font = OsuDb.String(self._io, self, self._root)
  self.is_unplayed = OsuDb.Bool(self._io, self, self._root)
  self.last_played_time = self._io:read_s8le()
  self.is_osz2 = OsuDb.Bool(self._io, self, self._root)
  self.folder_name = OsuDb.String(self._io, self, self._root)
  self.last_check_repo_time = self._io:read_s8le()
  self.ignore_sound = OsuDb.Bool(self._io, self, self._root)
  self.ignore_skin = OsuDb.Bool(self._io, self, self._root)
  self.disable_storyboard = OsuDb.Bool(self._io, self, self._root)
  self.disable_video = OsuDb.Bool(self._io, self, self._root)
  self.visual_override = OsuDb.Bool(self._io, self, self._root)
  if self._root.osu_version < 20140609 then
    self.unknown_short = self._io:read_s2le()
  end
  self.last_modification_time_int = self._io:read_s4le()
  self.mania_scroll_speed = self._io:read_s1()
end

-- 
-- Int,	Size in bytes of the beatmap entry. Only present if version is less than 20191106.
-- 
-- String, Artist name.
-- 
-- String, Artist name, in Unicode.
-- 
-- String, Song title.
-- 
-- String, Song title, in Unicode.
-- 
-- String, Creator name.
-- 
-- String, Difficulty (e.g. Hard, Insane, etc.).
-- 
-- String, Audio file name.
-- 
-- String, MD5 hash of the beatmap.
-- 
-- String, Name of the .osu file corresponding to this beatmap.
-- 
-- Byte, Ranked status (0 = unknown, 1 = unsubmitted, 2 = pending/wip/graveyard, 3 = unused, 4 = ranked, 5 = approved, 6 = qualified, 7 = loved).
-- 
-- Short, Number of hitcircles.
-- 
-- Short, Number of sliders (note: this will be present in every mode).
-- 
-- Short, Number of spinners (note: this will be present in every mode).
-- 
-- Long, Last modification time, Windows ticks.
-- 
-- Byte/Single, Approach rate. Byte if the version is less than 20140609, Single otherwise.
-- 
-- Byte/Single, Approach rate. Byte if the version is less than 20140609, Single otherwise.
-- 
-- Byte/Single, Circle size. Byte if the version is less than 20140609, Single otherwise.
-- 
-- Byte/Single, Circle size. Byte if the version is less than 20140609, Single otherwise.
-- 
-- Byte/Single, HP drain. Byte if the version is less than 20140609, Single otherwise.
-- 
-- Byte/Single, HP drain. Byte if the version is less than 20140609, Single otherwise.
-- 
-- Byte/Single, Overall difficulty. Byte if the version is less than 20140609, Single otherwise.
-- 
-- Byte/Single, Overall difficulty. Byte if the version is less than 20140609, Single otherwise.
-- 
-- Double, Slider velocity.
-- 
-- Int-Double pair*, Star Rating info for osu! standard, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
-- 
-- Int-Double pair*, Star Rating info for Taiko, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
-- 
-- Int-Double pair*, Star Rating info for CTB, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
-- 
-- Int-Double pair*, Star Rating info for osu!mania, in each pair, the Int is the mod combination, and the Double is the Star Rating. Only present if version is greater than or equal to 20140609.
-- 
-- Int, Drain time, in seconds.
-- 
-- Int, Total time, in milliseconds.
-- 
-- Int, Time when the audio preview when hovering over a beatmap in beatmap select starts, in milliseconds.
-- 
-- Timing point+, An Int indicating the number of following Timing points, then the aforementioned Timing points.
-- 
-- Int, Beatmap ID.
-- 
-- Int, Beatmap set ID.
-- 
-- Int, Thread ID.
-- 
-- Byte, Grade achieved in osu! standard.
-- 
-- Byte, Grade achieved in Taiko.
-- 
-- Byte, Grade achieved in CTB.
-- 
-- Byte, Grade achieved in osu!mania.
-- 
-- Short, Local beatmap offset.
-- 
-- Single, Stack leniency.
-- 
-- Byte, Osu gameplay mode. 0x00 = osu!Standard, 0x01 = Taiko, 0x02 = CTB, 0x03 = Mania.
-- 
-- String, Song source.
-- 
-- String, Song tags.
-- 
-- Short, Online offset.
-- 
-- String, Font used for the title of the song.
-- 
-- Boolean, Is beatmap unplayed.
-- 
-- Long, Last time when beatmap was played.
-- 
-- Boolean, Is the beatmap osz2.
-- 
-- String, Folder name of the beatmap, relative to Songs folder.
-- 
-- Long, Last time when beatmap was checked against osu! repository.
-- 
-- Boolean, Ignore beatmap sound.
-- 
-- Boolean, Ignore beatmap skin.
-- 
-- Boolean, Disable storyboard.
-- 
-- Boolean, Disable video.
-- 
-- Boolean, Visual override.
-- 
-- Short?, Unknown. Only present if version is less than 20140609.
-- 
-- Int, Last modification time (?).
-- 
-- Byte, Mania scroll speed.

-- 
-- An Int indicating the number of following Timing points, then the aforementioned Timing points.
OsuDb.TimingPoints = class.class(KaitaiStruct)

function OsuDb.TimingPoints:_init(io, parent, root)
  KaitaiStruct._init(self, io)
  self._parent = parent
  self._root = root or self
  self:_read()
end

function OsuDb.TimingPoints:_read()
  self.num_points = self._io:read_s4le()
  self.points = {}
  for i = 0, self.num_points - 1 do
    self.points[i + 1] = OsuDb.TimingPoint(self._io, self, self._root)
  end
end


OsuDb.Bool = class.class(KaitaiStruct)

function OsuDb.Bool:_init(io, parent, root)
  KaitaiStruct._init(self, io)
  self._parent = parent
  self._root = root or self
  self:_read()
end

function OsuDb.Bool:_read()
  self.byte = self._io:read_s1()
end

OsuDb.Bool.property.value = {}
function OsuDb.Bool.property.value:get()
  if self._m_value ~= nil then
    return self._m_value
  end

  self._m_value = utils.box_unwrap((self.byte == 0) and utils.box_wrap(false) or (true))
  return self._m_value
end


-- 
-- The first byte is 0x08, followed by an Int, then 0x0d, followed by a Double.
-- These extraneous bytes are presumably flags to signify different data types
-- in these slots, though in practice no other such flags have been seen.
-- Currently the purpose of this data type is unknown.
OsuDb.IntDoublePair = class.class(KaitaiStruct)

function OsuDb.IntDoublePair:_init(io, parent, root)
  KaitaiStruct._init(self, io)
  self._parent = parent
  self._root = root or self
  self:_read()
end

function OsuDb.IntDoublePair:_read()
  self.magic1 = self._io:read_bytes(1)
  if not(self.magic1 == "\008") then
    error("not equal, expected " ..  "\008" .. ", but got " .. self.magic1)
  end
  self.int = self._io:read_s4le()
  self.magic2 = self._io:read_bytes(1)
  if not(self.magic2 == "\013") then
    error("not equal, expected " ..  "\013" .. ", but got " .. self.magic2)
  end
  self.double = self._io:read_f8le()
end


-- 
-- An Int indicating the number of following Int-Double pairs, then the aforementioned pairs.
OsuDb.IntDoublePairs = class.class(KaitaiStruct)

function OsuDb.IntDoublePairs:_init(io, parent, root)
  KaitaiStruct._init(self, io)
  self._parent = parent
  self._root = root or self
  self:_read()
end

function OsuDb.IntDoublePairs:_read()
  self.num_pairs = self._io:read_s4le()
  self.pairs = {}
  for i = 0, self.num_pairs - 1 do
    self.pairs[i + 1] = OsuDb.IntDoublePair(self._io, self, self._root)
  end
end


