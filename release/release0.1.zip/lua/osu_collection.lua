-- This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild
--
-- This file is compatible with Lua 5.3

local class = require("class")
require("kaitaistruct")
local str_decode = require("string_decode")

require("vlq_base128_le")
-- 
-- collection.db file format in rhythm game, osu!.
-- See also: Source (https://osu.ppy.sh/wiki/zh-tw/osu%21_File_Formats/Db_%28file_format%29)
OsuCollection = class.class(KaitaiStruct)

function OsuCollection:_init(io, parent, root)
  KaitaiStruct._init(self, io)
  self._parent = parent
  self._root = root or self
  self:_read()
end

function OsuCollection:_read()
  self.version = self._io:read_s4le()
  self.num_collections = self._io:read_s4le()
  self.collections = {}
  for i = 0, self.num_collections - 1 do
    self.collections[i + 1] = OsuCollection.Collection(self._io, self, self._root)
  end
end

-- 
-- Int, Version (e.g. 20150203).
-- 
-- Int, Number of collections.

OsuCollection.Collection = class.class(KaitaiStruct)

function OsuCollection.Collection:_init(io, parent, root)
  KaitaiStruct._init(self, io)
  self._parent = parent
  self._root = root or self
  self:_read()
end

function OsuCollection.Collection:_read()
  self.name = OsuCollection.String(self._io, self, self._root)
  self.num_beatmaps = self._io:read_s4le()
  self.beatmaps_md5s = {}
  for i = 0, self.num_beatmaps - 1 do
    self.beatmaps_md5s[i + 1] = OsuCollection.String(self._io, self, self._root)
  end
end

-- 
-- String, Name of the collection.
-- 
-- Int, Number of beatmaps in the collection.
-- 
-- String*, Beatmap MD5 hash. Repeated for as many beatmaps as are in the collection.

OsuCollection.String = class.class(KaitaiStruct)

function OsuCollection.String:_init(io, parent, root)
  KaitaiStruct._init(self, io)
  self._parent = parent
  self._root = root or self
  self:_read()
end

function OsuCollection.String:_read()
  self.is_present = self._io:read_s1()
  if self.is_present == 11 then
    self.len_str = VlqBase128Le(self._io)
  end
  if self.is_present == 11 then
    self.value = str_decode.decode(self._io:read_bytes(self.len_str.value), "UTF-8")
  end
end


