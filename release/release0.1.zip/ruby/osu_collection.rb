# This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

require 'kaitai/struct/struct'

unless Gem::Version.new(Kaitai::Struct::VERSION) >= Gem::Version.new('0.9')
  raise "Incompatible Kaitai Struct Ruby API: 0.9 or later is required, but you have #{Kaitai::Struct::VERSION}"
end


##
# collection.db file format in rhythm game, osu!.
# @see https://osu.ppy.sh/wiki/zh-tw/osu%21_File_Formats/Db_%28file_format%29 Source
class OsuCollection < Kaitai::Struct::Struct
  def initialize(_io, _parent = nil, _root = self)
    super(_io, _parent, _root)
    _read
  end

  def _read
    @version = @_io.read_s4le
    @num_collections = @_io.read_s4le
    @collections = Array.new(num_collections)
    (num_collections).times { |i|
      @collections[i] = Collection.new(@_io, self, @_root)
    }
    self
  end
  class Collection < Kaitai::Struct::Struct
    def initialize(_io, _parent = nil, _root = self)
      super(_io, _parent, _root)
      _read
    end

    def _read
      @name = String.new(@_io, self, @_root)
      @num_beatmaps = @_io.read_s4le
      @beatmaps_md5s = Array.new(num_beatmaps)
      (num_beatmaps).times { |i|
        @beatmaps_md5s[i] = String.new(@_io, self, @_root)
      }
      self
    end

    ##
    # String, Name of the collection
    attr_reader :name

    ##
    # Int, Number of beatmaps in the collection
    attr_reader :num_beatmaps

    ##
    # String*, Beatmap MD5 hash. Repeated for as many beatmaps as are in the collection.
    attr_reader :beatmaps_md5s
  end
  class String < Kaitai::Struct::Struct
    def initialize(_io, _parent = nil, _root = self)
      super(_io, _parent, _root)
      _read
    end

    def _read
      @is_present = @_io.read_s1
      if is_present == 11
        @len_str = VlqBase128Le.new(@_io)
      end
      if is_present == 11
        @value = (@_io.read_bytes(len_str.value)).force_encoding("UTF-8")
      end
      self
    end
    attr_reader :is_present
    attr_reader :len_str
    attr_reader :value
  end

  ##
  # Int, Version (e.g. 20150203)
  attr_reader :version

  ##
  # Int, Number of collections
  attr_reader :num_collections
  attr_reader :collections
end
