# This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

require 'kaitai/struct/struct'

unless Gem::Version.new(Kaitai::Struct::VERSION) >= Gem::Version.new('0.9')
  raise "Incompatible Kaitai Struct Ruby API: 0.9 or later is required, but you have #{Kaitai::Struct::VERSION}"
end


##
# scores.db file format in rhythm game, osu!.
# @see https://osu.ppy.sh/wiki/zh-tw/osu%21_File_Formats/Db_%28file_format%29 Source
class OsuScores < Kaitai::Struct::Struct
  def initialize(_io, _parent = nil, _root = self)
    super(_io, _parent, _root)
    _read
  end

  def _read
    @version = @_io.read_s4le
    @num_beatmaps = @_io.read_s4le
    @beatmaps = Array.new(num_beatmaps)
    (num_beatmaps).times { |i|
      @beatmaps[i] = Beatmap.new(@_io, self, @_root)
    }
    self
  end
  class Bool < Kaitai::Struct::Struct
    def initialize(_io, _parent = nil, _root = self)
      super(_io, _parent, _root)
      _read
    end

    def _read
      @byte = @_io.read_s1
      self
    end
    def value
      return @value unless @value.nil?
      @value = (byte == 0 ? false : true)
      @value
    end
    attr_reader :byte
  end
  class String < Kaitai::Struct::Struct
    def initialize(_io, _parent = nil, _root = self)
      super(_io, _parent, _root)
      _read
    end

    def _read
      @is_present = @_io.read_s1
      if is_present == 11
        @len_str = VlqBase128Le.new(@_io)
      end
      if is_present == 11
        @value = (@_io.read_bytes(len_str.value)).force_encoding("UTF-8")
      end
      self
    end
    attr_reader :is_present
    attr_reader :len_str
    attr_reader :value
  end
  class Beatmap < Kaitai::Struct::Struct
    def initialize(_io, _parent = nil, _root = self)
      super(_io, _parent, _root)
      _read
    end

    def _read
      @md5_hash = String.new(@_io, self, @_root)
      @num_scores = @_io.read_s4le
      @scores = Array.new(num_scores)
      (num_scores).times { |i|
        @scores[i] = Score.new(@_io, self, @_root)
      }
      self
    end

    ##
    # String, Beatmap MD5 hash
    attr_reader :md5_hash

    ##
    # Int, Number of scores on this beatmap
    attr_reader :num_scores

    ##
    # Score*, Aforementioned scores
    attr_reader :scores
  end
  class Score < Kaitai::Struct::Struct
    def initialize(_io, _parent = nil, _root = self)
      super(_io, _parent, _root)
      _read
    end

    def _read
      @gameplay_mode = @_io.read_s1
      @version = @_io.read_s4le
      @beatmap_md5_hash = String.new(@_io, self, @_root)
      @player_name = String.new(@_io, self, @_root)
      @replay_md5_hash = String.new(@_io, self, @_root)
      @num_300 = @_io.read_s2le
      @num_100 = @_io.read_s2le
      @num_50 = @_io.read_s2le
      @num_gekis = @_io.read_s2le
      @num_katus = @_io.read_s2le
      @num_miss = @_io.read_s2le
      @replay_score = @_io.read_s4le
      @max_combo = @_io.read_s2le
      @perfect_combo = Bool.new(@_io, self, @_root)
      @mods = @_io.read_s4le
      @empty = String.new(@_io, self, @_root)
      @replay_timestamp = @_io.read_s8le
      @minus_one = @_io.read_bytes(4)
      raise Kaitai::Struct::ValidationNotEqualError.new([255, 255, 255, 255].pack('C*'), minus_one, _io, "/types/score/seq/17") if not minus_one == [255, 255, 255, 255].pack('C*')
      @online_score_id = @_io.read_s8le
      self
    end

    ##
    # Byte, osu! gameplay mode (0x00 = osu!Standard, 0x01 = Taiko, 0x02 = CTB, 0x03 = Mania)
    attr_reader :gameplay_mode

    ##
    # Int, Version of this score/replay (e.g. 20150203)
    attr_reader :version

    ##
    # String, Beatmap MD5 hash
    attr_reader :beatmap_md5_hash

    ##
    # String, Player name
    attr_reader :player_name

    ##
    # String, Replay MD5 hash
    attr_reader :replay_md5_hash

    ##
    # Short, Number of 300's
    attr_reader :num_300

    ##
    # Short, Number of 100's in osu!Standard, 150's in Taiko, 100's in CTB, 100's in Mania
    attr_reader :num_100

    ##
    # Short, Number of 50's in osu!Standard, small fruit in CTB, 50's in Mania
    attr_reader :num_50

    ##
    # Short, Number of Gekis in osu!Standard, Max 300's in Mania
    attr_reader :num_gekis

    ##
    # Short, Number of Katus in osu!Standard, 200's in Mania
    attr_reader :num_katus

    ##
    # Short, Number of misses
    attr_reader :num_miss

    ##
    # Int, Replay score
    attr_reader :replay_score

    ##
    # Short, Max Combo
    attr_reader :max_combo

    ##
    # Boolean, Perfect combo
    attr_reader :perfect_combo

    ##
    # Int, Bitwise combination of mods used. See Osr (file format) for more information.
    attr_reader :mods

    ##
    # String, Should always be empty
    attr_reader :empty

    ##
    # Long, Timestamp of replay, in Windows ticks
    attr_reader :replay_timestamp

    ##
    # Int, Should always be 0xffffffff (-1).
    attr_reader :minus_one

    ##
    # Long, Online Score ID
    attr_reader :online_score_id
  end

  ##
  # Int, Version (e.g. 20150204)
  attr_reader :version

  ##
  # Int, Number of beatmaps
  attr_reader :num_beatmaps

  ##
  # Beatmaps*, Aforementioned beatmaps
  attr_reader :beatmaps
end
