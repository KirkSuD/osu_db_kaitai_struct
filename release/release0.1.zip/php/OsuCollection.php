<?php
// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

/**
 * collection.db file format in rhythm game, osu!.
 */

namespace {
    class OsuCollection extends \Kaitai\Struct\Struct {
        public function __construct(\Kaitai\Struct\Stream $_io, \Kaitai\Struct\Struct $_parent = null, \OsuCollection $_root = null) {
            parent::__construct($_io, $_parent, $_root);
            $this->_read();
        }

        private function _read() {
            $this->_m_version = $this->_io->readS4le();
            $this->_m_numCollections = $this->_io->readS4le();
            $this->_m_collections = [];
            $n = $this->numCollections();
            for ($i = 0; $i < $n; $i++) {
                $this->_m_collections[] = new \OsuCollection\Collection($this->_io, $this, $this->_root);
            }
        }
        protected $_m_version;
        protected $_m_numCollections;
        protected $_m_collections;

        /**
         * Int, Version (e.g. 20150203)
         */
        public function version() { return $this->_m_version; }

        /**
         * Int, Number of collections
         */
        public function numCollections() { return $this->_m_numCollections; }
        public function collections() { return $this->_m_collections; }
    }
}

namespace OsuCollection {
    class Collection extends \Kaitai\Struct\Struct {
        public function __construct(\Kaitai\Struct\Stream $_io, \OsuCollection $_parent = null, \OsuCollection $_root = null) {
            parent::__construct($_io, $_parent, $_root);
            $this->_read();
        }

        private function _read() {
            $this->_m_name = new \OsuCollection\String($this->_io, $this, $this->_root);
            $this->_m_numBeatmaps = $this->_io->readS4le();
            $this->_m_beatmapsMd5s = [];
            $n = $this->numBeatmaps();
            for ($i = 0; $i < $n; $i++) {
                $this->_m_beatmapsMd5s[] = new \OsuCollection\String($this->_io, $this, $this->_root);
            }
        }
        protected $_m_name;
        protected $_m_numBeatmaps;
        protected $_m_beatmapsMd5s;

        /**
         * String, Name of the collection
         */
        public function name() { return $this->_m_name; }

        /**
         * Int, Number of beatmaps in the collection
         */
        public function numBeatmaps() { return $this->_m_numBeatmaps; }

        /**
         * String*, Beatmap MD5 hash. Repeated for as many beatmaps as are in the collection.
         */
        public function beatmapsMd5s() { return $this->_m_beatmapsMd5s; }
    }
}

namespace OsuCollection {
    class String extends \Kaitai\Struct\Struct {
        public function __construct(\Kaitai\Struct\Stream $_io, \OsuCollection\Collection $_parent = null, \OsuCollection $_root = null) {
            parent::__construct($_io, $_parent, $_root);
            $this->_read();
        }

        private function _read() {
            $this->_m_isPresent = $this->_io->readS1();
            if ($this->isPresent() == 11) {
                $this->_m_lenStr = new \VlqBase128Le($this->_io);
            }
            if ($this->isPresent() == 11) {
                $this->_m_value = \Kaitai\Struct\Stream::bytesToStr($this->_io->readBytes($this->lenStr()->value()), "UTF-8");
            }
        }
        protected $_m_isPresent;
        protected $_m_lenStr;
        protected $_m_value;
        public function isPresent() { return $this->_m_isPresent; }
        public function lenStr() { return $this->_m_lenStr; }
        public function value() { return $this->_m_value; }
    }
}
