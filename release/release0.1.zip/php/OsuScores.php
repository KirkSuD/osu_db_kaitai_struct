<?php
// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

/**
 * scores.db file format in rhythm game, osu!.
 */

namespace {
    class OsuScores extends \Kaitai\Struct\Struct {
        public function __construct(\Kaitai\Struct\Stream $_io, \Kaitai\Struct\Struct $_parent = null, \OsuScores $_root = null) {
            parent::__construct($_io, $_parent, $_root);
            $this->_read();
        }

        private function _read() {
            $this->_m_version = $this->_io->readS4le();
            $this->_m_numBeatmaps = $this->_io->readS4le();
            $this->_m_beatmaps = [];
            $n = $this->numBeatmaps();
            for ($i = 0; $i < $n; $i++) {
                $this->_m_beatmaps[] = new \OsuScores\Beatmap($this->_io, $this, $this->_root);
            }
        }
        protected $_m_version;
        protected $_m_numBeatmaps;
        protected $_m_beatmaps;

        /**
         * Int, Version (e.g. 20150204)
         */
        public function version() { return $this->_m_version; }

        /**
         * Int, Number of beatmaps
         */
        public function numBeatmaps() { return $this->_m_numBeatmaps; }

        /**
         * Beatmaps*, Aforementioned beatmaps
         */
        public function beatmaps() { return $this->_m_beatmaps; }
    }
}

namespace OsuScores {
    class Bool extends \Kaitai\Struct\Struct {
        public function __construct(\Kaitai\Struct\Stream $_io, \OsuScores\Score $_parent = null, \OsuScores $_root = null) {
            parent::__construct($_io, $_parent, $_root);
            $this->_read();
        }

        private function _read() {
            $this->_m_byte = $this->_io->readS1();
        }
        protected $_m_value;
        public function value() {
            if ($this->_m_value !== null)
                return $this->_m_value;
            $this->_m_value = ($this->byte() == 0 ? false : true);
            return $this->_m_value;
        }
        protected $_m_byte;
        public function byte() { return $this->_m_byte; }
    }
}

namespace OsuScores {
    class String extends \Kaitai\Struct\Struct {
        public function __construct(\Kaitai\Struct\Stream $_io, \Kaitai\Struct\Struct $_parent = null, \OsuScores $_root = null) {
            parent::__construct($_io, $_parent, $_root);
            $this->_read();
        }

        private function _read() {
            $this->_m_isPresent = $this->_io->readS1();
            if ($this->isPresent() == 11) {
                $this->_m_lenStr = new \VlqBase128Le($this->_io);
            }
            if ($this->isPresent() == 11) {
                $this->_m_value = \Kaitai\Struct\Stream::bytesToStr($this->_io->readBytes($this->lenStr()->value()), "UTF-8");
            }
        }
        protected $_m_isPresent;
        protected $_m_lenStr;
        protected $_m_value;
        public function isPresent() { return $this->_m_isPresent; }
        public function lenStr() { return $this->_m_lenStr; }
        public function value() { return $this->_m_value; }
    }
}

namespace OsuScores {
    class Beatmap extends \Kaitai\Struct\Struct {
        public function __construct(\Kaitai\Struct\Stream $_io, \OsuScores $_parent = null, \OsuScores $_root = null) {
            parent::__construct($_io, $_parent, $_root);
            $this->_read();
        }

        private function _read() {
            $this->_m_md5Hash = new \OsuScores\String($this->_io, $this, $this->_root);
            $this->_m_numScores = $this->_io->readS4le();
            $this->_m_scores = [];
            $n = $this->numScores();
            for ($i = 0; $i < $n; $i++) {
                $this->_m_scores[] = new \OsuScores\Score($this->_io, $this, $this->_root);
            }
        }
        protected $_m_md5Hash;
        protected $_m_numScores;
        protected $_m_scores;

        /**
         * String, Beatmap MD5 hash
         */
        public function md5Hash() { return $this->_m_md5Hash; }

        /**
         * Int, Number of scores on this beatmap
         */
        public function numScores() { return $this->_m_numScores; }

        /**
         * Score*, Aforementioned scores
         */
        public function scores() { return $this->_m_scores; }
    }
}

namespace OsuScores {
    class Score extends \Kaitai\Struct\Struct {
        public function __construct(\Kaitai\Struct\Stream $_io, \OsuScores\Beatmap $_parent = null, \OsuScores $_root = null) {
            parent::__construct($_io, $_parent, $_root);
            $this->_read();
        }

        private function _read() {
            $this->_m_gameplayMode = $this->_io->readS1();
            $this->_m_version = $this->_io->readS4le();
            $this->_m_beatmapMd5Hash = new \OsuScores\String($this->_io, $this, $this->_root);
            $this->_m_playerName = new \OsuScores\String($this->_io, $this, $this->_root);
            $this->_m_replayMd5Hash = new \OsuScores\String($this->_io, $this, $this->_root);
            $this->_m_num300 = $this->_io->readS2le();
            $this->_m_num100 = $this->_io->readS2le();
            $this->_m_num50 = $this->_io->readS2le();
            $this->_m_numGekis = $this->_io->readS2le();
            $this->_m_numKatus = $this->_io->readS2le();
            $this->_m_numMiss = $this->_io->readS2le();
            $this->_m_replayScore = $this->_io->readS4le();
            $this->_m_maxCombo = $this->_io->readS2le();
            $this->_m_perfectCombo = new \OsuScores\Bool($this->_io, $this, $this->_root);
            $this->_m_mods = $this->_io->readS4le();
            $this->_m_empty = new \OsuScores\String($this->_io, $this, $this->_root);
            $this->_m_replayTimestamp = $this->_io->readS8le();
            $this->_m_minusOne = $this->_io->readBytes(4);
            if (!($this->minusOne() == "\xFF\xFF\xFF\xFF")) {
                throw new \Kaitai\Struct\Error\ValidationNotEqualError("\xFF\xFF\xFF\xFF", $this->minusOne(), $this->_io(), "/types/score/seq/17");
            }
            $this->_m_onlineScoreId = $this->_io->readS8le();
        }
        protected $_m_gameplayMode;
        protected $_m_version;
        protected $_m_beatmapMd5Hash;
        protected $_m_playerName;
        protected $_m_replayMd5Hash;
        protected $_m_num300;
        protected $_m_num100;
        protected $_m_num50;
        protected $_m_numGekis;
        protected $_m_numKatus;
        protected $_m_numMiss;
        protected $_m_replayScore;
        protected $_m_maxCombo;
        protected $_m_perfectCombo;
        protected $_m_mods;
        protected $_m_empty;
        protected $_m_replayTimestamp;
        protected $_m_minusOne;
        protected $_m_onlineScoreId;

        /**
         * Byte, osu! gameplay mode (0x00 = osu!Standard, 0x01 = Taiko, 0x02 = CTB, 0x03 = Mania)
         */
        public function gameplayMode() { return $this->_m_gameplayMode; }

        /**
         * Int, Version of this score/replay (e.g. 20150203)
         */
        public function version() { return $this->_m_version; }

        /**
         * String, Beatmap MD5 hash
         */
        public function beatmapMd5Hash() { return $this->_m_beatmapMd5Hash; }

        /**
         * String, Player name
         */
        public function playerName() { return $this->_m_playerName; }

        /**
         * String, Replay MD5 hash
         */
        public function replayMd5Hash() { return $this->_m_replayMd5Hash; }

        /**
         * Short, Number of 300's
         */
        public function num300() { return $this->_m_num300; }

        /**
         * Short, Number of 100's in osu!Standard, 150's in Taiko, 100's in CTB, 100's in Mania
         */
        public function num100() { return $this->_m_num100; }

        /**
         * Short, Number of 50's in osu!Standard, small fruit in CTB, 50's in Mania
         */
        public function num50() { return $this->_m_num50; }

        /**
         * Short, Number of Gekis in osu!Standard, Max 300's in Mania
         */
        public function numGekis() { return $this->_m_numGekis; }

        /**
         * Short, Number of Katus in osu!Standard, 200's in Mania
         */
        public function numKatus() { return $this->_m_numKatus; }

        /**
         * Short, Number of misses
         */
        public function numMiss() { return $this->_m_numMiss; }

        /**
         * Int, Replay score
         */
        public function replayScore() { return $this->_m_replayScore; }

        /**
         * Short, Max Combo
         */
        public function maxCombo() { return $this->_m_maxCombo; }

        /**
         * Boolean, Perfect combo
         */
        public function perfectCombo() { return $this->_m_perfectCombo; }

        /**
         * Int, Bitwise combination of mods used. See Osr (file format) for more information.
         */
        public function mods() { return $this->_m_mods; }

        /**
         * String, Should always be empty
         */
        public function empty() { return $this->_m_empty; }

        /**
         * Long, Timestamp of replay, in Windows ticks
         */
        public function replayTimestamp() { return $this->_m_replayTimestamp; }

        /**
         * Int, Should always be 0xffffffff (-1).
         */
        public function minusOne() { return $this->_m_minusOne; }

        /**
         * Long, Online Score ID
         */
        public function onlineScoreId() { return $this->_m_onlineScoreId; }
    }
}
