#pragma once

// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

#include "kaitai/kaitaistruct.h"
#include <stdint.h>
#include <memory>
#include "vlq_base128_le.h"
#include <vector>

#if KAITAI_STRUCT_VERSION < 9000L
#error "Incompatible Kaitai Struct C++/STL API: version 0.9 or later is required"
#endif
class vlq_base128_le_t;

/**
 * collection.db file format in rhythm game, osu!.
 * \sa https://osu.ppy.sh/wiki/zh-tw/osu%21_File_Formats/Db_%28file_format%29 Source
 */

class osu_collection_t : public kaitai::kstruct {

public:
    class collection_t;
    class string_t;

    osu_collection_t(kaitai::kstream* p__io, kaitai::kstruct* p__parent = nullptr, osu_collection_t* p__root = nullptr);

private:
    void _read();
    void _clean_up();

public:
    ~osu_collection_t();

    class collection_t : public kaitai::kstruct {

    public:

        collection_t(kaitai::kstream* p__io, osu_collection_t* p__parent = nullptr, osu_collection_t* p__root = nullptr);

    private:
        void _read();
        void _clean_up();

    public:
        ~collection_t();

    private:
        std::unique_ptr<string_t> m_name;
        int32_t m_num_beatmaps;
        std::unique_ptr<std::vector<std::unique_ptr<string_t>>> m_beatmaps_md5s;
        osu_collection_t* m__root;
        osu_collection_t* m__parent;

    public:

        /**
         * String, Name of the collection
         */
        string_t* name() const { return m_name.get(); }

        /**
         * Int, Number of beatmaps in the collection
         */
        int32_t num_beatmaps() const { return m_num_beatmaps; }

        /**
         * String*, Beatmap MD5 hash. Repeated for as many beatmaps as are in the collection.
         */
        std::vector<std::unique_ptr<string_t>>* beatmaps_md5s() const { return m_beatmaps_md5s.get(); }
        osu_collection_t* _root() const { return m__root; }
        osu_collection_t* _parent() const { return m__parent; }
    };

    class string_t : public kaitai::kstruct {

    public:

        string_t(kaitai::kstream* p__io, osu_collection_t::collection_t* p__parent = nullptr, osu_collection_t* p__root = nullptr);

    private:
        void _read();
        void _clean_up();

    public:
        ~string_t();

    private:
        int8_t m_is_present;
        std::unique_ptr<vlq_base128_le_t> m_len_str;
        bool n_len_str;

    public:
        bool _is_null_len_str() { len_str(); return n_len_str; };

    private:
        std::string m_value;
        bool n_value;

    public:
        bool _is_null_value() { value(); return n_value; };

    private:
        osu_collection_t* m__root;
        osu_collection_t::collection_t* m__parent;

    public:
        int8_t is_present() const { return m_is_present; }
        vlq_base128_le_t* len_str() const { return m_len_str.get(); }
        std::string value() const { return m_value; }
        osu_collection_t* _root() const { return m__root; }
        osu_collection_t::collection_t* _parent() const { return m__parent; }
    };

private:
    int32_t m_version;
    int32_t m_num_collections;
    std::unique_ptr<std::vector<std::unique_ptr<collection_t>>> m_collections;
    osu_collection_t* m__root;
    kaitai::kstruct* m__parent;

public:

    /**
     * Int, Version (e.g. 20150203)
     */
    int32_t version() const { return m_version; }

    /**
     * Int, Number of collections
     */
    int32_t num_collections() const { return m_num_collections; }
    std::vector<std::unique_ptr<collection_t>>* collections() const { return m_collections.get(); }
    osu_collection_t* _root() const { return m__root; }
    kaitai::kstruct* _parent() const { return m__parent; }
};
