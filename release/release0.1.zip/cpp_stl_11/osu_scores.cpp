// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

#include "osu_scores.h"
#include "kaitai/exceptions.h"

osu_scores_t::osu_scores_t(kaitai::kstream* p__io, kaitai::kstruct* p__parent, osu_scores_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = this;
    m_beatmaps = nullptr;
    _read();
}

void osu_scores_t::_read() {
    m_version = m__io->read_s4le();
    m_num_beatmaps = m__io->read_s4le();
    int l_beatmaps = num_beatmaps();
    m_beatmaps = std::unique_ptr<std::vector<std::unique_ptr<beatmap_t>>>(new std::vector<std::unique_ptr<beatmap_t>>());
    m_beatmaps->reserve(l_beatmaps);
    for (int i = 0; i < l_beatmaps; i++) {
        m_beatmaps->push_back(std::move(std::unique_ptr<beatmap_t>(new beatmap_t(m__io, this, m__root))));
    }
}

osu_scores_t::~osu_scores_t() {
    _clean_up();
}

void osu_scores_t::_clean_up() {
}

osu_scores_t::bool_t::bool_t(kaitai::kstream* p__io, osu_scores_t::score_t* p__parent, osu_scores_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    f_value = false;
    _read();
}

void osu_scores_t::bool_t::_read() {
    m_byte = m__io->read_s1();
}

osu_scores_t::bool_t::~bool_t() {
    _clean_up();
}

void osu_scores_t::bool_t::_clean_up() {
}

bool osu_scores_t::bool_t::value() {
    if (f_value)
        return m_value;
    m_value = ((byte() == 0) ? (false) : (true));
    f_value = true;
    return m_value;
}

osu_scores_t::string_t::string_t(kaitai::kstream* p__io, kaitai::kstruct* p__parent, osu_scores_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    m_len_str = nullptr;
    _read();
}

void osu_scores_t::string_t::_read() {
    m_is_present = m__io->read_s1();
    n_len_str = true;
    if (is_present() == 11) {
        n_len_str = false;
        m_len_str = std::unique_ptr<vlq_base128_le_t>(new vlq_base128_le_t(m__io));
    }
    n_value = true;
    if (is_present() == 11) {
        n_value = false;
        m_value = kaitai::kstream::bytes_to_str(m__io->read_bytes(len_str()->value()), std::string("UTF-8"));
    }
}

osu_scores_t::string_t::~string_t() {
    _clean_up();
}

void osu_scores_t::string_t::_clean_up() {
    if (!n_len_str) {
    }
    if (!n_value) {
    }
}

osu_scores_t::beatmap_t::beatmap_t(kaitai::kstream* p__io, osu_scores_t* p__parent, osu_scores_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    m_md5_hash = nullptr;
    m_scores = nullptr;
    _read();
}

void osu_scores_t::beatmap_t::_read() {
    m_md5_hash = std::unique_ptr<string_t>(new string_t(m__io, this, m__root));
    m_num_scores = m__io->read_s4le();
    int l_scores = num_scores();
    m_scores = std::unique_ptr<std::vector<std::unique_ptr<score_t>>>(new std::vector<std::unique_ptr<score_t>>());
    m_scores->reserve(l_scores);
    for (int i = 0; i < l_scores; i++) {
        m_scores->push_back(std::move(std::unique_ptr<score_t>(new score_t(m__io, this, m__root))));
    }
}

osu_scores_t::beatmap_t::~beatmap_t() {
    _clean_up();
}

void osu_scores_t::beatmap_t::_clean_up() {
}

osu_scores_t::score_t::score_t(kaitai::kstream* p__io, osu_scores_t::beatmap_t* p__parent, osu_scores_t* p__root) : kaitai::kstruct(p__io) {
    m__parent = p__parent;
    m__root = p__root;
    m_beatmap_md5_hash = nullptr;
    m_player_name = nullptr;
    m_replay_md5_hash = nullptr;
    m_perfect_combo = nullptr;
    m_empty = nullptr;
    _read();
}

void osu_scores_t::score_t::_read() {
    m_gameplay_mode = m__io->read_s1();
    m_version = m__io->read_s4le();
    m_beatmap_md5_hash = std::unique_ptr<string_t>(new string_t(m__io, this, m__root));
    m_player_name = std::unique_ptr<string_t>(new string_t(m__io, this, m__root));
    m_replay_md5_hash = std::unique_ptr<string_t>(new string_t(m__io, this, m__root));
    m_num_300 = m__io->read_s2le();
    m_num_100 = m__io->read_s2le();
    m_num_50 = m__io->read_s2le();
    m_num_gekis = m__io->read_s2le();
    m_num_katus = m__io->read_s2le();
    m_num_miss = m__io->read_s2le();
    m_replay_score = m__io->read_s4le();
    m_max_combo = m__io->read_s2le();
    m_perfect_combo = std::unique_ptr<bool_t>(new bool_t(m__io, this, m__root));
    m_mods = m__io->read_s4le();
    m_empty = std::unique_ptr<string_t>(new string_t(m__io, this, m__root));
    m_replay_timestamp = m__io->read_s8le();
    m_minus_one = m__io->read_bytes(4);
    if (!(minus_one() == std::string("\xFF\xFF\xFF\xFF", 4))) {
        throw kaitai::validation_not_equal_error<std::string>(std::string("\xFF\xFF\xFF\xFF", 4), minus_one(), _io(), std::string("/types/score/seq/17"));
    }
    m_online_score_id = m__io->read_s8le();
}

osu_scores_t::score_t::~score_t() {
    _clean_up();
}

void osu_scores_t::score_t::_clean_up() {
}
