// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

using System.Collections.Generic;

namespace Kaitai
{

    /// <summary>
    /// collection.db file format in rhythm game, osu!.
    /// </summary>
    /// <remarks>
    /// Reference: <a href="https://osu.ppy.sh/wiki/zh-tw/osu%21_File_Formats/Db_%28file_format%29">Source</a>
    /// </remarks>
    public partial class OsuCollection : KaitaiStruct
    {
        public static OsuCollection FromFile(string fileName)
        {
            return new OsuCollection(new KaitaiStream(fileName));
        }

        public OsuCollection(KaitaiStream p__io, KaitaiStruct p__parent = null, OsuCollection p__root = null) : base(p__io)
        {
            m_parent = p__parent;
            m_root = p__root ?? this;
            _read();
        }
        private void _read()
        {
            _version = m_io.ReadS4le();
            _numCollections = m_io.ReadS4le();
            _collections = new List<Collection>((int) (NumCollections));
            for (var i = 0; i < NumCollections; i++)
            {
                _collections.Add(new Collection(m_io, this, m_root));
            }
        }
        public partial class Collection : KaitaiStruct
        {
            public static Collection FromFile(string fileName)
            {
                return new Collection(new KaitaiStream(fileName));
            }

            public Collection(KaitaiStream p__io, OsuCollection p__parent = null, OsuCollection p__root = null) : base(p__io)
            {
                m_parent = p__parent;
                m_root = p__root;
                _read();
            }
            private void _read()
            {
                _name = new String(m_io, this, m_root);
                _numBeatmaps = m_io.ReadS4le();
                _beatmapsMd5s = new List<String>((int) (NumBeatmaps));
                for (var i = 0; i < NumBeatmaps; i++)
                {
                    _beatmapsMd5s.Add(new String(m_io, this, m_root));
                }
            }
            private String _name;
            private int _numBeatmaps;
            private List<String> _beatmapsMd5s;
            private OsuCollection m_root;
            private OsuCollection m_parent;

            /// <summary>
            /// String, Name of the collection
            /// </summary>
            public String Name { get { return _name; } }

            /// <summary>
            /// Int, Number of beatmaps in the collection
            /// </summary>
            public int NumBeatmaps { get { return _numBeatmaps; } }

            /// <summary>
            /// String*, Beatmap MD5 hash. Repeated for as many beatmaps as are in the collection.
            /// </summary>
            public List<String> BeatmapsMd5s { get { return _beatmapsMd5s; } }
            public OsuCollection M_Root { get { return m_root; } }
            public OsuCollection M_Parent { get { return m_parent; } }
        }
        public partial class String : KaitaiStruct
        {
            public static String FromFile(string fileName)
            {
                return new String(new KaitaiStream(fileName));
            }

            public String(KaitaiStream p__io, OsuCollection.Collection p__parent = null, OsuCollection p__root = null) : base(p__io)
            {
                m_parent = p__parent;
                m_root = p__root;
                _read();
            }
            private void _read()
            {
                _isPresent = m_io.ReadS1();
                if (IsPresent == 11) {
                    _lenStr = new VlqBase128Le(m_io);
                }
                if (IsPresent == 11) {
                    _value = System.Text.Encoding.GetEncoding("UTF-8").GetString(m_io.ReadBytes(LenStr.Value));
                }
            }
            private sbyte _isPresent;
            private VlqBase128Le _lenStr;
            private string _value;
            private OsuCollection m_root;
            private OsuCollection.Collection m_parent;
            public sbyte IsPresent { get { return _isPresent; } }
            public VlqBase128Le LenStr { get { return _lenStr; } }
            public string Value { get { return _value; } }
            public OsuCollection M_Root { get { return m_root; } }
            public OsuCollection.Collection M_Parent { get { return m_parent; } }
        }
        private int _version;
        private int _numCollections;
        private List<Collection> _collections;
        private OsuCollection m_root;
        private KaitaiStruct m_parent;

        /// <summary>
        /// Int, Version (e.g. 20150203)
        /// </summary>
        public int Version { get { return _version; } }

        /// <summary>
        /// Int, Number of collections
        /// </summary>
        public int NumCollections { get { return _numCollections; } }
        public List<Collection> Collections { get { return _collections; } }
        public OsuCollection M_Root { get { return m_root; } }
        public KaitaiStruct M_Parent { get { return m_parent; } }
    }
}
