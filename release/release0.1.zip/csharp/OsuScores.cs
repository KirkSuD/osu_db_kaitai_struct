// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

using System.Collections.Generic;

namespace Kaitai
{

    /// <summary>
    /// scores.db file format in rhythm game, osu!.
    /// </summary>
    /// <remarks>
    /// Reference: <a href="https://osu.ppy.sh/wiki/zh-tw/osu%21_File_Formats/Db_%28file_format%29">Source</a>
    /// </remarks>
    public partial class OsuScores : KaitaiStruct
    {
        public static OsuScores FromFile(string fileName)
        {
            return new OsuScores(new KaitaiStream(fileName));
        }

        public OsuScores(KaitaiStream p__io, KaitaiStruct p__parent = null, OsuScores p__root = null) : base(p__io)
        {
            m_parent = p__parent;
            m_root = p__root ?? this;
            _read();
        }
        private void _read()
        {
            _version = m_io.ReadS4le();
            _numBeatmaps = m_io.ReadS4le();
            _beatmaps = new List<Beatmap>((int) (NumBeatmaps));
            for (var i = 0; i < NumBeatmaps; i++)
            {
                _beatmaps.Add(new Beatmap(m_io, this, m_root));
            }
        }
        public partial class Bool : KaitaiStruct
        {
            public static Bool FromFile(string fileName)
            {
                return new Bool(new KaitaiStream(fileName));
            }

            public Bool(KaitaiStream p__io, OsuScores.Score p__parent = null, OsuScores p__root = null) : base(p__io)
            {
                m_parent = p__parent;
                m_root = p__root;
                f_value = false;
                _read();
            }
            private void _read()
            {
                _byte = m_io.ReadS1();
            }
            private bool f_value;
            private bool _value;
            public bool Value
            {
                get
                {
                    if (f_value)
                        return _value;
                    _value = (bool) ((Byte == 0 ? false : true));
                    f_value = true;
                    return _value;
                }
            }
            private sbyte _byte;
            private OsuScores m_root;
            private OsuScores.Score m_parent;
            public sbyte Byte { get { return _byte; } }
            public OsuScores M_Root { get { return m_root; } }
            public OsuScores.Score M_Parent { get { return m_parent; } }
        }
        public partial class String : KaitaiStruct
        {
            public static String FromFile(string fileName)
            {
                return new String(new KaitaiStream(fileName));
            }

            public String(KaitaiStream p__io, KaitaiStruct p__parent = null, OsuScores p__root = null) : base(p__io)
            {
                m_parent = p__parent;
                m_root = p__root;
                _read();
            }
            private void _read()
            {
                _isPresent = m_io.ReadS1();
                if (IsPresent == 11) {
                    _lenStr = new VlqBase128Le(m_io);
                }
                if (IsPresent == 11) {
                    _value = System.Text.Encoding.GetEncoding("UTF-8").GetString(m_io.ReadBytes(LenStr.Value));
                }
            }
            private sbyte _isPresent;
            private VlqBase128Le _lenStr;
            private string _value;
            private OsuScores m_root;
            private KaitaiStruct m_parent;
            public sbyte IsPresent { get { return _isPresent; } }
            public VlqBase128Le LenStr { get { return _lenStr; } }
            public string Value { get { return _value; } }
            public OsuScores M_Root { get { return m_root; } }
            public KaitaiStruct M_Parent { get { return m_parent; } }
        }
        public partial class Beatmap : KaitaiStruct
        {
            public static Beatmap FromFile(string fileName)
            {
                return new Beatmap(new KaitaiStream(fileName));
            }

            public Beatmap(KaitaiStream p__io, OsuScores p__parent = null, OsuScores p__root = null) : base(p__io)
            {
                m_parent = p__parent;
                m_root = p__root;
                _read();
            }
            private void _read()
            {
                _md5Hash = new String(m_io, this, m_root);
                _numScores = m_io.ReadS4le();
                _scores = new List<Score>((int) (NumScores));
                for (var i = 0; i < NumScores; i++)
                {
                    _scores.Add(new Score(m_io, this, m_root));
                }
            }
            private String _md5Hash;
            private int _numScores;
            private List<Score> _scores;
            private OsuScores m_root;
            private OsuScores m_parent;

            /// <summary>
            /// String, Beatmap MD5 hash
            /// </summary>
            public String Md5Hash { get { return _md5Hash; } }

            /// <summary>
            /// Int, Number of scores on this beatmap
            /// </summary>
            public int NumScores { get { return _numScores; } }

            /// <summary>
            /// Score*, Aforementioned scores
            /// </summary>
            public List<Score> Scores { get { return _scores; } }
            public OsuScores M_Root { get { return m_root; } }
            public OsuScores M_Parent { get { return m_parent; } }
        }
        public partial class Score : KaitaiStruct
        {
            public static Score FromFile(string fileName)
            {
                return new Score(new KaitaiStream(fileName));
            }

            public Score(KaitaiStream p__io, OsuScores.Beatmap p__parent = null, OsuScores p__root = null) : base(p__io)
            {
                m_parent = p__parent;
                m_root = p__root;
                _read();
            }
            private void _read()
            {
                _gameplayMode = m_io.ReadS1();
                _version = m_io.ReadS4le();
                _beatmapMd5Hash = new String(m_io, this, m_root);
                _playerName = new String(m_io, this, m_root);
                _replayMd5Hash = new String(m_io, this, m_root);
                _num300 = m_io.ReadS2le();
                _num100 = m_io.ReadS2le();
                _num50 = m_io.ReadS2le();
                _numGekis = m_io.ReadS2le();
                _numKatus = m_io.ReadS2le();
                _numMiss = m_io.ReadS2le();
                _replayScore = m_io.ReadS4le();
                _maxCombo = m_io.ReadS2le();
                _perfectCombo = new Bool(m_io, this, m_root);
                _mods = m_io.ReadS4le();
                _empty = new String(m_io, this, m_root);
                _replayTimestamp = m_io.ReadS8le();
                _minusOne = m_io.ReadBytes(4);
                if (!((KaitaiStream.ByteArrayCompare(MinusOne, new byte[] { 255, 255, 255, 255 }) == 0)))
                {
                    throw new ValidationNotEqualError(new byte[] { 255, 255, 255, 255 }, MinusOne, M_Io, "/types/score/seq/17");
                }
                _onlineScoreId = m_io.ReadS8le();
            }
            private sbyte _gameplayMode;
            private int _version;
            private String _beatmapMd5Hash;
            private String _playerName;
            private String _replayMd5Hash;
            private short _num300;
            private short _num100;
            private short _num50;
            private short _numGekis;
            private short _numKatus;
            private short _numMiss;
            private int _replayScore;
            private short _maxCombo;
            private Bool _perfectCombo;
            private int _mods;
            private String _empty;
            private long _replayTimestamp;
            private byte[] _minusOne;
            private long _onlineScoreId;
            private OsuScores m_root;
            private OsuScores.Beatmap m_parent;

            /// <summary>
            /// Byte, osu! gameplay mode (0x00 = osu!Standard, 0x01 = Taiko, 0x02 = CTB, 0x03 = Mania)
            /// </summary>
            public sbyte GameplayMode { get { return _gameplayMode; } }

            /// <summary>
            /// Int, Version of this score/replay (e.g. 20150203)
            /// </summary>
            public int Version { get { return _version; } }

            /// <summary>
            /// String, Beatmap MD5 hash
            /// </summary>
            public String BeatmapMd5Hash { get { return _beatmapMd5Hash; } }

            /// <summary>
            /// String, Player name
            /// </summary>
            public String PlayerName { get { return _playerName; } }

            /// <summary>
            /// String, Replay MD5 hash
            /// </summary>
            public String ReplayMd5Hash { get { return _replayMd5Hash; } }

            /// <summary>
            /// Short, Number of 300's
            /// </summary>
            public short Num300 { get { return _num300; } }

            /// <summary>
            /// Short, Number of 100's in osu!Standard, 150's in Taiko, 100's in CTB, 100's in Mania
            /// </summary>
            public short Num100 { get { return _num100; } }

            /// <summary>
            /// Short, Number of 50's in osu!Standard, small fruit in CTB, 50's in Mania
            /// </summary>
            public short Num50 { get { return _num50; } }

            /// <summary>
            /// Short, Number of Gekis in osu!Standard, Max 300's in Mania
            /// </summary>
            public short NumGekis { get { return _numGekis; } }

            /// <summary>
            /// Short, Number of Katus in osu!Standard, 200's in Mania
            /// </summary>
            public short NumKatus { get { return _numKatus; } }

            /// <summary>
            /// Short, Number of misses
            /// </summary>
            public short NumMiss { get { return _numMiss; } }

            /// <summary>
            /// Int, Replay score
            /// </summary>
            public int ReplayScore { get { return _replayScore; } }

            /// <summary>
            /// Short, Max Combo
            /// </summary>
            public short MaxCombo { get { return _maxCombo; } }

            /// <summary>
            /// Boolean, Perfect combo
            /// </summary>
            public Bool PerfectCombo { get { return _perfectCombo; } }

            /// <summary>
            /// Int, Bitwise combination of mods used. See Osr (file format) for more information.
            /// </summary>
            public int Mods { get { return _mods; } }

            /// <summary>
            /// String, Should always be empty
            /// </summary>
            public String Empty { get { return _empty; } }

            /// <summary>
            /// Long, Timestamp of replay, in Windows ticks
            /// </summary>
            public long ReplayTimestamp { get { return _replayTimestamp; } }

            /// <summary>
            /// Int, Should always be 0xffffffff (-1).
            /// </summary>
            public byte[] MinusOne { get { return _minusOne; } }

            /// <summary>
            /// Long, Online Score ID
            /// </summary>
            public long OnlineScoreId { get { return _onlineScoreId; } }
            public OsuScores M_Root { get { return m_root; } }
            public OsuScores.Beatmap M_Parent { get { return m_parent; } }
        }
        private int _version;
        private int _numBeatmaps;
        private List<Beatmap> _beatmaps;
        private OsuScores m_root;
        private KaitaiStruct m_parent;

        /// <summary>
        /// Int, Version (e.g. 20150204)
        /// </summary>
        public int Version { get { return _version; } }

        /// <summary>
        /// Int, Number of beatmaps
        /// </summary>
        public int NumBeatmaps { get { return _numBeatmaps; } }

        /// <summary>
        /// Beatmaps*, Aforementioned beatmaps
        /// </summary>
        public List<Beatmap> Beatmaps { get { return _beatmaps; } }
        public OsuScores M_Root { get { return m_root; } }
        public KaitaiStruct M_Parent { get { return m_parent; } }
    }
}
