from construct import *
from construct.lib import *

osu_collection__collection = Struct(
	'name' / LazyBound(lambda: osu_collection__string),
	'num_beatmaps' / Int32sl,
	'beatmaps_md5s' / Array(this.num_beatmaps, LazyBound(lambda: osu_collection__string)),
)

osu_collection__string = Struct(
	'is_present' / Int8sb,
	'len_str' / If(this.is_present == 11, LazyBound(lambda: vlq_base128_le)),
	'value' / If(this.is_present == 11, FixedSized(this.len_str.value, GreedyString(encoding='UTF-8'))),
)

osu_collection = Struct(
	'version' / Int32sl,
	'num_collections' / Int32sl,
	'collections' / Array(this.num_collections, LazyBound(lambda: osu_collection__collection)),
)

_schema = osu_collection
