from construct import *
from construct.lib import *

osu_scores__bool = Struct(
	'byte' / Int8sb,
	'value' / Computed(lambda this: (False if this.byte == 0 else True)),
)

osu_scores__string = Struct(
	'is_present' / Int8sb,
	'len_str' / If(this.is_present == 11, LazyBound(lambda: vlq_base128_le)),
	'value' / If(this.is_present == 11, FixedSized(this.len_str.value, GreedyString(encoding='UTF-8'))),
)

osu_scores__beatmap = Struct(
	'md5_hash' / LazyBound(lambda: osu_scores__string),
	'num_scores' / Int32sl,
	'scores' / Array(this.num_scores, LazyBound(lambda: osu_scores__score)),
)

osu_scores__score = Struct(
	'gameplay_mode' / Int8sb,
	'version' / Int32sl,
	'beatmap_md5_hash' / LazyBound(lambda: osu_scores__string),
	'player_name' / LazyBound(lambda: osu_scores__string),
	'replay_md5_hash' / LazyBound(lambda: osu_scores__string),
	'num_300' / Int16sl,
	'num_100' / Int16sl,
	'num_50' / Int16sl,
	'num_gekis' / Int16sl,
	'num_katus' / Int16sl,
	'num_miss' / Int16sl,
	'replay_score' / Int32sl,
	'max_combo' / Int16sl,
	'perfect_combo' / LazyBound(lambda: osu_scores__bool),
	'mods' / Int32sl,
	'empty' / LazyBound(lambda: osu_scores__string),
	'replay_timestamp' / Int64sl,
	'minus_one' / FixedSized(4, GreedyBytes),
	'online_score_id' / Int64sl,
)

osu_scores = Struct(
	'version' / Int32sl,
	'num_beatmaps' / Int32sl,
	'beatmaps' / Array(this.num_beatmaps, LazyBound(lambda: osu_scores__beatmap)),
)

_schema = osu_scores
