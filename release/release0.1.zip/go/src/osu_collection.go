// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

import "github.com/kaitai-io/kaitai_struct_go_runtime/kaitai"


/**
 * collection.db file format in rhythm game, osu!.
 * @see <a href="https://osu.ppy.sh/wiki/zh-tw/osu%21_File_Formats/Db_%28file_format%29">Source</a>
 */
type OsuCollection struct {
	Version int32
	NumCollections int32
	Collections []*OsuCollection_Collection
	_io *kaitai.Stream
	_root *OsuCollection
	_parent interface{}
}
func NewOsuCollection() *OsuCollection {
	return &OsuCollection{
	}
}

func (this *OsuCollection) Read(io *kaitai.Stream, parent interface{}, root *OsuCollection) (err error) {
	this._io = io
	this._parent = parent
	this._root = root

	tmp1, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.Version = int32(tmp1)
	tmp2, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.NumCollections = int32(tmp2)
	this.Collections = make([]*OsuCollection_Collection, this.NumCollections)
	for i := range this.Collections {
		tmp3 := NewOsuCollection_Collection()
		err = tmp3.Read(this._io, this, this._root)
		if err != nil {
			return err
		}
		this.Collections[i] = tmp3
	}
	return err
}

/**
 * Int, Version (e.g. 20150203)
 */

/**
 * Int, Number of collections
 */
type OsuCollection_Collection struct {
	Name *OsuCollection_String
	NumBeatmaps int32
	BeatmapsMd5s []*OsuCollection_String
	_io *kaitai.Stream
	_root *OsuCollection
	_parent *OsuCollection
}
func NewOsuCollection_Collection() *OsuCollection_Collection {
	return &OsuCollection_Collection{
	}
}

func (this *OsuCollection_Collection) Read(io *kaitai.Stream, parent *OsuCollection, root *OsuCollection) (err error) {
	this._io = io
	this._parent = parent
	this._root = root

	tmp4 := NewOsuCollection_String()
	err = tmp4.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.Name = tmp4
	tmp5, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.NumBeatmaps = int32(tmp5)
	this.BeatmapsMd5s = make([]*OsuCollection_String, this.NumBeatmaps)
	for i := range this.BeatmapsMd5s {
		tmp6 := NewOsuCollection_String()
		err = tmp6.Read(this._io, this, this._root)
		if err != nil {
			return err
		}
		this.BeatmapsMd5s[i] = tmp6
	}
	return err
}

/**
 * String, Name of the collection
 */

/**
 * Int, Number of beatmaps in the collection
 */

/**
 * String*, Beatmap MD5 hash. Repeated for as many beatmaps as are in the collection.
 */
type OsuCollection_String struct {
	IsPresent int8
	LenStr *VlqBase128Le
	Value string
	_io *kaitai.Stream
	_root *OsuCollection
	_parent *OsuCollection_Collection
}
func NewOsuCollection_String() *OsuCollection_String {
	return &OsuCollection_String{
	}
}

func (this *OsuCollection_String) Read(io *kaitai.Stream, parent *OsuCollection_Collection, root *OsuCollection) (err error) {
	this._io = io
	this._parent = parent
	this._root = root

	tmp7, err := this._io.ReadS1()
	if err != nil {
		return err
	}
	this.IsPresent = tmp7
	if (this.IsPresent == 11) {
		tmp8 := NewVlqBase128Le()
		err = tmp8.Read(this._io, this, nil)
		if err != nil {
			return err
		}
		this.LenStr = tmp8
	}
	if (this.IsPresent == 11) {
		tmp9, err := this.LenStr.Value()
		if err != nil {
			return err
		}
		tmp10, err := this._io.ReadBytes(int(tmp9))
		if err != nil {
			return err
		}
		tmp10 = tmp10
		this.Value = string(tmp10)
	}
	return err
}
