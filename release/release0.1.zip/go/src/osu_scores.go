// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

import (
	"github.com/kaitai-io/kaitai_struct_go_runtime/kaitai"
	"bytes"
)


/**
 * scores.db file format in rhythm game, osu!.
 * @see <a href="https://osu.ppy.sh/wiki/zh-tw/osu%21_File_Formats/Db_%28file_format%29">Source</a>
 */
type OsuScores struct {
	Version int32
	NumBeatmaps int32
	Beatmaps []*OsuScores_Beatmap
	_io *kaitai.Stream
	_root *OsuScores
	_parent interface{}
}
func NewOsuScores() *OsuScores {
	return &OsuScores{
	}
}

func (this *OsuScores) Read(io *kaitai.Stream, parent interface{}, root *OsuScores) (err error) {
	this._io = io
	this._parent = parent
	this._root = root

	tmp1, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.Version = int32(tmp1)
	tmp2, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.NumBeatmaps = int32(tmp2)
	this.Beatmaps = make([]*OsuScores_Beatmap, this.NumBeatmaps)
	for i := range this.Beatmaps {
		tmp3 := NewOsuScores_Beatmap()
		err = tmp3.Read(this._io, this, this._root)
		if err != nil {
			return err
		}
		this.Beatmaps[i] = tmp3
	}
	return err
}

/**
 * Int, Version (e.g. 20150204)
 */

/**
 * Int, Number of beatmaps
 */

/**
 * Beatmaps*, Aforementioned beatmaps
 */
type OsuScores_Bool struct {
	Byte int8
	_io *kaitai.Stream
	_root *OsuScores
	_parent *OsuScores_Score
	_f_value bool
	value bool
}
func NewOsuScores_Bool() *OsuScores_Bool {
	return &OsuScores_Bool{
	}
}

func (this *OsuScores_Bool) Read(io *kaitai.Stream, parent *OsuScores_Score, root *OsuScores) (err error) {
	this._io = io
	this._parent = parent
	this._root = root

	tmp4, err := this._io.ReadS1()
	if err != nil {
		return err
	}
	this.Byte = tmp4
	return err
}
func (this *OsuScores_Bool) Value() (v bool, err error) {
	if (this._f_value) {
		return this.value, nil
	}
	var tmp5 bool;
	if (this.Byte == 0) {
		tmp5 = false
	} else {
		tmp5 = true
	}
	this.value = bool(tmp5)
	this._f_value = true
	return this.value, nil
}
type OsuScores_String struct {
	IsPresent int8
	LenStr *VlqBase128Le
	Value string
	_io *kaitai.Stream
	_root *OsuScores
	_parent interface{}
}
func NewOsuScores_String() *OsuScores_String {
	return &OsuScores_String{
	}
}

func (this *OsuScores_String) Read(io *kaitai.Stream, parent interface{}, root *OsuScores) (err error) {
	this._io = io
	this._parent = parent
	this._root = root

	tmp6, err := this._io.ReadS1()
	if err != nil {
		return err
	}
	this.IsPresent = tmp6
	if (this.IsPresent == 11) {
		tmp7 := NewVlqBase128Le()
		err = tmp7.Read(this._io, this, nil)
		if err != nil {
			return err
		}
		this.LenStr = tmp7
	}
	if (this.IsPresent == 11) {
		tmp8, err := this.LenStr.Value()
		if err != nil {
			return err
		}
		tmp9, err := this._io.ReadBytes(int(tmp8))
		if err != nil {
			return err
		}
		tmp9 = tmp9
		this.Value = string(tmp9)
	}
	return err
}
type OsuScores_Beatmap struct {
	Md5Hash *OsuScores_String
	NumScores int32
	Scores []*OsuScores_Score
	_io *kaitai.Stream
	_root *OsuScores
	_parent *OsuScores
}
func NewOsuScores_Beatmap() *OsuScores_Beatmap {
	return &OsuScores_Beatmap{
	}
}

func (this *OsuScores_Beatmap) Read(io *kaitai.Stream, parent *OsuScores, root *OsuScores) (err error) {
	this._io = io
	this._parent = parent
	this._root = root

	tmp10 := NewOsuScores_String()
	err = tmp10.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.Md5Hash = tmp10
	tmp11, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.NumScores = int32(tmp11)
	this.Scores = make([]*OsuScores_Score, this.NumScores)
	for i := range this.Scores {
		tmp12 := NewOsuScores_Score()
		err = tmp12.Read(this._io, this, this._root)
		if err != nil {
			return err
		}
		this.Scores[i] = tmp12
	}
	return err
}

/**
 * String, Beatmap MD5 hash
 */

/**
 * Int, Number of scores on this beatmap
 */

/**
 * Score*, Aforementioned scores
 */
type OsuScores_Score struct {
	GameplayMode int8
	Version int32
	BeatmapMd5Hash *OsuScores_String
	PlayerName *OsuScores_String
	ReplayMd5Hash *OsuScores_String
	Num300 int16
	Num100 int16
	Num50 int16
	NumGekis int16
	NumKatus int16
	NumMiss int16
	ReplayScore int32
	MaxCombo int16
	PerfectCombo *OsuScores_Bool
	Mods int32
	Empty *OsuScores_String
	ReplayTimestamp int64
	MinusOne []byte
	OnlineScoreId int64
	_io *kaitai.Stream
	_root *OsuScores
	_parent *OsuScores_Beatmap
}
func NewOsuScores_Score() *OsuScores_Score {
	return &OsuScores_Score{
	}
}

func (this *OsuScores_Score) Read(io *kaitai.Stream, parent *OsuScores_Beatmap, root *OsuScores) (err error) {
	this._io = io
	this._parent = parent
	this._root = root

	tmp13, err := this._io.ReadS1()
	if err != nil {
		return err
	}
	this.GameplayMode = tmp13
	tmp14, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.Version = int32(tmp14)
	tmp15 := NewOsuScores_String()
	err = tmp15.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.BeatmapMd5Hash = tmp15
	tmp16 := NewOsuScores_String()
	err = tmp16.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.PlayerName = tmp16
	tmp17 := NewOsuScores_String()
	err = tmp17.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.ReplayMd5Hash = tmp17
	tmp18, err := this._io.ReadS2le()
	if err != nil {
		return err
	}
	this.Num300 = int16(tmp18)
	tmp19, err := this._io.ReadS2le()
	if err != nil {
		return err
	}
	this.Num100 = int16(tmp19)
	tmp20, err := this._io.ReadS2le()
	if err != nil {
		return err
	}
	this.Num50 = int16(tmp20)
	tmp21, err := this._io.ReadS2le()
	if err != nil {
		return err
	}
	this.NumGekis = int16(tmp21)
	tmp22, err := this._io.ReadS2le()
	if err != nil {
		return err
	}
	this.NumKatus = int16(tmp22)
	tmp23, err := this._io.ReadS2le()
	if err != nil {
		return err
	}
	this.NumMiss = int16(tmp23)
	tmp24, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.ReplayScore = int32(tmp24)
	tmp25, err := this._io.ReadS2le()
	if err != nil {
		return err
	}
	this.MaxCombo = int16(tmp25)
	tmp26 := NewOsuScores_Bool()
	err = tmp26.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.PerfectCombo = tmp26
	tmp27, err := this._io.ReadS4le()
	if err != nil {
		return err
	}
	this.Mods = int32(tmp27)
	tmp28 := NewOsuScores_String()
	err = tmp28.Read(this._io, this, this._root)
	if err != nil {
		return err
	}
	this.Empty = tmp28
	tmp29, err := this._io.ReadS8le()
	if err != nil {
		return err
	}
	this.ReplayTimestamp = int64(tmp29)
	tmp30, err := this._io.ReadBytes(int(4))
	if err != nil {
		return err
	}
	tmp30 = tmp30
	this.MinusOne = tmp30
	if !(bytes.Equal(this.MinusOne, []uint8{255, 255, 255, 255})) {
		return kaitai.NewValidationNotEqualError([]uint8{255, 255, 255, 255}, this.MinusOne, this._io, "/types/score/seq/17")
	}
	tmp31, err := this._io.ReadS8le()
	if err != nil {
		return err
	}
	this.OnlineScoreId = int64(tmp31)
	return err
}

/**
 * Byte, osu! gameplay mode (0x00 = osu!Standard, 0x01 = Taiko, 0x02 = CTB, 0x03 = Mania)
 */

/**
 * Int, Version of this score/replay (e.g. 20150203)
 */

/**
 * String, Beatmap MD5 hash
 */

/**
 * String, Player name
 */

/**
 * String, Replay MD5 hash
 */

/**
 * Short, Number of 300's
 */

/**
 * Short, Number of 100's in osu!Standard, 150's in Taiko, 100's in CTB, 100's in Mania
 */

/**
 * Short, Number of 50's in osu!Standard, small fruit in CTB, 50's in Mania
 */

/**
 * Short, Number of Gekis in osu!Standard, Max 300's in Mania
 */

/**
 * Short, Number of Katus in osu!Standard, 200's in Mania
 */

/**
 * Short, Number of misses
 */

/**
 * Int, Replay score
 */

/**
 * Short, Max Combo
 */

/**
 * Boolean, Perfect combo
 */

/**
 * Int, Bitwise combination of mods used. See Osr (file format) for more information.
 */

/**
 * String, Should always be empty
 */

/**
 * Long, Timestamp of replay, in Windows ticks
 */

/**
 * Int, Should always be 0xffffffff (-1).
 */

/**
 * Long, Online Score ID
 */
