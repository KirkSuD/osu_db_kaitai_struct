// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

use std::option::Option;
use std::boxed::Box;
use std::io::Result;
use std::io::Cursor;
use std::vec::Vec;
use std::default::Default;
use kaitai_struct::KaitaiStream;
use kaitai_struct::KaitaiStruct;
use vlq_base128_le::VlqBase128Le;


/*
 * collection.db file format in rhythm game, osu!.
 */
#[derive(Default)]
pub struct OsuCollection {
    pub version: i32,
    pub numCollections: i32,
    pub collections: Vec<Box<OsuCollection__Collection>>,
}

impl KaitaiStruct for OsuCollection {
    fn new<S: KaitaiStream>(stream: &mut S,
                            _parent: &Option<Box<KaitaiStruct>>,
                            _root: &Option<Box<KaitaiStruct>>)
                            -> Result<Self>
        where Self: Sized {
        let mut s: Self = Default::default();

        s.stream = stream;
        s.read(stream, _parent, _root)?;

        Ok(s)
    }


    fn read<S: KaitaiStream>(&mut self,
                             stream: &mut S,
                             _parent: &Option<Box<KaitaiStruct>>,
                             _root: &Option<Box<KaitaiStruct>>)
                             -> Result<()>
        where Self: Sized {
        self.version = self.stream.read_s4le()?;
        self.numCollections = self.stream.read_s4le()?;
        self.collections = vec!();
        for i in 0..self.num_collections {
            self.collections.push(Box::new(OsuCollection__Collection::new(self.stream, self, _root)?));
        }
    }
}

impl OsuCollection {

    /*
     * Int, Version (e.g. 20150203)
     */

    /*
     * Int, Number of collections
     */
}
#[derive(Default)]
pub struct OsuCollection__Collection {
    pub name: Box<OsuCollection__String>,
    pub numBeatmaps: i32,
    pub beatmapsMd5s: Vec<Box<OsuCollection__String>>,
}

impl KaitaiStruct for OsuCollection__Collection {
    fn new<S: KaitaiStream>(stream: &mut S,
                            _parent: &Option<Box<KaitaiStruct>>,
                            _root: &Option<Box<KaitaiStruct>>)
                            -> Result<Self>
        where Self: Sized {
        let mut s: Self = Default::default();

        s.stream = stream;
        s.read(stream, _parent, _root)?;

        Ok(s)
    }


    fn read<S: KaitaiStream>(&mut self,
                             stream: &mut S,
                             _parent: &Option<Box<KaitaiStruct>>,
                             _root: &Option<Box<KaitaiStruct>>)
                             -> Result<()>
        where Self: Sized {
        self.name = Box::new(OsuCollection__String::new(self.stream, self, _root)?);
        self.numBeatmaps = self.stream.read_s4le()?;
        self.beatmapsMd5s = vec!();
        for i in 0..self.num_beatmaps {
            self.beatmapsMd5s.push(Box::new(OsuCollection__String::new(self.stream, self, _root)?));
        }
    }
}

impl OsuCollection__Collection {

    /*
     * String, Name of the collection
     */

    /*
     * Int, Number of beatmaps in the collection
     */

    /*
     * String*, Beatmap MD5 hash. Repeated for as many beatmaps as are in the collection.
     */
}
#[derive(Default)]
pub struct OsuCollection__String {
    pub isPresent: i8,
    pub lenStr: Box<VlqBase128Le>,
    pub value: String,
}

impl KaitaiStruct for OsuCollection__String {
    fn new<S: KaitaiStream>(stream: &mut S,
                            _parent: &Option<Box<KaitaiStruct>>,
                            _root: &Option<Box<KaitaiStruct>>)
                            -> Result<Self>
        where Self: Sized {
        let mut s: Self = Default::default();

        s.stream = stream;
        s.read(stream, _parent, _root)?;

        Ok(s)
    }


    fn read<S: KaitaiStream>(&mut self,
                             stream: &mut S,
                             _parent: &Option<Box<KaitaiStruct>>,
                             _root: &Option<Box<KaitaiStruct>>)
                             -> Result<()>
        where Self: Sized {
        self.isPresent = self.stream.read_s1()?;
        if self.is_present == 11 {
            self.lenStr = Box::new(VlqBase128Le::new(self.stream, self, _root)?);
        }
        if self.is_present == 11 {
            self.value = panic!("Unimplemented encoding for bytesToStr: {}", "UTF-8");
        }
    }
}

impl OsuCollection__String {
}
