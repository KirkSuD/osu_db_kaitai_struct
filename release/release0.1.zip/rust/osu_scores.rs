// This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

use std::option::Option;
use std::boxed::Box;
use std::io::Result;
use std::io::Cursor;
use std::vec::Vec;
use std::default::Default;
use kaitai_struct::KaitaiStream;
use kaitai_struct::KaitaiStruct;
use vlq_base128_le::VlqBase128Le;


/*
 * scores.db file format in rhythm game, osu!.
 */
#[derive(Default)]
pub struct OsuScores {
    pub version: i32,
    pub numBeatmaps: i32,
    pub beatmaps: Vec<Box<OsuScores__Beatmap>>,
}

impl KaitaiStruct for OsuScores {
    fn new<S: KaitaiStream>(stream: &mut S,
                            _parent: &Option<Box<KaitaiStruct>>,
                            _root: &Option<Box<KaitaiStruct>>)
                            -> Result<Self>
        where Self: Sized {
        let mut s: Self = Default::default();

        s.stream = stream;
        s.read(stream, _parent, _root)?;

        Ok(s)
    }


    fn read<S: KaitaiStream>(&mut self,
                             stream: &mut S,
                             _parent: &Option<Box<KaitaiStruct>>,
                             _root: &Option<Box<KaitaiStruct>>)
                             -> Result<()>
        where Self: Sized {
        self.version = self.stream.read_s4le()?;
        self.numBeatmaps = self.stream.read_s4le()?;
        self.beatmaps = vec!();
        for i in 0..self.num_beatmaps {
            self.beatmaps.push(Box::new(OsuScores__Beatmap::new(self.stream, self, _root)?));
        }
    }
}

impl OsuScores {

    /*
     * Int, Version (e.g. 20150204)
     */

    /*
     * Int, Number of beatmaps
     */

    /*
     * Beatmaps*, Aforementioned beatmaps
     */
}
#[derive(Default)]
pub struct OsuScores__Bool {
    pub byte: i8,
    pub value: Option<bool>,
}

impl KaitaiStruct for OsuScores__Bool {
    fn new<S: KaitaiStream>(stream: &mut S,
                            _parent: &Option<Box<KaitaiStruct>>,
                            _root: &Option<Box<KaitaiStruct>>)
                            -> Result<Self>
        where Self: Sized {
        let mut s: Self = Default::default();

        s.stream = stream;
        s.read(stream, _parent, _root)?;

        Ok(s)
    }


    fn read<S: KaitaiStream>(&mut self,
                             stream: &mut S,
                             _parent: &Option<Box<KaitaiStruct>>,
                             _root: &Option<Box<KaitaiStruct>>)
                             -> Result<()>
        where Self: Sized {
        self.byte = self.stream.read_s1()?;
    }
}

impl OsuScores__Bool {
    fn value(&mut self) -> bool {
        if let Some(x) = self.value {
            return x;
        }

        self.value = if self.byte == 0 { false } else { true};
        return self.value;
    }
}
#[derive(Default)]
pub struct OsuScores__String {
    pub isPresent: i8,
    pub lenStr: Box<VlqBase128Le>,
    pub value: String,
}

impl KaitaiStruct for OsuScores__String {
    fn new<S: KaitaiStream>(stream: &mut S,
                            _parent: &Option<Box<KaitaiStruct>>,
                            _root: &Option<Box<KaitaiStruct>>)
                            -> Result<Self>
        where Self: Sized {
        let mut s: Self = Default::default();

        s.stream = stream;
        s.read(stream, _parent, _root)?;

        Ok(s)
    }


    fn read<S: KaitaiStream>(&mut self,
                             stream: &mut S,
                             _parent: &Option<Box<KaitaiStruct>>,
                             _root: &Option<Box<KaitaiStruct>>)
                             -> Result<()>
        where Self: Sized {
        self.isPresent = self.stream.read_s1()?;
        if self.is_present == 11 {
            self.lenStr = Box::new(VlqBase128Le::new(self.stream, self, _root)?);
        }
        if self.is_present == 11 {
            self.value = panic!("Unimplemented encoding for bytesToStr: {}", "UTF-8");
        }
    }
}

impl OsuScores__String {
}
#[derive(Default)]
pub struct OsuScores__Beatmap {
    pub md5Hash: Box<OsuScores__String>,
    pub numScores: i32,
    pub scores: Vec<Box<OsuScores__Score>>,
}

impl KaitaiStruct for OsuScores__Beatmap {
    fn new<S: KaitaiStream>(stream: &mut S,
                            _parent: &Option<Box<KaitaiStruct>>,
                            _root: &Option<Box<KaitaiStruct>>)
                            -> Result<Self>
        where Self: Sized {
        let mut s: Self = Default::default();

        s.stream = stream;
        s.read(stream, _parent, _root)?;

        Ok(s)
    }


    fn read<S: KaitaiStream>(&mut self,
                             stream: &mut S,
                             _parent: &Option<Box<KaitaiStruct>>,
                             _root: &Option<Box<KaitaiStruct>>)
                             -> Result<()>
        where Self: Sized {
        self.md5Hash = Box::new(OsuScores__String::new(self.stream, self, _root)?);
        self.numScores = self.stream.read_s4le()?;
        self.scores = vec!();
        for i in 0..self.num_scores {
            self.scores.push(Box::new(OsuScores__Score::new(self.stream, self, _root)?));
        }
    }
}

impl OsuScores__Beatmap {

    /*
     * String, Beatmap MD5 hash
     */

    /*
     * Int, Number of scores on this beatmap
     */

    /*
     * Score*, Aforementioned scores
     */
}
#[derive(Default)]
pub struct OsuScores__Score {
    pub gameplayMode: i8,
    pub version: i32,
    pub beatmapMd5Hash: Box<OsuScores__String>,
    pub playerName: Box<OsuScores__String>,
    pub replayMd5Hash: Box<OsuScores__String>,
    pub num300: i16,
    pub num100: i16,
    pub num50: i16,
    pub numGekis: i16,
    pub numKatus: i16,
    pub numMiss: i16,
    pub replayScore: i32,
    pub maxCombo: i16,
    pub perfectCombo: Box<OsuScores__Bool>,
    pub mods: i32,
    pub empty: Box<OsuScores__String>,
    pub replayTimestamp: i64,
    pub minusOne: Vec<u8>,
    pub onlineScoreId: i64,
}

impl KaitaiStruct for OsuScores__Score {
    fn new<S: KaitaiStream>(stream: &mut S,
                            _parent: &Option<Box<KaitaiStruct>>,
                            _root: &Option<Box<KaitaiStruct>>)
                            -> Result<Self>
        where Self: Sized {
        let mut s: Self = Default::default();

        s.stream = stream;
        s.read(stream, _parent, _root)?;

        Ok(s)
    }


    fn read<S: KaitaiStream>(&mut self,
                             stream: &mut S,
                             _parent: &Option<Box<KaitaiStruct>>,
                             _root: &Option<Box<KaitaiStruct>>)
                             -> Result<()>
        where Self: Sized {
        self.gameplayMode = self.stream.read_s1()?;
        self.version = self.stream.read_s4le()?;
        self.beatmapMd5Hash = Box::new(OsuScores__String::new(self.stream, self, _root)?);
        self.playerName = Box::new(OsuScores__String::new(self.stream, self, _root)?);
        self.replayMd5Hash = Box::new(OsuScores__String::new(self.stream, self, _root)?);
        self.num300 = self.stream.read_s2le()?;
        self.num100 = self.stream.read_s2le()?;
        self.num50 = self.stream.read_s2le()?;
        self.numGekis = self.stream.read_s2le()?;
        self.numKatus = self.stream.read_s2le()?;
        self.numMiss = self.stream.read_s2le()?;
        self.replayScore = self.stream.read_s4le()?;
        self.maxCombo = self.stream.read_s2le()?;
        self.perfectCombo = Box::new(OsuScores__Bool::new(self.stream, self, _root)?);
        self.mods = self.stream.read_s4le()?;
        self.empty = Box::new(OsuScores__String::new(self.stream, self, _root)?);
        self.replayTimestamp = self.stream.read_s8le()?;
        self.minusOne = self.stream.read_bytes(4)?;
        self.onlineScoreId = self.stream.read_s8le()?;
    }
}

impl OsuScores__Score {

    /*
     * Byte, osu! gameplay mode (0x00 = osu!Standard, 0x01 = Taiko, 0x02 = CTB, 0x03 = Mania)
     */

    /*
     * Int, Version of this score/replay (e.g. 20150203)
     */

    /*
     * String, Beatmap MD5 hash
     */

    /*
     * String, Player name
     */

    /*
     * String, Replay MD5 hash
     */

    /*
     * Short, Number of 300's
     */

    /*
     * Short, Number of 100's in osu!Standard, 150's in Taiko, 100's in CTB, 100's in Mania
     */

    /*
     * Short, Number of 50's in osu!Standard, small fruit in CTB, 50's in Mania
     */

    /*
     * Short, Number of Gekis in osu!Standard, Max 300's in Mania
     */

    /*
     * Short, Number of Katus in osu!Standard, 200's in Mania
     */

    /*
     * Short, Number of misses
     */

    /*
     * Int, Replay score
     */

    /*
     * Short, Max Combo
     */

    /*
     * Boolean, Perfect combo
     */

    /*
     * Int, Bitwise combination of mods used. See Osr (file format) for more information.
     */

    /*
     * String, Should always be empty
     */

    /*
     * Long, Timestamp of replay, in Windows ticks
     */

    /*
     * Int, Should always be 0xffffffff (-1).
     */

    /*
     * Long, Online Score ID
     */
}
